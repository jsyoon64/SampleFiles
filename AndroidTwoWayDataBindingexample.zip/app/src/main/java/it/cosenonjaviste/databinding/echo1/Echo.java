package it.cosenonjaviste.databinding.echo1;

public class Echo {
    public String text;
}
