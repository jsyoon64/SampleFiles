#ifndef SIGNALS_H
#define SIGNALS_H
/*===============================================================================================*/
/**
 *   @file signals.h
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.

*****************************************************
*****************************************************
    SIGNAL GROUP

    1. RESERVED     : 0x0000 ~
    2. XXXX TASK    : 0xX000 ~
    3. TIMER        : 0xX000 ~ 0xX0FF
    4. EVENT        : 0xX100 ~ 0xX1FF
    5. COMMAND      : 0xX200 ~ 0xX2FF

*****************************************************
1) MC TASK
    MC TASK         : 0x1000 ~
    TIMER           : 0x1000 ~ 0x10FF
    EVENT           : 0x1100 ~ 0x11FF
    COMMAND         : 0x1200 ~ 0x12FF

2) LED TASK
    LED TASK        : 0x2000 ~

3) CONSOL TASK
    COLSOL TASK     : 0x3000 ~

4) MP3 TASK
    MP3 TASK        : 0x4000 ~
    
5) SENSOR TASK
    SENSOR TASK     : 0x5000 ~

6) FFT TASK
    FFT TASK        : 0x6000 ~

7) BLE TASK
    BLE TASK        : 0x7000 ~

===================================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Application includes. */
#include "comdef.h"

/* TASK SIGNAL INCLUDE */
#include "mctask_signals.h"
#include "ledtask_signals.h"
#include "consoltask_signals.h"
#include "mp3task_signals.h"
#include "sensortask_signals.h"
#include "ffttask_signals.h"
#include "bletask_signals.h"

/*===============================================================================================*/
#endif  /* SIGNALS_H */
