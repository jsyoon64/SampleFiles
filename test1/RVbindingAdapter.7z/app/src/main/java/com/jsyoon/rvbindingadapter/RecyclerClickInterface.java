package com.jsyoon.rvbindingadapter;

import com.jsyoon.rvbindingadapter.model.User;

/**
 *
 */
public interface RecyclerClickInterface {
    public void onClick(User user);
}
