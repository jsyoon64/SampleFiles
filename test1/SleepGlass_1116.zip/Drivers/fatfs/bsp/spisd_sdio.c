/**
  ******************************************************************************
  * File Name          : SDIO.c
  * Description        : This file provides code for the configuration
  *                      of the SDIO instances.
  ******************************************************************************
  *
  * COPYRIGHT(c) 2016 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "sdio.h"
#include "gpio.h"
#include "target.h"
#include "comdef.h"
#include "diskio.h"
#include "spi.h"
#include "spisd_diskio.h"

#if defined(USE_SPI_SDCARD)
/* USER CODE BEGIN 0 */

#if defined(SHINWOOHW)
    #define SD_SPI          hspi5
#elif defined(FRASENHW)
    #define SD_SPI          hspi3
#endif


#define SD_MAX_RESP_TIME   200 // 100 msec max operate time

/* MMC/SD command */
#define CMD0	(0)			/* GO_IDLE_STATE */
#define CMD1	(1)			/* SEND_OP_COND (MMC) */
#define	ACMD41	(0x80+41)	/* SEND_OP_COND (SDC) */
#define CMD8	(8)			/* SEND_IF_COND */
#define CMD9	(9)			/* SEND_CSD */
#define CMD10	(10)		/* SEND_CID */
#define CMD12	(12)		/* STOP_TRANSMISSION */
#define ACMD13	(0x80+13)	/* SD_STATUS (SDC) */
#define CMD16	(16)		/* SET_BLOCKLEN */
#define CMD17	(17)		/* READ_SINGLE_BLOCK */
#define CMD18	(18)		/* READ_MULTIPLE_BLOCK */
#define CMD23	(23)		/* SET_BLOCK_COUNT (MMC) */
#define	ACMD23	(0x80+23)	/* SET_WR_BLK_ERASE_COUNT (SDC) */
#define CMD24	(24)		/* WRITE_BLOCK */
#define CMD25	(25)		/* WRITE_MULTIPLE_BLOCK */
#define CMD32	(32)		/* ERASE_ER_BLK_START */
#define CMD33	(33)		/* ERASE_ER_BLK_END */
#define CMD38	(38)		/* ERASE */
#define CMD55	(55)		/* APP_CMD */
#define CMD58	(58)		/* READ_OCR */


#define CT_MMC		0x01		/* MMC ver 3 */
#define CT_SD1		0x02		/* SD ver 1 */
#define CT_SD2		0x04		/* SD ver 2 */
#define CT_SDC		(CT_SD1|CT_SD2)	/* SD */
#define CT_BLOCK	0x08		/* Block addressing */


static volatile DSTATUS TM_FATFS_SD_Stat = STA_NOINIT;	/* Physical drive status */

static BYTE TM_FATFS_SD_CardType;			/* Card type flags */

/* USER CODE END 0 */

/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/

/* USER CODE BEGIN 1 */

/* Initialize MMC interface */
static void init_spi (boolean isInitial) {

    if(isInitial)
    {
        MX_SPI5_Init_With_BR_Pres(SPI_BAUDRATEPRESCALER_256);
    }
    else
    {
        MX_SPI5_Init_With_BR_Pres(SPI_BAUDRATEPRESCALER_2);
    }
    
	/* Init SPI */
	//TM_SPI_Init(FATFS_SPI, FATFS_SPI_PINSPACK);
	
	/* Set CS high */
    HAL_GPIO_WritePin(SD__CS_GPIO_Port,SD__CS_Pin, GPIO_PIN_SET); 
    
	/* Wait for stable */
    HAL_Delay(10);
}


/*-----------------------------------------------------------------------*/
/* Wait for card ready                                                   */
/*-----------------------------------------------------------------------*/

static int wait_ready (	/* 1:Ready, 0:Timeout */
	UINT wt			/* Timeout [ms] */
)
{
	BYTE d,data;
    uint32_t  loopcount=0;

	/* Set down counter */
	loopcount = wt*10;
    data = 0xFF;  
	do {
        HAL_SPI_TransmitReceive(&SD_SPI, &data, &d,1, SD_MAX_RESP_TIME);  /* Receive data resp */
        loopcount--;
	} while (d != 0xFF && loopcount > 0);	/* Wait for card goes ready or timeout */

    // d == 0xFF then "wait_ready: OK"
    // else "wait_ready: timeout"
	return (d == 0xFF) ? 1 : 0;
}



/*-----------------------------------------------------------------------*/
/* Deselect card and release SPI                                         */
/*-----------------------------------------------------------------------*/

static void deselect (void)
{
	//BYTE data;

	/* Set CS high */
    HAL_GPIO_WritePin(SD__CS_GPIO_Port,SD__CS_Pin, GPIO_PIN_SET); 

    /* Dummy clock (force DO hi-z for multiple slave SPI) */
    //data = 0xFF;
    //HAL_SPI_Transmit(&SD_SPI, &data, 1, SD_MAX_RESP_TIME);

    //FATFS_DEBUG_SEND_USART("deselect: ok");
}



/*-----------------------------------------------------------------------*/
/* Select card and wait for ready                                        */
/*-----------------------------------------------------------------------*/

static int _select (void)	/* 1:OK, 0:Timeout */
{
	//BYTE data;
    
	/* Set CS low */
    HAL_GPIO_WritePin(SD__CS_GPIO_Port,SD__CS_Pin, GPIO_PIN_RESET); 

    //data = 0xFF;
    //HAL_SPI_Transmit(&SD_SPI, &data, 1, SD_MAX_RESP_TIME);

	if (wait_ready(1500)) 
    {
		//FATFS_DEBUG_SEND_USART("select: OK");
		return 1;	/* OK */
	}
    else
    {
    	//FATFS_DEBUG_SEND_USART("select: no");
    	deselect();
    	return 0;	/* Timeout */
    }
}



/*-----------------------------------------------------------------------*/
/* Receive a data packet from the MMC                                    */
/*-----------------------------------------------------------------------*/

static int rcvr_datablock (	/* 1:OK, 0:Error */
	BYTE *buff,			/* Data buffer */
	UINT btr			/* Data block length (byte) */
)
{
	BYTE token,data;
    uint32_t  loopcount=0;
    
	//Timer1 = 200;

    loopcount = 20; //	TM_DELAY_SetTime2(200);

    
    do{  // Wait for DataStart token in timeout of 200ms 
        data = 0xFF;  
        HAL_SPI_TransmitReceive(&SD_SPI, &data, &token,1, SD_MAX_RESP_TIME);  /* Receive data resp */
        HAL_Delay(1);
        loopcount--;
		// This loop will take a time. Insert rot_rdq() here for multitask envilonment. 
    }while((token == 0xFF) && loopcount > 0 );
    
	if (token != 0xFE) {
		//FATFS_DEBUG_SEND_USART("rcvr_datablock: token != 0xFE");
		return 0;		// Function fails if invalid DataStart token or timeout 
	}

    HAL_SPI_Receive(&SD_SPI, buff, btr, SD_MAX_RESP_TIME);

    data = 0xFF;  
    HAL_SPI_Transmit(&SD_SPI, &data, 1, SD_MAX_RESP_TIME);
    HAL_SPI_Transmit(&SD_SPI, &data, 1, SD_MAX_RESP_TIME);  /* Dummy CRC */
	return 1;						// Function succeeded 
}



/*-----------------------------------------------------------------------*/
/* Send a data packet to the MMC                                         */
/*-----------------------------------------------------------------------*/

#if _USE_WRITE
static int xmit_datablock (	/* 1:OK, 0:Failed */
	const BYTE *buff,	/* Ponter to 512 byte data to be sent */
	BYTE token,			/* Token */
	uint32_t BlockSize
)
{
	BYTE resp,data;
	
	//FATFS_DEBUG_SEND_USART("xmit_datablock: inside");

	if (!wait_ready(500)) {
		//FATFS_DEBUG_SEND_USART("xmit_datablock: not ready");
		return 0;		/* Wait for card ready */
	}
	//FATFS_DEBUG_SEND_USART("xmit_datablock: ready");

    HAL_SPI_Transmit(&SD_SPI, &token, 1, SD_MAX_RESP_TIME); /* Send token */
	if (token != 0xFD) {				/* Send data if token is other than StopTran */

        HAL_SPI_Transmit(&SD_SPI, ( uint8_t *)buff, BlockSize, SD_MAX_RESP_TIME);

        data = 0xFF;  
        HAL_SPI_Transmit(&SD_SPI, &data, 1, SD_MAX_RESP_TIME);
        HAL_SPI_Transmit(&SD_SPI, &data, 1, SD_MAX_RESP_TIME);  /* Dummy CRC */

        data = 0xFF;  
        HAL_SPI_TransmitReceive(&SD_SPI, &data, &resp,1, SD_MAX_RESP_TIME);  /* Receive data resp */
		if ((resp & 0x1F) != 0x05)		/* Function fails if the data packet was not accepted */
			return 0;
	}
	return 1;
}
#endif


/*-----------------------------------------------------------------------*/
/* Send a command packet to the MMC                                      */
/*-----------------------------------------------------------------------*/

static BYTE send_cmd (		/* Return value: R1 resp (bit7==1:Failed to send) */
	BYTE cmd,		/* Command index */
	DWORD arg		/* Argument */
)
{
	BYTE n, res, data;
	
	if (cmd & 0x80) {	/* Send a CMD55 prior to ACMD<n> */
		cmd &= 0x7F;
		res = send_cmd(CMD55, 0);
		if (res > 1) return res;
	}

	/* Select the card and wait for ready except to stop multiple block read */
	if (cmd != CMD12) {
		deselect();
		if (!_select()) return 0xFF;
	}

	/* Send command packet */
    data = 0x40 | cmd;				/* Start + command index */
    HAL_SPI_Transmit(&SD_SPI, &data, 1, SD_MAX_RESP_TIME);

    data = (BYTE)(arg >> 24);		/* Argument[31..24] */
    HAL_SPI_Transmit(&SD_SPI, &data, 1, SD_MAX_RESP_TIME);
    
    data = (BYTE)(arg >> 16);		/* Argument[23..16] */
    HAL_SPI_Transmit(&SD_SPI, &data, 1, SD_MAX_RESP_TIME);
    
    data = (BYTE)(arg >> 8);		/* Argument[15..8] */
    HAL_SPI_Transmit(&SD_SPI, &data, 1, SD_MAX_RESP_TIME);
    
    data = (BYTE)(arg);				/* Argument[7..0] */
    HAL_SPI_Transmit(&SD_SPI, &data, 1, SD_MAX_RESP_TIME);

	n = 0x01;										/* Dummy CRC + Stop */
	if (cmd == CMD0) n = 0x95;						/* Valid CRC for CMD0(0) */
	if (cmd == CMD8) n = 0x87;						/* Valid CRC for CMD8(0x1AA) */
    HAL_SPI_Transmit(&SD_SPI, &n, 1, SD_MAX_RESP_TIME);

	/* Receive command resp */
	if (cmd == CMD12) {
        data = 0xFF;            /* Diacard following one byte when CMD12 */
        HAL_SPI_Transmit(&SD_SPI, &data, 1, SD_MAX_RESP_TIME);
	}
	
	n = 10;								/* Wait for response (10 bytes max) */
    data = 0xFF;  
	do {
        HAL_SPI_TransmitReceive(&SD_SPI, &data, &res,1, SD_MAX_RESP_TIME); 
	} while ((res & 0x80) && --n);

	return res;							/* Return received response */
}


/**
 * @brief  Detects if SD card is correctly plugged in the memory slot or not.
 * @param  None
 * @retval Returns if SD is detected or not
 */
uint8_t BSP_SD_IsDetected(void)
{
  __IO uint8_t status = SD_PRESENT;

  /* Check SD card detect pin */
  if(HAL_GPIO_ReadPin(SD_DECT_GPIO_Port, SD_DECT_Pin) != GPIO_PIN_RESET) 
  {
    status = SD_NOT_PRESENT;
  }
  
  return status;
}



/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/


/**
  * @brief  Initializes the SD card device.
  * @param  None
  * @retval SD status.
  */
uint8_t BSP_SD_Init(void)
{ 
  uint8_t   SD_state = MSD_OK;
  uint8_t   data, cmd, n, ty, ocr[4];
  uint32_t  loopcount=0;
  uint8_t buffer[4] = { 0xFF, 0xFF, 0xFF, 0xFF };
  
  init_spi(TRUE);
  
  /* Check if the SD card is plugged in the slot */
  if(BSP_SD_IsDetected() != SD_PRESENT)
  {
    return MSD_ERROR;
  }
  
  deselect();
  
  //We must supply at least 74 clocks with CS high
  HAL_SPI_Transmit(&SD_SPI, buffer, 4, 100);
  HAL_SPI_Transmit(&SD_SPI, buffer, 4, 100);
  HAL_SPI_Transmit(&SD_SPI, buffer, 4, 100);
  HAL_Delay(10);

  _select();

  ty = 0;

  // command to go idle in SPI mode
  if (send_cmd(CMD0, 0) == 1) {                 /* Put the card SPI/Idle state */
      loopcount = 10000;                        /* Initialization timeout = 1 sec */
      
      // check SD version
      if (send_cmd(CMD8, 0x1AA) == 1) {   /* SDv2? */

        /* Get 32 bit return value of R7 resp */
          data = 0xFF;
          for (n = 0; n < 4; n++) {
              HAL_SPI_TransmitReceive(&SD_SPI, &data, &ocr[n],1, SD_MAX_RESP_TIME); /* Get 32 bit return value of R7 resp */
          }
          
          if (ocr[2] == 0x01 && ocr[3] == 0xAA) {             /* Is the card supports vcc of 2.7-3.6V? */

            // initialize card and send host supports SDHC
            while((--loopcount > 0) &&(send_cmd(ACMD41, 1UL << 30)));

            // if SD2 read OCR register to check for SDHC card
            if( loopcount && (send_cmd(CMD58, 0) == 0)) {
                  data = 0xFF;
                  for (n = 0; n < 4; n++) {
                      HAL_SPI_TransmitReceive(&SD_SPI, &data, &ocr[n],1, SD_MAX_RESP_TIME); /* Get 32 bit return value of R7 resp */
                  }
                  ty = (ocr[0] & 0x40) ? CT_SD2 | CT_BLOCK : CT_SD2;  /* Card id SDv2 */
              }
          }
      } else {    /* Not SDv2 card */
          if (send_cmd(ACMD41, 0) <= 1)   {   /* SDv1 or MMC? */
              ty = CT_SD1; cmd = ACMD41;  /* SDv1 (ACMD41(0)) */
          } else {
              ty = CT_MMC; cmd = CMD1;    /* MMCv3 (CMD1(0)) */
          }

          while((--loopcount > 0) &&(send_cmd(cmd, 0)));  /* Wait for end of initialization */
          if( loopcount && (send_cmd(CMD16, 512) != 0)) { /* Set block length: 512 */
              ty = 0;
          }
      }
      
  }
  TM_FATFS_SD_CardType = ty;  /* Card type */
  deselect();

  if (ty) {           /* OK */
      TM_FATFS_SD_Stat &= ~STA_NOINIT;    /* Clear STA_NOINIT flag */
  } else {            /* Failed */
      TM_FATFS_SD_Stat = STA_NOINIT;
  }

#if (0)
  if (!TM_FATFS_WriteEnabled()) {
      TM_FATFS_SD_Stat |= STA_PROTECT;
  } else {
      TM_FATFS_SD_Stat &= ~STA_PROTECT;
  }
  #endif
  
//  TM_SPI_InitFull(FATFS_SPI, FATFS_SPI_PINSPACK , SPI_BaudRatePrescaler_16,TM_SPI_Mode_0, SPI_Mode_Master, SPI_FirstBit_MSB);


  if(TM_FATFS_SD_Stat == STA_NOINIT)
  {
    SD_state = MSD_ERROR;
  }

  init_spi(FALSE);
  return  SD_state;
}




uint8_t BSP_SD_GetStatus(void) {
	__IO uint8_t status = SD_PRESENT;

	/* Check status */
	if (!BSP_SD_IsDetected()) 
    {
		status = SD_NOT_PRESENT;
	}

#if 0
	/* Check if write is enabled */
	if (!TM_FATFS_WriteEnabled()) {
		TM_FATFS_SD_Stat |= STA_PROTECT;
	} else {
		TM_FATFS_SD_Stat &= ~STA_PROTECT;
	}
#endif	

    if( (status&SD_PRESENT) == SD_PRESENT)
    {
        return MSD_OK;
    }
    else
    {
        return MSD_ERROR;
    }
	/* Return status */
//	return status;
}




#if (0)
/**
  * @brief  Configures Interrupt mode for SD detection pin.
  * @param  None
  * @retval Returns 0
  */
uint8_t BSP_SD_ITConfig(void)
{ 
  GPIO_InitTypeDef GPIO_Init_Structure;
  
  /* Configure Interrupt mode for SD detection pin */ 
  GPIO_Init_Structure.Mode      = GPIO_MODE_IT_RISING_FALLING;
  GPIO_Init_Structure.Pull      = GPIO_PULLUP;
  GPIO_Init_Structure.Speed     = GPIO_SPEED_HIGH;
  GPIO_Init_Structure.Pin       = SD_DECT_Pin;
  HAL_GPIO_Init(SD_DECT_GPIO_Port, &GPIO_Init_Structure);
    
  /* NVIC configuration for SDIO interrupts */
  HAL_NVIC_SetPriority(SD_DETECT_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(SD_DETECT_IRQn);
  
  return 0;
}
#endif

/**
  * @brief  Reads block(s) from a specified address in an SD card, in polling mode.
  * @param  pData: Pointer to the buffer that will contain the data to transmit
  * @param  ReadAddr: Address from where data is to be read  
  * @param  BlockSize: SD card data block size, that should be 512
  * @param  NumOfBlocks: Number of SD blocks to read 
  * @retval SD status
  */
//  if(BSP_SD_ReadBlocks((uint32_t*)buff,(uint64_t) (sector * BLOCK_SIZE), BLOCK_SIZE, count) != MSD_OK)
uint8_t BSP_SD_ReadBlocks(uint32_t *pData, uint64_t sector, uint32_t BlockSize, uint32_t NumOfBlocks)
{
   
	//FATFS_DEBUG_SEND_USART("disk_read: inside");
	if (!BSP_SD_IsDetected() || (TM_FATFS_SD_Stat & STA_NOINIT)) {
		return RES_NOTRDY;
	}

	if (!(TM_FATFS_SD_CardType & CT_BLOCK)) {
		sector *= 512;	/* LBA ot BA conversion (byte addressing cards) */
	}


	if (NumOfBlocks == 1)
	{	/* Single sector read */
		if (send_cmd(CMD17, sector) == 0)	/* READ_SINGLE_BLOCK */
		{
			if(rcvr_datablock((BYTE *)pData, BlockSize))
			{
				NumOfBlocks = 0;
			}
		}
	}
	else
	{				/* Multiple sector read */
		if (send_cmd(CMD18, sector) == 0) {	/* READ_MULTIPLE_BLOCK */
			do {
				if (!rcvr_datablock((BYTE *)pData, BlockSize)) {
					break;
				}
				pData += BlockSize;
			} while (--NumOfBlocks);
			send_cmd(CMD12, 0);				/* STOP_TRANSMISSION */
		}
	}
	deselect();

	return NumOfBlocks ? RES_ERROR : RES_OK;	/* Return result */
}


/**
  * @brief  Writes block(s) to a specified address in an SD card, in polling mode. 
  * @param  pData: Pointer to the buffer that will contain the data to transmit
  * @param  WriteAddr: Address from where data is to be written  
  * @param  BlockSize: SD card data block size, that should be 512
  * @param  NumOfBlocks: Number of SD blocks to write
  * @retval SD status
  */
//if(BSP_SD_WriteBlocks((uint32_t*)buff, (uint64_t)(sector * BLOCK_SIZE),  BLOCK_SIZE, count) != MSD_OK)
  
uint8_t BSP_SD_WriteBlocks(uint32_t *pData, uint64_t WriteAddr, uint32_t BlockSize, uint32_t NumOfBlocks)
{
  
	//FATFS_DEBUG_SEND_USART("disk_write: inside");
	if (!BSP_SD_IsDetected()) {
		return RES_ERROR;
	}
	//if (!TM_FATFS_WriteEnabled()) {
	//	FATFS_DEBUG_SEND_USART("disk_write: Write protected!!! \n---------------------------------------------");
	//	return RES_WRPRT;
	//}
	if (TM_FATFS_SD_Stat & STA_NOINIT) {
		return RES_NOTRDY;	/* Check drive status */
	}
	if (TM_FATFS_SD_Stat & STA_PROTECT) {
		return RES_WRPRT;	/* Check write protect */
	}

#if(0)
	if (!(TM_FATFS_SD_CardType & CT_BLOCK)) {
		sector *= 512;	/* LBA ==> BA conversion (byte addressing cards) */
	}
#endif
	if (NumOfBlocks == 1) {	/* Single sector write */
		if ((send_cmd(CMD24, WriteAddr) == 0)	/* WRITE_BLOCK */
			&& xmit_datablock((const BYTE *)pData, 0xFE, BlockSize))
			NumOfBlocks = 0;
	} else {				/* Multiple sector write */
		if (TM_FATFS_SD_CardType & CT_SDC) send_cmd(ACMD23, NumOfBlocks);	/* Predefine number of sectors */
		if (send_cmd(CMD25, WriteAddr) == 0) {	/* WRITE_MULTIPLE_BLOCK */
			do {
				if (!xmit_datablock((const BYTE *)pData, 0xFC, BlockSize)) {
					break;
				}
				pData += 512;
			} while (--NumOfBlocks);
			if (!xmit_datablock(0, 0xFD, BlockSize)) {	/* STOP_TRAN token */
				NumOfBlocks = 1;
			}
		}
	}
	deselect();

	return NumOfBlocks ? RES_ERROR : RES_OK;	/* Return result */
}


uint8_t BSP_SD_Ioctl(BYTE cmd, uint32_t *pData)
{
	DRESULT res;
	BYTE n, csd[16],data;
	DWORD csize;

	if (TM_FATFS_SD_Stat & STA_NOINIT) {
		return RES_NOTRDY;	/* Check if drive is ready */
	}
	if (!BSP_SD_IsDetected()) {
		return RES_NOTRDY;
	}

	res = RES_ERROR;

	switch (cmd) {
	case CTRL_SYNC :		/* Wait for end of internal write process of the drive */
		if (_select()) res = RES_OK;
		break;

	case GET_SECTOR_COUNT :	/* Get drive capacity in unit of sector (DWORD) */
        /* Read CSD */
		if ((send_cmd(CMD9, 0) == 0) && rcvr_datablock(csd, 16)) {
			if ((csd[0] >> 6) == 1) {	/* SDC ver 2.00 */
				csize = csd[9] + ((WORD)csd[8] << 8) + ((DWORD)(csd[7] & 63) << 16) + 1;
				*(DWORD*)pData = csize << 10;
			} else {					/* SDC ver 1.XX or MMC ver 3 */
				n = (csd[5] & 15) + ((csd[10] & 128) >> 7) + ((csd[9] & 3) << 1) + 2;
				csize = (csd[8] >> 6) + ((WORD)csd[7] << 2) + ((WORD)(csd[6] & 3) << 10) + 1;
				*(DWORD*)pData = csize << (n - 9);
			}
			res = RES_OK;
		}
		break;
        
    /* Get R/W sector size (WORD) */
    case GET_SECTOR_SIZE :
      *(WORD*)pData = BLOCK_SIZE;
      res = RES_OK;
      break;
        

	case GET_BLOCK_SIZE :	/* Get erase block size in unit of sector (DWORD) */
		if (TM_FATFS_SD_CardType & CT_SD2) 
        {  
            /* SDC ver 2.00 */
			if (send_cmd(ACMD13, 0) == 0) 
            {   /* Read SD status */
                data = 0xFF ; 
                HAL_SPI_Transmit(&SD_SPI, &data, 1, SD_MAX_RESP_TIME);
				if (rcvr_datablock(csd, 16)) 
                {               /* Read partial block */
					for (n = 64 - 16; n; n--) 
                        HAL_SPI_Transmit(&SD_SPI, &data, 1, SD_MAX_RESP_TIME);   /* Purge trailing data */
                    
					*(DWORD*)pData = 16UL << (csd[10] >> 4);
					res = RES_OK;
				}
			}
		} 
        else 
        {                   
            /* SDC ver 1.XX or MMC */
			if ((send_cmd(CMD9, 0) == 0) && rcvr_datablock(csd, 16)) 
            {   /* Read CSD */
				if (TM_FATFS_SD_CardType & CT_SD1) {	/* SDC ver 1.XX */
					*(DWORD*)pData = (((csd[10] & 63) << 1) + ((WORD)(csd[11] & 128) >> 7) + 1) << ((csd[13] >> 6) - 1);
				} 
                else {					/* MMC */
					*(DWORD*)pData = ((WORD)((csd[10] & 124) >> 2) + 1) * (((csd[11] & 3) << 3) + ((csd[11] & 224) >> 5) + 1);
				}
				res = RES_OK;
			}
		}
		break;

#if(0)
	case CTRL_ERASE_SECTOR :	/* Erase a block of sectors (used when _USE_ERASE == 1) */
		if (!(TM_FATFS_SD_CardType & CT_SDC)) break;				/* Check if the card is SDC */
		if (TM_FATFS_SD_disk_ioctl(MMC_GET_CSD, csd)) break;	/* Get CSD */
		if (!(csd[0] >> 6) && !(csd[10] & 0x40)) break;	/* Check if sector erase can be applied to the card */
		dp = buff; st = dp[0]; ed = dp[1];				/* Load sector block */
		if (!(TM_FATFS_SD_CardType & CT_BLOCK)) {
			st *= 512; ed *= 512;
		}
		if (send_cmd(CMD32, st) == 0 && send_cmd(CMD33, ed) == 0 && send_cmd(CMD38, 0) == 0 && wait_ready(30000))	/* Erase sector block */
			res = RES_OK;	/* FatFs does not check result of this command */
		break;
#endif

	default:
		res = RES_PARERR;
	}

	deselect();

	return res;
}

#endif /* USE_SPI_SDCARD */
/* USER CODE END 1 */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
