/**
  ******************************************************************************
  * File Name          : TIM.c
  * Description        : This file provides code for the configuration
  *                      of the TIM instances.
  ******************************************************************************
  *
  * COPYRIGHT(c) 2016 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "tim.h"

#include "gpio.h"
#include "debugmsgcli.h"

/* USER CODE BEGIN 0 */
#define TIMER4_PWM_PERIOD			2800
#define LOCAL_TIMER_PWM_MAX_PERIOD	255
/* USER CODE END 0 */

TIM_HandleTypeDef htim4;
uint32_t tim4_freq = TIMER4_PWM_PERIOD;
uint32_t chan1_pulse = (LOCAL_TIMER_PWM_MAX_PERIOD);
uint32_t chan2_pulse = (LOCAL_TIMER_PWM_MAX_PERIOD);
uint32_t chan3_pulse = (LOCAL_TIMER_PWM_MAX_PERIOD);

uint32_t Get_CalcedPeriod(uint32_t pulse)
{
	uint32_t calc_pulse;

	calc_pulse = (uint32_t)(pulse*(tim4_freq/255));
	return calc_pulse;
}
/* TIM4 init function */
void MX_TIM4_Init(void)
{
  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;
  TIM_OC_InitTypeDef sConfigOC;

  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 2;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = tim4_freq;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  HAL_TIM_Base_Init(&htim4);

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig);

  HAL_TIM_PWM_Init(&htim4);

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig);

  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = Get_CalcedPeriod(chan1_pulse);
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_ENABLE;
  HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_1);

  sConfigOC.Pulse = Get_CalcedPeriod(chan2_pulse);
  HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_2);

  sConfigOC.Pulse = Get_CalcedPeriod(chan3_pulse);
  HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_3);

}

void HAL_TIM_Base_MspInit(TIM_HandleTypeDef* htim_base)
{

  GPIO_InitTypeDef GPIO_InitStruct;
  if(htim_base->Instance==TIM4)
  {
  /* USER CODE BEGIN TIM4_MspInit 0 */

  /* USER CODE END TIM4_MspInit 0 */
    /* Peripheral clock enable */
    __TIM4_CLK_ENABLE();
  
    /**TIM4 GPIO Configuration    
    PD12     ------> TIM4_CH1
    PD13     ------> TIM4_CH2
    PD14     ------> TIM4_CH3 
    */
    GPIO_InitStruct.Pin = GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FAST;
    GPIO_InitStruct.Alternate = GPIO_AF2_TIM4;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /* USER CODE BEGIN TIM4_MspInit 1 */

  /* USER CODE END TIM4_MspInit 1 */
  }
}

void HAL_TIM_Base_MspDeInit(TIM_HandleTypeDef* htim_base)
{

  if(htim_base->Instance==TIM4)
  {
  /* USER CODE BEGIN TIM4_MspDeInit 0 */

  /* USER CODE END TIM4_MspDeInit 0 */
    /* Peripheral clock disable */
    __TIM4_CLK_DISABLE();
  
    /**TIM4 GPIO Configuration    
    PD12     ------> TIM4_CH1
    PD13     ------> TIM4_CH2
    PD14     ------> TIM4_CH3 
    */
    HAL_GPIO_DeInit(GPIOD, GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_14);

  }
  /* USER CODE BEGIN TIM4_MspDeInit 1 */

  /* USER CODE END TIM4_MspDeInit 1 */
} 

/* USER CODE BEGIN 1 */

/* TIM4 init function */

void Local_PWM_Period(uint32_t chan, uint32_t pulse)
{
  uint32_t temp = pulse, calc_pulse;
  TIM_OC_InitTypeDef sConfigOC;

  if(temp > LOCAL_TIMER_PWM_MAX_PERIOD) temp = LOCAL_TIMER_PWM_MAX_PERIOD;

  if(chan <= TIM_CHANNEL_3)
  {
	  //��LED Chnnel�� 0���� ���ϸ� �ƹ��� ���� �÷��� �������� �ʴ� �������� ���� reset���� 255�� ���Է��Ͽ� ����
	  Local_PWM_Period_Reset(chan);
	  sConfigOC.OCMode = TIM_OCMODE_PWM1;
	  //pulse �Է°��� 0-255�̹Ƿ� 255�϶� TIMER4_PWM_PERIOD���� �������� ����
	  //calc_pulse = (uint32_t)(temp*(tim4_freq/255));
	  calc_pulse = Get_CalcedPeriod(temp);
	  sConfigOC.Pulse = calc_pulse;
	  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
	  sConfigOC.OCFastMode = TIM_OCFAST_ENABLE;
	  HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, chan);
	  switch(chan)
	  {
		  case TIM_CHANNEL_1: chan1_pulse = temp; break;
		  case TIM_CHANNEL_2: chan2_pulse = temp; break;
		  case TIM_CHANNEL_3: chan3_pulse = temp; break;
		  default: break;
	  }
  }
}

void Local_TIM4_Init(uint32_t freq)
{
  uint32_t temp = freq;
  TIM_ClockConfigTypeDef sClockSourceConfig;
  TIM_MasterConfigTypeDef sMasterConfig;

  if(freq > 30) temp = 30;
  //���������� �����ϴ� ���� 2���Ϸ� �پ��� freq�̿��� ���� �� LED Chnnel�� 0���� �پ��� ���� ����
  else if(freq < 3) temp = 3;

  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 2;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  //freq �Է°��� 0-30�̹Ƿ� 30�϶� TIMER4_PWM_PERIOD���� �������� ����
  tim4_freq = (uint32_t)(temp*(TIMER4_PWM_PERIOD/30));
  htim4.Init.Period = tim4_freq;

  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  HAL_TIM_Base_Init(&htim4);

  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  HAL_TIM_ConfigClockSource(&htim4, &sClockSourceConfig);

  HAL_TIM_PWM_Init(&htim4);

  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig);

  //pulse �Է°��� 0-255�̹Ƿ� 255�϶� TIMER4_PWM_PERIOD���� �������� ����
	  Local_PWM_Period(TIM_CHANNEL_1, Get_CalcedPeriod(chan1_pulse));
	  Local_PWM_Period(TIM_CHANNEL_2, Get_CalcedPeriod(chan2_pulse));
	  Local_PWM_Period(TIM_CHANNEL_3, Get_CalcedPeriod(chan3_pulse));
}

void Tim4_PrintStatus(void)
{
	DBGHI(LED,"Tim4 Var: Freq = %d, Pulse = %d, %d, %d\r\n", tim4_freq,chan1_pulse,chan2_pulse,chan3_pulse);
}

uint32_t Local_PWM_Period_GET(uint32_t chan)
{
	uint32_t ret_val = 0;

	switch(chan)
	{
		case TIM_CHANNEL_1: ret_val = chan1_pulse; break;
		case TIM_CHANNEL_2: ret_val = chan2_pulse; break;
		case TIM_CHANNEL_3: ret_val = chan3_pulse; break;
		default: break;
	}
	return ret_val;
}

//LED reset funcion
void Local_PWM_Period_Reset(uint32_t chan)
{
	switch(chan)
	{
		case TIM_CHANNEL_1: chan1_pulse = LOCAL_TIMER_PWM_MAX_PERIOD; break;
		case TIM_CHANNEL_2: chan2_pulse = LOCAL_TIMER_PWM_MAX_PERIOD; break;
		case TIM_CHANNEL_3: chan3_pulse = LOCAL_TIMER_PWM_MAX_PERIOD; break;
		default: break;
	}
}
/* USER CODE END 1 */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
