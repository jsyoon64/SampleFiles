/**
  ******************************************************************************
  * File Name          : gpio.c
  * Description        : This file provides code for the configuration
  *                      of all used GPIO pins.
  ******************************************************************************
  *
  * COPYRIGHT(c) 2016 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "target.h"
#include "Cmsis_os.h"

#include "gpio.h"

/* USER CODE BEGIN 0 */
#include "command.h"
#include "signals.h"
#include "task_cfg.h"
#include "interrupt_conf.h"

/* USER CODE END 0 */

uint8_t HW_VERNO = 0;

/*----------------------------------------------------------------------------*/
/* Configure GPIO                                                             */
/*----------------------------------------------------------------------------*/
/* USER CODE BEGIN 1 */

/* USER CODE END 1 */

/** Configure pins as 
        * Analog 
        * Input 
        * Output
        * EVENT_OUT
        * EXTI
     PC8   ------> SDIO_D0
     PC9   ------> SDIO_D1
     PC10   ------> SDIO_D2
     PC11   ------> SDIO_D3
     PC12   ------> SDIO_CK
     PD2   ------> SDIO_CMD
*/
void MX_GPIO_Init(void)
{
    
  GPIO_InitTypeDef GPIO_InitStruct;

  /* GPIO Ports Clock Enable */
  __GPIOE_CLK_ENABLE();
  __GPIOC_CLK_ENABLE();
  __GPIOH_CLK_ENABLE();
  __GPIOA_CLK_ENABLE();
  __GPIOB_CLK_ENABLE();
  __GPIOD_CLK_ENABLE();

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = PW_CTRL_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_LOW;
  HAL_GPIO_Init(PW_CTRL_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = STA_LED_R_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_LOW;
  HAL_GPIO_Init(STA_LED_R_GPIO_Port, &GPIO_InitStruct);
  HAL_GPIO_WritePin(STA_LED_R_GPIO_Port,STA_LED_R_Pin, GPIO_PIN_SET); //Initial OFF

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = STA_LED_G_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_LOW;
  HAL_GPIO_Init(STA_LED_G_GPIO_Port, &GPIO_InitStruct);
  HAL_GPIO_WritePin(STA_LED_G_GPIO_Port,STA_LED_G_Pin, GPIO_PIN_SET); //Initial OFF

#if defined(SHINWOOHW)
  /*Configure GPIO pins : PBPin PBPin */
  GPIO_InitStruct.Pin = STA_LED_B_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_LOW;
  HAL_GPIO_Init(STA_LED_B_GPIO_Port, &GPIO_InitStruct);
  HAL_GPIO_WritePin(STA_LED_B_GPIO_Port,STA_LED_B_Pin, GPIO_PIN_SET); //Initial OFF

    /*Configure GPIO pins : AMP_SDZ_Pin */
  GPIO_InitStruct.Pin = AMP_SDZ_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_LOW;
  HAL_GPIO_Init(AMP_SDZ_GPIO_Port, &GPIO_InitStruct);
  //HAL_GPIO_WritePin(AMP_SDZ_GPIO_Port,AMP_SDZ_Pin, GPIO_PIN_SET);
#endif

// MP3
  // MP3 CS
  GPIO_InitStruct.Pin = MP3_CS_PIN;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_MEDIUM;
  HAL_GPIO_Init(MP3_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PEPin PEPin */
  GPIO_InitStruct.Pin = MP3_DCS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;//GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_MEDIUM;
  HAL_GPIO_Init(MP3_DCS_GPIO_Port, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = MP3_RESET_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN; //GPIO_PULLUP;//GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_MEDIUM;
  HAL_GPIO_Init(MP3_RESET_GPIO_Port, &GPIO_InitStruct);

#ifdef USE_MP3_DREQ_POLL
  /*Configure GPIO pins : PEPin PEPin */
  GPIO_InitStruct.Pin = MP3_DREQ_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;//GPIO_NOPULL;
  HAL_GPIO_Init(MP3_DREQ_GPIO_Port, &GPIO_InitStruct);
#else
  /*Configure GPIO pins : PEPin PEPin */
  GPIO_InitStruct.Pin = MP3_DREQ_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLUP;//GPIO_NOPULL;
  HAL_GPIO_Init(MP3_DREQ_GPIO_Port, &GPIO_InitStruct);

  HAL_NVIC_SetPriority(EXTI15_10_IRQn, RTOS_API_INTERRUPT_GROUP1, 0); /*!< EXTI Line10 Interrupt                                              */
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
#endif

  /*Configure GPIO pins : PEPin PEPin */
  GPIO_InitStruct.Pin = SD_DECT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(SD_DECT_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = EEG__DRDY_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;//GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(EEG__DRDY_GPIO_Port, &GPIO_InitStruct);

#ifdef SHINWOOHW
      HAL_NVIC_SetPriority(EXTI9_5_IRQn, RTOS_API_INTERRUPT_GROUP1, 0); /*!< EXTI Line8 Interrupt                                              */
      HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);
#elif defined (FRASENHW)
      HAL_NVIC_SetPriority(EXTI1_IRQn, RTOS_API_INTERRUPT_GROUP1, 0); /*!< EXTI Line1 Interrupt                                              */
      HAL_NVIC_EnableIRQ(EXTI1_IRQn);
#endif

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = EEG_START_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;//GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_MEDIUM;
  HAL_GPIO_Init(EEG_START_GPIO_Port, &GPIO_InitStruct);
  HAL_GPIO_WritePin(EEG_START_GPIO_Port,EEG_START_Pin, GPIO_PIN_RESET); //EEG_START= 0

  GPIO_InitStruct.Pin = EEG__PWD__RESET_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;//GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_MEDIUM;
  HAL_GPIO_Init(EEG__PWD__RESET_GPIO_Port, &GPIO_InitStruct);
  HAL_GPIO_WritePin(EEG__PWD__RESET_GPIO_Port,EEG__PWD__RESET_Pin,GPIO_PIN_SET); //ADS_RESET= 1

// PPG
  GPIO_InitStruct.Pin = PPG_CS_PIN;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
  HAL_GPIO_Init(PPG_CS_GPIO_Port, &GPIO_InitStruct);
  HAL_GPIO_WritePin(PPG_CS_GPIO_Port,PPG_CS_PIN, GPIO_PIN_SET); 

  GPIO_InitStruct.Pin = PPG__PDN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_MEDIUM;
  HAL_GPIO_Init(PPG__PDN_GPIO_Port, &GPIO_InitStruct);
  HAL_GPIO_WritePin(PPG__PDN_GPIO_Port,PPG__PDN_Pin, GPIO_PIN_SET); 

  GPIO_InitStruct.Pin = PPG__RESET_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_MEDIUM;
  HAL_GPIO_Init(PPG__RESET_GPIO_Port, &GPIO_InitStruct);
  HAL_GPIO_WritePin(PPG__RESET_GPIO_Port,PPG__RESET_Pin, GPIO_PIN_RESET); 

  /*Configure GPIO pins : PDPin PDPin */
  GPIO_InitStruct.Pin = PPG_DIAG_END_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(PPG_DIAG_END_GPIO_Port, &GPIO_InitStruct);

#if defined(SHINWOOHW)
  GPIO_InitStruct.Pin = ACCE_INT1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(ACCE_INT1_GPIO_Port, &GPIO_InitStruct);
#endif

  /*Configure GPIO pins : PCPin PCPin */
  GPIO_InitStruct.Pin = PPG_LED_ALM_Pin|PPG_PD_ALM_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);


// move to emmc_sdio
//#if defined(USE_EMMC_SD)
#if (0)
  /*Configure GPIO pins : PC8 PC9 PC10 PC11 
                           PC12 */
  GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11 /*|GPIO_PIN_12*/;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF12_SDIO;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  // EMMC_CMD
  /* Configure PD.2 pin: CMD pin */
  GPIO_InitStruct.Pin = GPIO_PIN_2;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  // EMMC CLK
  /* Configure PC.12 pin: CLK pin */
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Pin = GPIO_PIN_12;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
#endif

#if 0
  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = EMMC__RESET_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_LOW;
  HAL_GPIO_Init(EMMC__RESET_GPIO_Port, &GPIO_InitStruct);
#endif

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = TEMP_DRDY_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(TEMP_DRDY_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = USB_ID_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(USB_ID_GPIO_Port, &GPIO_InitStruct);

#if 0
#if defined(SHINWOOHW)
  /*Configure GPIO pin : PD2 */
  GPIO_InitStruct.Pin = GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF12_SDIO;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
#endif
#endif

  // EEG CS
  GPIO_InitStruct.Pin = EEG_CS_PIN;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
  HAL_GPIO_Init(EEG_CS_GPIO_Port, &GPIO_InitStruct);
  HAL_GPIO_WritePin(EEG_CS_GPIO_Port,EEG_CS_PIN, GPIO_PIN_SET); 

  // SD CS
  GPIO_InitStruct.Pin = SD__CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;//GPIO_SPEED_LOW;
  HAL_GPIO_Init(SD__CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = PPG_ADC_RDY_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(PPG_ADC_RDY_GPIO_Port, &GPIO_InitStruct);

#ifdef SHINWOOHW
        HAL_NVIC_SetPriority(EXTI9_5_IRQn, RTOS_API_INTERRUPT_GROUP1, 0); /*!< EXTI Line6 Interrupt                                              */
        HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);
#elif defined (FRASENHW)
        HAL_NVIC_SetPriority(EXTI2_IRQn, RTOS_API_INTERRUPT_GROUP1, 0); /*!< EXTI Line2 Interrupt                                              */
        HAL_NVIC_EnableIRQ(EXTI2_IRQn);
#endif

  /*Configure GPIO pin : PtPin */
  GPIO_InitStruct.Pin = KEY_PWR_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(KEY_PWR_GPIO_Port, &GPIO_InitStruct);

#ifdef SHINWOOHW
    HAL_NVIC_SetPriority(EXTI1_IRQn, RTOS_API_INTERRUPT_GROUP1, 0); /*!< EXTI Line1 Interrupt                                              */
    HAL_NVIC_EnableIRQ(EXTI1_IRQn);
#elif defined (FRASENHW)
    HAL_NVIC_SetPriority(EXTI3_IRQn, RTOS_API_INTERRUPT_GROUP1, 0); /*!< EXTI Line3 Interrupt                                              */
    HAL_NVIC_EnableIRQ(EXTI3_IRQn);
#endif


/*Configure GPIO pin : TMODE_Pin */
  GPIO_InitStruct.Pin = TMODE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(TMODE_GPIO_Port, &GPIO_InitStruct);


/* BLE Module Reset GPIO Define */
  GPIO_InitStruct.Pin = BLE_RST_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(BLE_RST_GPIO_Port, &GPIO_InitStruct);

/* H/W Version ID Pin Define */
  GPIO_InitStruct.Pin = HW_ID_0_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(HW_ID_0_GPIO_Port, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = HW_ID_1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(HW_ID_1_GPIO_Port, &GPIO_InitStruct);

/* USB_DET Pin Define */
  GPIO_InitStruct.Pin = USB_DET_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(USB_DET_GPIO_Port, &GPIO_InitStruct);

  HAL_NVIC_SetPriority(EXTI3_IRQn, RTOS_API_INTERRUPT_GROUP1, 0); /*!< EXTI Line3 Interrupt                                              */
  HAL_NVIC_EnableIRQ(EXTI3_IRQn);

/* CHG_CTRL Pin Define */
  GPIO_InitStruct.Pin = CHG_CTRL_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;//GPIO_MODE_OUTPUT_OD;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(CHG_CTRL_GPIO_Port, &GPIO_InitStruct);

  // EMMC Clock
#if(1)  
  {
    /*Configure GPIO pins : PC8 PC9 PC10 PC11 
                             PC12 */
    GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11 |GPIO_PIN_12;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
    GPIO_InitStruct.Alternate = GPIO_AF12_SDIO;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    // EMMC_CMD
    /* Configure PD.2 pin: CMD pin */
    GPIO_InitStruct.Pin = GPIO_PIN_2;
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

    /*Configure GPIO pin : PtPin */
    GPIO_InitStruct.Pin = EMMC__RESET_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    GPIO_InitStruct.Speed = GPIO_SPEED_HIGH;
    HAL_GPIO_Init(EMMC__RESET_GPIO_Port, &GPIO_InitStruct);  

    HAL_GPIO_WritePin(EMMC__RESET_GPIO_Port,EMMC__RESET_Pin,GPIO_PIN_SET);
  }
#endif
}

/* USER CODE BEGIN 2 */

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin, portBASE_TYPE *xHigherPriorityTaskWoken)
{
	command_type	cmd;

	cmd.len = 0;
	cmd.msg = NULL;

	switch(GPIO_Pin)
	{
		case KEY_PWR_Pin:
			cmd.cmd = PWR_KEY_PRESSED_EVT;
			xQueueSendFromISR(xMcTaskQueue,&cmd,xHigherPriorityTaskWoken);
			break;

		case EEG__DRDY_Pin:
			cmd.cmd = EEG_DATA_READY_EVT;
			xQueueSendFromISR(xSensorTaskQueue,&cmd,xHigherPriorityTaskWoken);
			break;

		case PPG_ADC_RDY_Pin:
			cmd.cmd = PPG_DATA_READY_EVT;
			xQueueSendFromISR(xSensorTaskQueue,&cmd,xHigherPriorityTaskWoken);
			break;

#ifndef USE_MP3_DREQ_POLL
		case MP3_DREQ_Pin:
			cmd.cmd = MP3_DREQ_OCCURRED_EVT;
			xQueueSendFromISR(xMp3TaskQueue,&cmd,xHigherPriorityTaskWoken);
			break;
#endif

		case USB_DET_Pin:
            if( HAL_GPIO_ReadPin(USB_DET_GPIO_Port,USB_DET_Pin) == GPIO_PIN_SET)
            {
			    cmd.cmd = MC_EXTPWR_IN_EVT;
            }
            else
            {
			    cmd.cmd = MC_EXTPWR_OUT_EVT;
            }                
			xQueueSendFromISR(xMcTaskQueue,&cmd,xHigherPriorityTaskWoken);
			break;

		default: 
            break;
	}
}

/* USER CODE END 2 */


/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
