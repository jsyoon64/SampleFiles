/*===============================================================================================*/
/**
 *   @file mcdata.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "comdef.h"
#include "signals.h"
#include "command.h"
#include "task_cfg.h"
#include "interface.h"
#include "mc_data.h"
#include "mc_process.h"
#include "vs1011e.h"
#include "fat_api.h"
#include "tim.h"


/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/

#define MAX_STATUS_ARRAY_SIZ    50

/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/

// Result data storage
//static ble_packet_msg_field_type current_status;
static uint8_t current_status[MAX_STATUS_ARRAY_SIZ];
//uint8_t CurrentOperationMode = IDLE_MODE;
uint8_t CurrentOperationMode = DEMO_MODE;

boolean IsCharging = FALSE;
boolean IsExtPwrInState = FALSE;

/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/

/*===========================================================================
FUNCTION           
DESCRIPTION     
DEPENDENCIES
RETURN VALUE
===========================================================================*/
void mcdata_update_fft_result(command_type *cmd)
{
    uint8_t * data = (uint8_t *)cmd->msg;

    memcpy(&current_status[FDPOS(ble_packet_msg_field_type,Heart_Rate)],
           &data[FDPOS(fft_result_resp_field_type,Heart_Rate)],
            FDSIZ(fft_result_resp_field_type,Heart_Rate));

    memcpy(&current_status[FDPOS(ble_packet_msg_field_type,SpO2)],
           &data[FDPOS(fft_result_resp_field_type,SpO2)],
           FDSIZ(fft_result_resp_field_type,SpO2));

    memcpy(&current_status[FDPOS(ble_packet_msg_field_type,bDelta)],
           &data[FDPOS(fft_result_resp_field_type,bDelta)],
           FDSIZ(fft_result_resp_field_type,bDelta));
    
    memcpy(&current_status[FDPOS(ble_packet_msg_field_type,bTheta)],
           &data[FDPOS(fft_result_resp_field_type,bTheta)],
           FDSIZ(fft_result_resp_field_type,bTheta));
    
    memcpy(&current_status[FDPOS(ble_packet_msg_field_type,bAlpha)],
           &data[FDPOS(fft_result_resp_field_type,bAlpha)],
           FDSIZ(fft_result_resp_field_type,bAlpha));
    
    memcpy(&current_status[FDPOS(ble_packet_msg_field_type,bBeta)],
           &data[FDPOS(fft_result_resp_field_type,bBeta)],
           FDSIZ(fft_result_resp_field_type,bBeta));

}


void mcdata_update_sensor_result(command_type *cmd)
{
    uint8_t * data = (uint8_t *)cmd->msg;

    memcpy(&current_status[FDPOS(ble_packet_msg_field_type,DevContact)],
           &data[FDPOS(sensor_status_field_type,DevContact)],
            FDSIZ(sensor_status_field_type,DevContact));

    memcpy(&current_status[FDPOS(ble_packet_msg_field_type,Sensor_status)],
           &data[FDPOS(sensor_status_field_type,Sensor_status)],
            FDSIZ(sensor_status_field_type,Sensor_status));

    memcpy(&current_status[FDPOS(ble_packet_msg_field_type,EDA_Value)],
           &data[FDPOS(sensor_status_field_type,EDA_Value)],
           FDSIZ(sensor_status_field_type,EDA_Value));

    memcpy(&current_status[FDPOS(ble_packet_msg_field_type,AcceXValue)],
           &data[FDPOS(sensor_status_field_type,AcceXValue)],
           FDSIZ(sensor_status_field_type,AcceXValue));

	memcpy(&current_status[FDPOS(ble_packet_msg_field_type,AcceYValue)],
           &data[FDPOS(sensor_status_field_type,AcceYValue)],
           FDSIZ(sensor_status_field_type,AcceYValue));

	memcpy(&current_status[FDPOS(ble_packet_msg_field_type,AcceZValue)],
           &data[FDPOS(sensor_status_field_type,AcceZValue)],
           FDSIZ(sensor_status_field_type,AcceZValue));
    
    memcpy(&current_status[FDPOS(ble_packet_msg_field_type,BatteryStatus)],
           &data[FDPOS(sensor_status_field_type,BatteryStatus)],
           FDSIZ(sensor_status_field_type,BatteryStatus));
    
    memcpy(&current_status[FDPOS(ble_packet_msg_field_type,MicPeak)],
           &data[FDPOS(sensor_status_field_type,MicPeak)],
           FDSIZ(sensor_status_field_type,MicPeak));
    
    memcpy(&current_status[FDPOS(ble_packet_msg_field_type,Temp)],
           &data[FDPOS(sensor_status_field_type,Temp)],
           FDSIZ(sensor_status_field_type,Temp));

    memcpy(&current_status[FDPOS(ble_packet_msg_field_type,AmbientLight)],
           &data[FDPOS(sensor_status_field_type,LightSensor)],
           FDSIZ(sensor_status_field_type,LightSensor));
}

void mcdata_update_mp3_result(command_type *cmd)
{
	uint8_t * data = (uint8_t *)cmd->msg;
	
	memcpy(&current_status[FDPOS(ble_packet_msg_field_type,Mp3_Index)],
		   &data[FDPOS(mp3_current_status_field_type,Mp3_Index)],
		   FDSIZ(ble_packet_msg_field_type,Mp3_Index));
		   
	memcpy(&current_status[FDPOS(ble_packet_msg_field_type,Mp3_SetVolume)],
		   &data[FDPOS(mp3_current_status_field_type,Mp3_SetVolume)],
		   FDSIZ(ble_packet_msg_field_type,Mp3_SetVolume));
}

void mcdata_update_ble_result(command_type *cmd)
{
    uint8_t * data = (uint8_t *)cmd->msg;

    if(cmd->cmd == LED_BRIGHT_F)
    {
        uint8_t	  index = data[FDPOS(gen_cmd_msg_field_type,data3)];
        uint8_t	  bright = data[FDPOS(gen_cmd_msg_field_type,data2)];
        int8_t	  targetindex=-1;
        uint32_t  Sindex = (uint32_t) index;

        switch(Sindex)
        {
        	case TIM_CHANNEL_1:
        		targetindex = 0;
        		break;

        	case TIM_CHANNEL_2:
        	    targetindex = 1;
        	    break;

        	case TIM_CHANNEL_3:
        	    targetindex = 2;
        	    break;

        	default:
        		break;
        }

        if( ( targetindex >= 0) && (targetindex < 3))
        {
			memcpy(&current_status[FDPOS(ble_packet_msg_field_type,ledBrightness) + targetindex],
				   &bright,
				   FDSIZ(gen_cmd_msg_field_type,data3));
        }
    }

}

uint8_t mcdata_set_current_mode(uint8_t mode)
{
   
    if( mode < MODE_MAX)
    {
        current_status[FDPOS(ble_packet_msg_field_type,OperMode)] = mode;
        CurrentOperationMode = mode;
    }
    return CurrentOperationMode;
}


void mcdata_send2bletask(void)
{
    mcprocessSendData2Ble(BLE_SEND_F, &current_status[0], FDPOS(ble_packet_msg_field_type,EndofData), TRUE);
}

void mcdata_init(void)
{
	uint8_t temp;

    memset(current_status,0x00,MAX_STATUS_ARRAY_SIZ);  
    current_status[FDPOS(ble_packet_msg_field_type,OperMode)] = CurrentOperationMode;

    temp = (uint8_t) Local_PWM_Period_GET(TIM_CHANNEL_1);
    current_status[FDPOS(ble_packet_msg_field_type,ledBrightness)] = temp;

    temp = (uint8_t) Local_PWM_Period_GET(TIM_CHANNEL_2);
    current_status[FDPOS(ble_packet_msg_field_type,ledBrightness) + 1] = temp;

    temp = (uint8_t) Local_PWM_Period_GET(TIM_CHANNEL_3);
    current_status[FDPOS(ble_packet_msg_field_type,ledBrightness) + 2] = temp;
}

/*===============================================================================================*/
