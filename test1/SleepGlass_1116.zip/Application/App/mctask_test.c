/*===============================================================================================*/
/**
 *   @file mctask_test.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "comdef.h"
#include "signals.h"
#include "command.h"
#include "task_cfg.h"
#include "mctask_state.h"
#include "debugmsgcli.h"
#include "interface.h"
#include "mc_data.h"
#include "mc_process.h"

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/
    
// init state
typedef enum
{
    TEST_ENTRY = MCSTATE_TEST,
    TEST_HANDLE,
    TEST_EXIT,
    NO_STATE
} mctask_test_state_type;
    

/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/

/*===========================================================================
FUNCTION           
DESCRIPTION     
DEPENDENCIES
RETURN VALUE
===========================================================================*/
uint16_t mc_test_state ( command_type *cmdptr )
{
    uint16_t new_state; /* new state if any */
    uint16_t ret_state; /* return state */
    uint8_t  *cmdmsg = (uint8_t*)cmdptr->msg;
    uint8_t blecmd = cmdmsg[FDPOS(gen_cmd_msg_field_type,data2)];
    
    ret_state = MCSTATE_NOSTATE;    /* don't assume a return state */
    new_state = mctask_state;

    while ( new_state != NO_STATE )
    {
        mctask_state = new_state;
        new_state = NO_STATE;

        switch ( mctask_state )
        {
            case TEST_ENTRY :
                mcdata_set_current_mode(IDLE_MODE);
                
                mcprocessSendCmd2Led(MC_MODE_TEST_MODE_F);
                mcprocessSendCmd2Mp3(MC_MODE_TEST_MODE_F);
                mcprocessSendCmd2Sensor(MC_MODE_TEST_MODE_F);
                
                xTimerStart(xmcPeriodicRptTimer, 0);
                
                mctask_state = TEST_HANDLE ;
                break;

            case TEST_HANDLE :
                switch ( cmdptr->cmd )
                {
                    case SENSOR_MASK_WORN_EVT:
                        //ret_state = MCSTATE_STANDBY;
                        cmdptr->cmd = 0;
                        break;

                    case MC_PERIODIC_RPT_TIMER_F:
                        //mcprocessSendCmd2Sensor(SENSOR_DATA_REQ_F);
                        //xTimerStart(xmcPeriodicRptTimer, 0);
                        DBGHI(MC,"Periodic Report timer fired!\r\n");
                        break;

                    case MC_MODE_CHG_F:
                        {
                            uint16_t processState;
                            
                            processState = mcProcessModechgF(cmdptr->cmd, blecmd);
                            if(processState != MCSTATE_TEST)
                            {
                                ret_state = processState;
                            }
                        }
                        cmdptr->cmd = 0;
                        break;
                        
                    default:
                        break;
                }
                cmdptr->cmd = 0;
                break;

            case TEST_EXIT:
                break;

                
            default :
                DBGERR ( MC, "bad test state = 0x%x, cmd = 0x%x\n", mctask_state, cmdptr->cmd );
                cmdptr->cmd = 0;
                break;
        }
    }

    return ret_state;
}


/*===============================================================================================*/
