/*===============================================================================================*/
/**
 *   @file mctask_state.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "signals.h"
#include "command.h"
#include "task_cfg.h"
#include "mctask_state.h"
#include "debugmsgcli.h"


/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/
uint16_t    mctask_state = MCSTATE_IDLE; //MCSTATE_DEMO;

uint16_t    mcStandbyWaitTime = DEFAULT_STANDBY_WAIT_TIME;
/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/

uint16_t mcSetStandbyWaitTime(uint8_t time)
{
    mcStandbyWaitTime = (uint16_t)((uint16_t)time * 1000);
    return mcStandbyWaitTime;
}

/*===========================================================================
FUNCTION           
DESCRIPTION     
DEPENDENCIES
RETURN VALUE
===========================================================================*/
void mctask_state_machine (command_type *cmdptr)
{
    uint16_t  new_state;

    do
    {
        new_state = MCSTATE_NOSTATE;

        switch ( MCSTATE_STATE( mctask_state) )
        {
            case MCSTATE_MASS :
                new_state = mc_mass_state ( cmdptr );        /* Process the mass storage state */
                break;

            case MCSTATE_IDLE :
                new_state = mc_idle_state ( cmdptr );        /* Process the idle state */
                break;

            case MCSTATE_STANDBY :
                new_state = mc_standby_state ( cmdptr );        /* Process the standby state */
                break;

            case MCSTATE_START :
                new_state = mc_start_state ( cmdptr );        /* Process the start state */
                break;

            case MCSTATE_DEMO :
                new_state = mc_demo_state ( cmdptr );        /* Process the demo state */
                break;

            case MCSTATE_TEST :
                new_state = mc_test_state ( cmdptr );        /* Process the test state */
                break;

            default:
                DBGERR(MC, "bad state = 0x%x, cmd = 0x%x\n", mctask_state, cmdptr->cmd );
                new_state = MCSTATE_NOSTATE;
                break;
        }

        if ( new_state != MCSTATE_NOSTATE )
        {
            mctask_state = new_state;
        }

    } while ( new_state != MCSTATE_NOSTATE );
}


/*===============================================================================================*/
