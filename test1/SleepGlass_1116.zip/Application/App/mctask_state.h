#ifndef MCTASK_STATE_H_
#define MCTASK_STATE_H_
/*===============================================================================================*/
/**
 *   @file mctask_state.h
 *
 *   @version v1.0
 */
/*=================================================================================================


Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------


===================================================================================================*/
/* Standard includes. */

/* Scheduler include files. */
#include "FreeRTOS.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "queue.h"
#include "task.h"
#include "timers.h"

/* Application include files. */
#include "command.h"


/*=================================================================================================
 CONSTANTS
=================================================================================================*/
/* MCTASK main states */

#define MCSTATE_MASS        0x0100
#define MCSTATE_IDLE       	0x0200
#define MCSTATE_STANDBY		0x0300
#define MCSTATE_START		0x0400
#define MCSTATE_DEMO		0x0500
#define MCSTATE_TEST		0x0600

#define MCSTATE_NOSTATE    	0xFF00
#define MCSTATE_EXIT       	0xFF00
    
#define MCSTATE_STATE(state)    (state & 0xFF00 )


#define DEFAULT_STANDBY_WAIT_TIME 10000

extern uint16_t mctask_state;
extern TimerHandle_t xmcTimergen;
extern TimerHandle_t xmcPeriodicRptTimer;

extern uint16_t mcStandbyWaitTime;


/*=================================================================================================
 FUNCTION PROTOTYPES
=================================================================================================*/

void mctask_state_machine ( command_type *cmdptr);
uint16_t mc_mass_state ( command_type *cmdptr);
uint16_t mc_idle_state ( command_type *cmdptr);
uint16_t mc_standby_state ( command_type *cmdptr);
uint16_t mc_start_state ( command_type *cmdptr);
uint16_t mc_demo_state ( command_type *cmdptr);
uint16_t mc_test_state ( command_type *cmdptr);


uint16_t mcSetStandbyWaitTime(uint8_t time);

/*===============================================================================================*/
#endif  /* MCTASK_STATE_H_ */
