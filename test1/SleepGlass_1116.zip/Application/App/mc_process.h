#ifndef MC_PROCESS_H_
#define MC_PROCESS_H_
/*===============================================================================================*/
/**
 *   @file mc_process.h
 *
 *   @version v1.0
 */
/*=================================================================================================


Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------


===================================================================================================*/
/* Standard includes. */
#include "target.h"
#include "command.h"

/* Scheduler include files. */

/* Application include files. */

/*=================================================================================================
 CONSTANTS
=================================================================================================*/

typedef enum {
    POWER_NORMAL,
    POWER_CHARGE,
    POWER_FULL,
    POWER_LOWBATT,
    POWER_MAX
} main_power_state_type;



/*=================================================================================================
 FUNCTION PROTOTYPES
=================================================================================================*/
void sendMcCommand(uint16_t command);
void sendFftReqCmd2FFTTASK(command_type *command);
void mcprocessSendCmd2Sensor(uint16_t signal);
void mcprocessSendData2Ble(uint16_t signal, uint8_t *data, uint16_t len, boolean isconst);
void mcprocessSendCmd2Mp3(uint16_t signal);
void mcprocessSendCmd2Led(uint16_t signal);
void mcprocessSendCmd2Fft(uint16_t signal);


boolean CheckFromBLEMP3Cmd(command_type *cmd);
boolean CheckFromBLELEDCmd(command_type *command);
boolean CheckFromSENSORCmd(command_type *cmd);
uint16_t mcProcessModechgF(uint16_t cmd, uint8_t data);

/*===============================================================================================*/
#endif  /* MC_PROCESS_H_ */
