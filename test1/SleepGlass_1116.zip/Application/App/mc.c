/*
        1 tab == 4 spaces!
*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */
//#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>


/* Scheduler include files. */
#include "FreeRTOS.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "queue.h"
#include "task.h"

/* Application include files. */
#include "command.h"
#include "signals.h"
#include "consol.h"
#include "task_cfg.h"
#include "timers.h"
#include "timergen.h"
#include "debugmsgcli.h"
#include "mccli.h"
#include "mc_data.h"
#include "mc_process.h"
#include "mctask_state.h"

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/
/* The task that is created eight times - each time with a different xLEDParaemtes 
structure passed in as the parameter. */
static void vMCTask( void *pvParameters );


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/

#define mcTIMER_QUEUE_LENGTH 20


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/

static QueueHandle_t xmcTimerQueue;

static uint16_t pwrKeyCount=0;


/*-----------------------------------------------------------*/
/* The handle of the queue set to which the queues are added. */
static QueueSetHandle_t xQueueSet;

TimerHandle_t xmcTimergen = NULL;
TimerHandle_t xmcPwrKeyCheckTimer = NULL;
TimerHandle_t xmcPeriodicRptTimer = NULL;
/*-----------------------------------------------------------*/

/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/

static void prvmcTimerCallback( TimerHandle_t pxExpiredTimer )
{
    uint32_t ulTimerID;

    portENTER_CRITICAL();
	ulTimerID = ( uint32_t ) pvTimerGetTimerID( pxExpiredTimer );
	xQueueSend(xmcTimerQueue,&ulTimerID,0);
    portEXIT_CRITICAL();
}
/*-----------------------------------------------------------*/

void check_pwronstate()
{
#ifdef MASS_DEBUG
    HAL_GPIO_WritePin(PW_CTRL_GPIO_Port, PW_CTRL_Pin, GPIO_PIN_SET);
    vTaskDelay( 100); // Delay 100msec
#else
    uint16_t    loop_count=0;

	for(;;)
	{
		if( HAL_GPIO_ReadPin(KEY_PWR_GPIO_Port,KEY_PWR_Pin) == GPIO_PIN_SET)
		{
            if(loop_count >=5)
            {
                HAL_GPIO_WritePin(PW_CTRL_GPIO_Port, PW_CTRL_Pin, GPIO_PIN_SET);
    			break;
            }
            loop_count++;
		}
        else
        {
            #ifdef USB_PWR_AUTO_ON
                if(loop_count >=2)
                {
                    HAL_GPIO_WritePin(PW_CTRL_GPIO_Port, PW_CTRL_Pin, GPIO_PIN_SET);
                    break;
                }
                loop_count++;
            #endif
        }
		vTaskDelay( 100); // Delay 100msec
	}
#endif    
}

/*-----------------------------------------------------------*/
boolean check_pwroffstate(void)
{
	if( HAL_GPIO_ReadPin(KEY_PWR_GPIO_Port,KEY_PWR_Pin) == GPIO_PIN_SET)
	{
		if( pwrKeyCount++ > 4) // 3sec
		{
			return TRUE;
		}

		/* Restart the xmcPwrKeyCheckTimer. */
		xTimerStart( xmcPwrKeyCheckTimer, 0 );
	}
	else
	{
		pwrKeyCount = 0;
	}
	return FALSE;
}

/*-----------------------------------------------------------*/
void sendTaskStartSignal()
{
	command_type	cmd;

    portENTER_CRITICAL();
	cmd.len = 0;
	cmd.msg = NULL;
    cmd.isconst = FALSE;

#if (DEFAULT_USB_DEVICE != 2)
	cmd.cmd = MP3_TASK_START_CMD_F;
	xQueueSend(xMp3TaskQueue,&cmd,taskNO_BLOCK);
#endif

	cmd.cmd = BLE_TASK_START_CMD_F;
	xQueueSend(xBleTaskQueue,&cmd,taskNO_BLOCK);
	
	cmd.cmd = FFT_TASK_START_CMD_F;
	xQueueSend(xFftTaskQueue,&cmd,taskNO_BLOCK);

#if (DEFAULT_USB_DEVICE != 2)
	cmd.cmd = SENSOR_TASK_START_CMD_F;
	xQueueSend(xSensorTaskQueue,&cmd,taskNO_BLOCK);
#endif

	cmd.cmd = LED_TASK_START_CMD_F;
	xQueueSend(xLedTaskQueue,&cmd,taskNO_BLOCK);
    portEXIT_CRITICAL();
}

/*-----------------------------------------------------------*/
void sendSTOPandPowerOFF(void)
{
	command_type	cmd;

    portENTER_CRITICAL();
	cmd.len = 0;
	cmd.msg = NULL;
    cmd.isconst = FALSE;

	cmd.cmd = MP3_TASK_STOP_F;
	xQueueSend(xMp3TaskQueue,&cmd,taskNO_BLOCK);
	vTaskDelay( 5);

	cmd.cmd = BLE_TASK_STOP_F;
	xQueueSend(xBleTaskQueue,&cmd,taskNO_BLOCK);
	vTaskDelay( 5);
	
	cmd.cmd = FFT_TASK_STOP_F;
	xQueueSend(xFftTaskQueue,&cmd,taskNO_BLOCK);
	vTaskDelay( 5);

	cmd.cmd = SENSOR_TASK_STOP_F;
	xQueueSend(xSensorTaskQueue,&cmd,taskNO_BLOCK);
	vTaskDelay( 5);

	cmd.cmd = LED_TASK_STOP_F;
	xQueueSend(xLedTaskQueue,&cmd,taskNO_BLOCK);
	vTaskDelay( 5);
    portEXIT_CRITICAL();

	vTaskDelay( 500); // Delay 3sec
	
    HAL_GPIO_WritePin(PW_CTRL_GPIO_Port, PW_CTRL_Pin, GPIO_PIN_RESET);
    // Power OFF
}
        

/*-----------------------------------------------------------*/
void mctask_init()
{
	mcCLIregister();

	check_pwronstate();

	sendTaskStartSignal();

    mcdata_init();
}

boolean CheckTestModePin(void)
{
    uint16_t    MaxRetryCount=0;
    boolean     retval = FALSE;
    #define     MAXRETRYCOUNT   5

    if(HAL_GPIO_ReadPin(TMODE_GPIO_Port,TMODE_Pin) == GPIO_PIN_RESET)
    {
        do
        {
            vTaskDelay( 10 );
            if(HAL_GPIO_ReadPin(TMODE_GPIO_Port,TMODE_Pin) != GPIO_PIN_RESET)
                break;
        }while( ++MaxRetryCount < MAXRETRYCOUNT);

        if(MaxRetryCount >= MAXRETRYCOUNT)
            retval = TRUE;
    }

    return retval;
}

/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/
void vStartMCTasks( void )
{
	/*First Create the queue set such that it will be able to hold a message for
	every space in every queue in the set. */
	xQueueSet = xQueueCreateSet( taskMC_QUEUE_LENGTH + mcTIMER_QUEUE_LENGTH );

	/* Create the queue that we are going to use for the
	prvSendFrontAndBackTest demo. */
	xMcTaskQueue = xQueueCreate( taskMC_QUEUE_LENGTH, sizeof( command_type ) );
	xmcTimerQueue = xQueueCreate( mcTIMER_QUEUE_LENGTH, sizeof( uint32_t ) );

	/* vQueueAddToRegistry() adds the queue to the queue registry, if one is
	in use.  The queue registry is provided as a means for kernel aware
	debuggers to locate queues and has no purpose if a kernel aware debugger
	is not being used.  The call to vQueueAddToRegistry() will be removed
	by the pre-processor if configQUEUE_REGISTRY_SIZE is not defined or is
	defined to be less than 1. */
	//vQueueAddToRegistry( xMcTaskQueue, "MC_Queue" );
	//vQueueAddToRegistry( xmcTimerQueue, "MC_Queue" );

	xQueueAddToSet( xMcTaskQueue, xQueueSet );//vQueueAddToRegistry( xPrintQueue, "CLI_Queue" );
	xQueueAddToSet( xmcTimerQueue, xQueueSet );


	/* Create a one-shot timer for use later on in this test. */
	xmcTimergen = xTimerCreate(	"",				/* Text name to facilitate debugging.  The kernel does not use this itself. */
								1000,					/* The period for the timer(1 sec). */
								pdFALSE,				/* Don't auto-reload - hence a one shot timer. */
								( void * )MC_TIMER_GEN_F,	/* The timer identifier. */
								prvmcTimerCallback );	/* The callback to be called when the timer expires. */

	/* Create a one-shot timer for use later on in this test. */
	xmcPwrKeyCheckTimer = xTimerCreate(	"",		/* Text name to facilitate debugging.  The kernel does not use this itself. */
								500,					/* The period for the timer(500 msec). */
								pdFALSE,				/* Don't auto-reload - hence a one shot timer. */
								( void * )MC_PWR_KEY_CHECK_TIMER_F,	/* The timer identifier. */
								prvmcTimerCallback );	/* The callback to be called when the timer expires. */

	/* Create a one-shot timer for use later on in this test. */
	xmcPeriodicRptTimer = xTimerCreate(	"",				/* Text name to facilitate debugging.  The kernel does not use this itself. */
								2000,					/* The period for the timer(1 sec). */
								pdFALSE,				/* Don't auto-reload - hence a one shot timer. */
								( void * )MC_PERIODIC_RPT_TIMER_F,	/* The timer identifier. */
								prvmcTimerCallback );	/* The callback to be called when the timer expires. */


	/* Spawn the task. */
	//xTaskCreate( vMCTask, "MCx", taskMC_TASK_STACK_SIZE, xMcTaskQueue, taskMC_TASK_PRIORITY, ( TaskHandle_t * ) NULL );
	xTaskCreate( vMCTask, "MCx", taskMC_TASK_STACK_SIZE, xQueueSet, taskMC_TASK_PRIORITY, ( TaskHandle_t * ) NULL );

}


/*-----------------------------------------------------------*/


static void vMCTask( void *pvParameters )
{
	//QueueHandle_t   xQueue;		// mctask�� queue �ϳ��� ��� �Ҷ�
	QueueSetMemberHandle_t  xQueue;
	QueueSetMemberHandle_t	xActivatedMember;
	command_type	        cmd;
    uint32_t                timerid;
    boolean                 isprocessed = FALSE;

	xQueue = ( QueueHandle_t * ) pvParameters;

	mctask_init();

    if(HAL_GPIO_ReadPin(USB_DET_GPIO_Port,USB_DET_Pin) == GPIO_PIN_SET)
    {
        IsExtPwrInState = TRUE;
    }

    if( CheckTestModePin() == TRUE)
    {
        mctask_state = MCSTATE_TEST;
    }
    else
    {
    #if (DEFAULT_USB_DEVICE == 2)
        mctask_state = MCSTATE_MASS;
    #endif
    }
    
    //mcdata_set_current_mode(IDLE_MODE);
	xTimerStart(xmcTimergen, 0);
	xTimerStart(xmcPeriodicRptTimer, 0);
    
	for(;;)
	{
		// �ִ� 2000 msec���� q�� ��ٸ�.
		xActivatedMember =  xQueueSelectFromSet( xQueue, queueSHORT_DELAY );
		// xMcTaskQueue �ϳ��� ��� �� ���
		//if( xQueueReceive( xQueue, &cmd, 2000 ) == pdPASS )

		/* Which set member was selected?  Receives/takes can use a block time
        of zero as they are guaranteed to pass because xQueueSelectFromSet() would
        not have returned the handle unless something was available. */
        if( xActivatedMember == xMcTaskQueue )
        {
            xQueueReceive( xActivatedMember, &cmd, 0 );
        }
        else if( xActivatedMember == xmcTimerQueue )
        {
            xQueueReceive( xActivatedMember, &timerid, 0 );
            cmd.cmd = (uint16_t)timerid;
            cmd.len = 0;
			cmd.msg = NULL;
        }
		else
		{
			cmd.cmd = 0;
			cmd.msg = NULL;
		}

		//processing
		switch(cmd.cmd)
		{
			case 0:
				// No cmd rxed, 2000 msec wait timeout
                DBGMED(MC,"Current MC Status is 0x%x\r\n",mctask_state);
				break;

			case MC_POWEROFF_CMD_F:
				DBGHI(MC,"MC_POWEROFF_CMD_F requested!!!\r\n");
                xTimerStop(xmcPeriodicRptTimer, 0);
                sendSTOPandPowerOFF();
				break;

			case MC_PWR_KEY_CHECK_TIMER_F:
				DBGLOW(MC,"MC_PWR_KEY_CHECK_TIMER_F is expired\r\n");

				if(check_pwroffstate() == TRUE)
				{
					sendMcCommand(MC_POWEROFF_CMD_F);
				}
				break;

			case PWR_KEY_PRESSED_EVT:
				DBGHI(MC,"PWR_KEY_PRESSED_EVT\r\n");
				pwrKeyCount = 0;
				xTimerStart( xmcPwrKeyCheckTimer, 0 );
				break;

#if (0)
            case FFT_COMPLETE_EVT:
                if(MCSTATE_STATE( mctask_state) != MCSTATE_MASS)
                {
                    // send sensor data req to sensor task
                    // and if rxed data result then send req to BLE TASK
                    mcdata_update_fft_result(&cmd);
                    mcprocessSendCmd2Sensor(SENSOR_DATA_REQ_F);
                    xTimerStart(xmcPeriodicRptTimer, 0);
                }
                break;

            case MC_PERIODIC_RPT_TIMER_F:
                if(MCSTATE_STATE( mctask_state) != MCSTATE_MASS)
                {
                    // ���� EEG FFT�� ���� �ǰ� ���� ������ �׳� sensor data�� ������.
                    mcprocessSendCmd2Sensor(SENSOR_DATA_REQ_F);
                    xTimerStart(xmcPeriodicRptTimer, 0);
                    DBGHI(MC,"Periodic Report timer fired!\r\n");
                }
                break;
#endif         
            case SENSOR_DATA_RESULT_EVT:
                if(MCSTATE_STATE( mctask_state) != MCSTATE_MASS)
                {
                    mcdata_update_sensor_result(&cmd);
                
                    // send RESULT to ble task
                    mcdata_send2bletask();
                }
                break;
                
            case MP3_CURRENT_REPORT_EVT:
            	mcdata_update_mp3_result(&cmd);
            	break;

            case MC_MODE_TEST_MODE_F:
                mctask_state = MCSTATE_TEST;
                mctask_state_machine(&cmd);
                break;

            case MC_EXTPWR_IN_EVT:
                IsExtPwrInState = TRUE;
                DBGHI(MC,"External Power In Event.\r\n");
                mcprocessSendCmd2Led(MC_EXTPWR_IN_EVT);
                break;
            case MC_EXTPWR_OUT_EVT:             
                IsExtPwrInState = FALSE;
                DBGHI(MC,"External Power Out Event.\r\n");
                mcprocessSendCmd2Led(MC_EXTPWR_OUT_EVT);
                break;
                
            case MC_STOP_CHARGE_F:
                DBGHI(MC,"Stop Charging !!!\r\n");
                HAL_GPIO_WritePin(CHG_CTRL_GPIO_Port, CHG_CTRL_Pin, GPIO_PIN_SET);
                break;
                
            default:
                if(( isprocessed = CheckFromBLELEDCmd(&cmd)) == TRUE) 
                { 
                    break; 
                }
                
                else if((MCSTATE_STATE( mctask_state) != MCSTATE_MASS) && (( isprocessed = CheckFromBLEMP3Cmd(&cmd)) == TRUE) )
                { 
                    break; 
                }
                
                else if((MCSTATE_STATE( mctask_state) != MCSTATE_MASS) && (( isprocessed = CheckFromSENSORCmd(&cmd)) == TRUE) )
                { 
                    break; 
                }
                else
                {
                    mctask_state_machine(&cmd);
                    break;
                }

		}

		if( (cmd.msg != NULL) && (cmd.isconst == FALSE))
		{
			cmd_mfree(cmd.msg);
		}
	}
}



/*-----------------------------------------------------------*/

