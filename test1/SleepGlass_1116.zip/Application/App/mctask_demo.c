/*===============================================================================================*/
/**
 *   @file mctask_demo.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "signals.h"
#include "command.h"
#include "task_cfg.h"
#include "mctask_state.h"
#include "mc_data.h"
#include "mc_process.h"
#include "debugmsgcli.h"
#include "comdef.h"
#include "interface.h"


/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/
    
// init state
typedef enum
{
    DEMO_ENTRY = MCSTATE_DEMO,
    DEMO_HANDLE,
    DEMO_EXIT,
    NO_STATE
} mctask_demo_state_type;
    

/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/

/*===========================================================================
FUNCTION           
DESCRIPTION     
DEPENDENCIES
RETURN VALUE
===========================================================================*/
uint16_t mc_demo_state ( command_type *cmdptr )
{
    uint16_t new_state; /* new state if any */
    uint16_t ret_state; /* return state */
    uint8_t  *cmdmsg = (uint8_t*)cmdptr->msg;
    uint8_t blecmd = cmdmsg[FDPOS(gen_cmd_msg_field_type,data2)];
    
    ret_state = MCSTATE_NOSTATE;    /* don't assume a return state */
    new_state = mctask_state;

    while ( new_state != NO_STATE )
    {
        mctask_state = new_state;
        new_state = NO_STATE;

        switch ( mctask_state )
        {
            case DEMO_ENTRY :
                mcdata_set_current_mode(DEMO_MODE);

                mcprocessSendCmd2Led(MC_MODE_DEMO_MODE_F);
                mcprocessSendCmd2Mp3(MC_MODE_DEMO_MODE_F);
                mcprocessSendCmd2Sensor(MC_MODE_DEMO_MODE_F);
                                                
                mctask_state = DEMO_HANDLE ;
                break;

            case DEMO_HANDLE :
                
                switch ( cmdptr->cmd )
                {
                    case MC_FFT_EEG_REQ_F:
                    case MC_FFT_PPG_REQ_F:
                        sendFftReqCmd2FFTTASK(cmdptr);
                        DBGLOW(MC,"FFT Req send to FFT task\r\n");
                        break;
                        
                    case FFT_COMPLETE_EVT:
                        // send sensor data req to sensor task
                        // and if rxed data result then send req to BLE TASK
                        mcdata_update_fft_result(cmdptr);
                        mcprocessSendCmd2Sensor(SENSOR_DATA_REQ_F);
                        break;
                    
                    case MC_MODE_CHG_F:
                        {
                            uint16_t processState;
                            
                            processState = mcProcessModechgF(cmdptr->cmd, blecmd);
                            if(processState != MCSTATE_DEMO)
                            {
                                ret_state = processState;
                            }
                        }
                        cmdptr->cmd = 0;
                        break;
                        
                    default:
                        break;
                }
                break;

            default :
                DBGERR ( MC, "bad demo state = 0x%x, cmd = 0x%x\n", mctask_state, cmdptr->cmd );
                cmdptr->cmd = 0;
                break;
        }
    }

    return ret_state;
}


/*===============================================================================================*/
