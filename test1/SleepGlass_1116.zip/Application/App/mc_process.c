/*===============================================================================================*/
/**
 *   @file mc_process.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "comdef.h"
#include "signals.h"
#include "command.h"
#include "task_cfg.h"
#include "interface.h"
#include "mc_process.h"
#include "mc_data.h"
#include "debugmsgcli.h"
#include "mctask_state.h"


/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/

/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/

main_power_state_type power_state = POWER_NORMAL; // 0 : normal, 1: charging, 2: low batt , 3:...

/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/
/*-----------------------------------------------------------*/
void sendMcCommand(uint16_t command)
{
    command_type    cmd;

    portENTER_CRITICAL();
    cmd.len = 0;
    cmd.msg = NULL;
    cmd.cmd = command;
    cmd.isconst = TRUE;
    xQueueSend(xMcTaskQueue,&cmd,taskNO_BLOCK);
    portEXIT_CRITICAL();
}

void sendFftReqCmd2FFTTASK(command_type *command)
{
    command_type    cmd;

    cmd.len     = command->len;
    cmd.msg     = command->msg;
    cmd.isconst = command->isconst;
    switch(command->cmd)
    {
        case MC_FFT_PPG_REQ_F:
            cmd.cmd = FFT_PPG_REQ_F;
            break;
                
        case MC_FFT_EEG_REQ_F:
            cmd.cmd = FFT_EEG_REQ_F;
            break;
            
        default:
            cmd.cmd = 0;
            break;
    }

    if(cmd.cmd != 0)
    {
        portENTER_CRITICAL();
        xQueueSend(xFftTaskQueue,&cmd,taskNO_BLOCK);
        portEXIT_CRITICAL();
    }
}

void mcprocessSendCmd2Sensor(uint16_t signal)
{
    command_type    cmd;
    
    portENTER_CRITICAL();
    cmd.len     = 0;
    cmd.msg     = NULL;
    cmd.isconst = TRUE;
    cmd.cmd     = signal;
    xQueueSend(xSensorTaskQueue,&cmd,taskNO_BLOCK);
    portEXIT_CRITICAL();
}

void mcprocessSendCmd2Mp3(uint16_t signal)
{
    command_type    cmd;
    
    portENTER_CRITICAL();
    cmd.len     = 0;
    cmd.msg     = NULL;
    cmd.isconst = TRUE;
    cmd.cmd     = signal;
    xQueueSend(xMp3TaskQueue,&cmd,taskNO_BLOCK);
    portEXIT_CRITICAL();
}

void mcprocessSendCmd2Led(uint16_t signal)
{
    command_type    cmd;
    
    portENTER_CRITICAL();
    cmd.len     = 0;
    cmd.msg     = NULL;
    cmd.isconst = TRUE;
    cmd.cmd     = signal;
    xQueueSend(xLedTaskQueue,&cmd,taskNO_BLOCK);
    portEXIT_CRITICAL();
}

void mcprocessSendData2Ble(uint16_t signal, uint8_t *data, uint16_t len, boolean isconst)
{
    command_type    cmd;
    
    portENTER_CRITICAL();
    cmd.len     = len;
    cmd.msg     = data;
    cmd.isconst = isconst;
    cmd.cmd     = signal;
    xQueueSend(xBleTaskQueue,&cmd,taskNO_BLOCK);
    portEXIT_CRITICAL();
}

void mcprocessSendCmd2Fft(uint16_t signal)
{
    command_type    cmd;
    
    portENTER_CRITICAL();
    cmd.len     = 0;
    cmd.msg     = NULL;
    cmd.isconst = TRUE;
    cmd.cmd     = signal;
    xQueueSend(xFftTaskQueue,&cmd,taskNO_BLOCK);
    portEXIT_CRITICAL();
}

/*===========================================================================
FUNCTION           
DESCRIPTION     
DEPENDENCIES
RETURN VALUE
===========================================================================*/

boolean CheckFromBLEMP3Cmd(command_type *command)
{
    boolean         isprocessed = TRUE;
    command_type    cmd;
    uint8_t         *data = (uint8_t *)command->msg;
    uint8_t			*tdata;
    
    switch(command->cmd)
    {
        case MP3_OPEN_MUSIC_FILE_F:
        case MP3_SET_VOLUME_F:
        case MP3_LISTS_REQ_F:
        //case MP3_PLAYSTOP_F:
        case MP3_STOP_F:
        case MP3_PAUSE_F:
        case MP3_PLAY_F:
            // Bypass to MP3 Task
            if((tdata = (uint8_t *)cmd_malloc(FDPOS(mp3_cmd_msg_field_type,EndofData))) != NULL)
            {
                cmd.len = FDPOS(mp3_cmd_msg_field_type,EndofData);
                cmd.isconst = FALSE;
                cmd.cmd = command->cmd;
            
                tdata[FDPOS(mp3_cmd_msg_field_type,Index)] = data[FDPOS(gen_cmd_msg_field_type,data2)];
                cmd.msg = tdata;
                
                portENTER_CRITICAL();
                xQueueSend(xMp3TaskQueue,&cmd,taskNO_BLOCK);
                portEXIT_CRITICAL();
            }
            else
            {
                DBGERR(MC,"Memory Allocation Error!!!\r\n");
            }
            break;
            
        default:
            isprocessed = FALSE;
            break;
    }
#if 0
    if(isprocessed)
    {
        mcdata_update_ble_result(command);
    }
#endif
    return isprocessed;
}

boolean CheckFromBLELEDCmd(command_type *command)
{
    boolean         isprocessed = TRUE;
    command_type    cmd;
    uint8_t         *data = (uint8_t *)command->msg;
    uint8_t			*tdata;
    
    switch(command->cmd)
    {
        case LED_BRIGHT_F:
        case LED_FREQ_F:
        case LED_ONOFF_F:
        case LED_ON_F:
        case LED_OFF_F:            
        case AML_CONTROL_F:
            if((tdata = (uint8_t *)cmd_malloc(FDPOS(led_cmd_msg_field_type,EndofData))) != NULL)
            {
                cmd.len = FDPOS(led_cmd_msg_field_type,EndofData);
                cmd.isconst = FALSE;
                cmd.cmd = command->cmd;
            
                tdata[FDPOS(led_cmd_msg_field_type,Cmd)] = data[FDPOS(gen_cmd_msg_field_type,data2)];
                tdata[FDPOS(led_cmd_msg_field_type,Dummy)] = data[FDPOS(gen_cmd_msg_field_type,data3)];
                cmd.msg = tdata;

                portENTER_CRITICAL();
                xQueueSend(xLedTaskQueue,&cmd,taskNO_BLOCK);
                portEXIT_CRITICAL();
            }
            else
            {
                DBGERR(MC,"Memory Allocation Error!!!\r\n");
            }
            break;
            
        default:
            isprocessed = FALSE;
            break;
    }

    if(isprocessed)
    {
        mcdata_update_ble_result(command);
    }

    return isprocessed;
}

/*===========================================================================
FUNCTION           
DESCRIPTION     
DEPENDENCIES
RETURN VALUE
===========================================================================*/
boolean CheckFromSENSORCmd(command_type *cmd)
{    
    boolean isprocessed = TRUE;
    uint8_t *data = (uint8_t *)cmd->msg;
    uint8_t	adc_val = data[0];
    uint8_t			*tdata;
    command_type    tcmd;
    
    switch(cmd->cmd)
    {
#if (0)        
        case MC_FFT_EEG_REQ_F:
        case MC_FFT_PPG_REQ_F:
            sendFftReqCmd2FFTTASK(cmd);
            DBGLOW(MC,"FFT Req send to FFT task\r\n");
            break;
#endif
        case SENSOR_BATT_TEMP_EVT:
            {
                uint8_t low_limit, high_limit;
                
                if(IsCharging)
                {
                    low_limit = BATT_TEMP_CHARGE_LOW_LIMIT;
                    high_limit = BATT_TEMP_CHARGE_HIGH_LIMIT;
                }
                else
                {
                    low_limit = BATT_TEMP_DISCHARGE_LOW_LIMIT;
                    high_limit = BATT_TEMP_DISCHARGE_HIGH_LIMIT;
                }

#ifndef V21BOARD
                if (IsExtPwrInState)
                {
                    if( adc_val > high_limit)
                    {
                        /* Stop charging */
    					sendMcCommand(MC_STOP_CHARGE_F);
                    }
                }
                else
#endif                    
                {
                    if( (adc_val < low_limit) || (adc_val > high_limit))
                    {
                        DBGERR(MC,"Battery Range out of bound Error!!!\r\n");
    					sendMcCommand(MC_POWEROFF_CMD_F);
                    }
                }

            }
            break;

        case SENSOR_BATT_VAL_EVT:
            if( (IsExtPwrInState == FALSE) && (adc_val < BATT_CUTOFF_VOLT_VAL))
            {
                DBGERR(MC,"Battery Cutoff Event occurred!!!\r\n");
                sendMcCommand(MC_POWEROFF_CMD_F);
            }
            else if( (IsExtPwrInState == FALSE) && (adc_val < BATT_LOW_VOLT_VAL))
            {
                DBGERR(MC,"Low Battery Event occurred!!!\r\n");
                mcprocessSendCmd2Led(MC_LOW_BATTERY_EVT);
            }

            #if (0)
            else if((IsCharging == FALSE) && (adc_val > BATT_LOW_VOLT_VAL))
            {
                
            }
            // TODO
            if((IsCharging == TRUE) && (adc_val >= BATT_FULL_VOLT_VAL))
            {
                DBGHI(MC,"Battery Charge Full!!!\r\n");
                mcprocessSendCmd2Led(MC_FULL_CHARGE_EVT);
            }
            #endif
            break;

        case SENSOR_CHARGE_STATUS_ADC_EVT:

            if(IsExtPwrInState == TRUE)
            {
                if( adc_val <= CHARGEADC_LOW)  // charging....
                {
                    if(IsCharging == FALSE)
                    {
                        DBGHI(MC,"Charging Started !!!\r\n");
                        mcprocessSendCmd2Led(MC_CHARGING_STARTED_EVT);
                        
                        // TODO
                        // send MP3 Stop command or pause command
                    }
                    IsCharging = TRUE;

                    power_state = POWER_CHARGE;
                }
                else if(adc_val >= CHARGEADC_HIGH) //charge complete
                {
                    if(IsCharging)
                    {
                        DBGHI(MC,"Charge Complete !!!\r\n");
                        mcprocessSendCmd2Led(MC_FULL_CHARGE_EVT);
                    }
                    
                    IsCharging = FALSE;
                    power_state = POWER_FULL;
                }
                else //  CHARGEADC_LOW < adc_val < CHARGEADC_HIGH // No USB
                {
                    if(IsCharging) 
                    {
                        DBGHI(MC,"Charging Stopped !!!\r\n");
                        mcprocessSendCmd2Led(MC_CHARGING_STOPED_EVT);
                    }
                    IsCharging = FALSE;
                    
                    power_state = POWER_NORMAL;
                }
            }
            break;

        case MC_PPG_CONTROL_F:
            if( data[FDPOS(gen_cmd_msg_field_type,data2)] == 0)
            {
                tcmd.len = 0;
                tcmd.isconst = TRUE;
                tcmd.cmd = FFT_PPG_DATA_INIT_F;
                tcmd.msg = NULL;
                portENTER_CRITICAL();
                xQueueSend(xFftTaskQueue,&tcmd,taskNO_BLOCK);
                portEXIT_CRITICAL();
            }
            // go thru
        case MC_TEMP_CONTROL_F:
        case MC_EDA_CONTROL_F:
            if((tdata = (uint8_t *)cmd_malloc(FDPOS(gen_cmd_msg_field_type,EndofData))) != NULL)
            {
                tcmd.len = FDPOS(gen_cmd_msg_field_type,EndofData);
                tcmd.isconst = FALSE;
                tcmd.cmd = cmd->cmd;
            
                tdata[FDPOS(gen_cmd_msg_field_type,data1)] = data[FDPOS(gen_cmd_msg_field_type,data2)];
                tcmd.msg = tdata;

                portENTER_CRITICAL();
                xQueueSend(xSensorTaskQueue,&tcmd,taskNO_BLOCK);
                portEXIT_CRITICAL();
            }
            else
            {
                DBGERR(MC,"Memory Allocation Error!!!\r\n");
            }
            break;
            
            break;
            
        case MC_WAIT_EEG_STAB_TIME_F:
            {
                uint8_t time = data[FDPOS(gen_cmd_msg_field_type,data2)];
                mcSetStandbyWaitTime(time);
            }
            break;

        default:
            isprocessed = FALSE;
            break;
    }

    return isprocessed;
}

uint16_t mcProcessModechgF(uint16_t cmd, uint8_t data)
{
    uint16_t ret_state = MCSTATE_NOSTATE;
    
    DBGHI(MC,"Mode Change Command Rxed : %d\r\n",data);
    switch(data)
    {
        case 0x00:
        case '0':  // goto MASS
            ret_state = MCSTATE_MASS;
            break;
            
        case 0x01:    
        case '1':  // goto IDLE
            ret_state = MCSTATE_IDLE;
            break;
            
        case 0x02:
        case '2':  // goto STANDBY
            ret_state = MCSTATE_STANDBY;
            break;
            
        case 0x03:
        case '3':  // goto START
            ret_state = MCSTATE_START;
            break;
            
        case 0x04:
        case '4':  // goto DEMO
            ret_state = MCSTATE_DEMO;
            break;

        default:
            break;
    }

    return ret_state;
}

/*===============================================================================================*/
