#ifndef MCDATA_H_
#define MCDATA_H_
/*===============================================================================================*/
/**
 *   @file mcdata.h
 *
 *   @version v1.0
 */
/*=================================================================================================


Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------


===================================================================================================*/
/* Standard includes. */
#include "target.h"
#include "command.h"

/* Scheduler include files. */

/* Application include files. */

/*=================================================================================================
 CONSTANTS
=================================================================================================*/
//State of mask
#define CHARGINGMASS    0x00
#define IDLE_MODE		0x01
#define STANBY_MODE		0x02
#define START_MODE		0x03
#define DEMO_MODE       0x04
#define MODE_MAX        0x05


#define BATT_TEMP_CHARGE_LOW_LIMIT      83
#define BATT_TEMP_CHARGE_HIGH_LIMIT     189

#define BATT_TEMP_DISCHARGE_LOW_LIMIT   59
#define BATT_TEMP_DISCHARGE_HIGH_LIMIT  226

#define BATT_CUTOFF_VOLT_VAL            194//191
#define BATT_LOW_VOLT_VAL               200//197
#define BATT_FULL_VOLT_VAL              240//245

#define CHARGEADC_LOW   10
#define CHARGEADC_HIGH  150

extern boolean IsCharging;
extern boolean IsExtPwrInState;

/*=================================================================================================
 FUNCTION PROTOTYPES
=================================================================================================*/
void mcdata_update_fft_result(command_type *cmd);
void mcdata_update_sensor_result(command_type *cmd);
void mcdata_update_mp3_result(command_type *cmd);
void mcdata_update_ble_result(command_type *cmd);
void mcdata_send2bletask(void);
void mcdata_init(void);
uint8_t mcdata_set_current_mode(uint8_t mode);


/*===============================================================================================*/
#endif  /* MCDATA_H_ */
