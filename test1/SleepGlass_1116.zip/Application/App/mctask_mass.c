/*===============================================================================================*/
/**
 *   @file mctask_mass.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "comdef.h"
#include "signals.h"
#include "command.h"
#include "task_cfg.h"
#include "mctask_state.h"
#include "mc_data.h"
#include "mc_process.h"
#include "debugmsgcli.h"
#include "interface.h"
#include "usb_device.h"

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/
    
// init state
typedef enum
{
    MASS_ENTRY = MCSTATE_MASS,
    MASS_HANDLE,
    MASS_EXIT,
    NO_STATE
} mctask_mass_state_type;
    

/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/

/*===========================================================================
FUNCTION           
DESCRIPTION     
DEPENDENCIES
RETURN VALUE
===========================================================================*/
uint16_t mc_mass_state ( command_type *cmdptr )
{
    uint16_t new_state; /* new state if any */
    uint16_t ret_state; /* return state */
    //uint8_t  *cmdmsg = (uint8_t*)cmdptr->msg;
    //uint8_t blecmd = cmdmsg[FDPOS(gen_cmd_msg_field_type,data2)];
    
    ret_state = MCSTATE_NOSTATE;    /* don't assume a return state */
    new_state = mctask_state;

    while ( new_state != NO_STATE )
    {
        mctask_state = new_state;
        new_state = NO_STATE;

        switch ( mctask_state )
        {
            case MASS_ENTRY :
                mcdata_set_current_mode(CHARGINGMASS);

                mcprocessSendCmd2Led(MC_MODE_MASS_MODE_F);
                mcprocessSendCmd2Mp3(MC_MODE_MASS_MODE_F);
                mcprocessSendCmd2Sensor(MC_MODE_MASS_MODE_F);

                #if defined (USE_USB_VCP) && (DEFAULT_USB_DEVICE == 1)
                    MX_USB_DEVICE_VCP_Stop();
                #endif

                #if defined (USE_USB_MSC)
                    MX_USB_DEVICE_MSC_Init();
                #endif
                
                mctask_state = MASS_HANDLE ;
                break;

            case MASS_HANDLE :
                // Cable�� ������ reset .....
                // TODO Exit ���� �߰� �ʿ� 
                // 1. USB Disconnect
                break;

            case MASS_EXIT:
                #if defined (USE_USB_MSC)
                    MX_USB_DEVICE_MSC_Stop();
                #endif
                
                break;
                
            default :
                DBGERR ( MC, "bad mass state = 0x%x, cmd = 0x%x\n", mctask_state, cmdptr->cmd );
                cmdptr->cmd = 0;
                break;
        }
    }

    return ret_state;
}


/*===============================================================================================*/
