/*===============================================================================================*/
/**
 *   @file tpa2016d2.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.

===================================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "signals.h"
#include "command.h"
#include "task_cfg.h"
#include "tpa2016d2.h"
#include "stm32f4xx_hal.h"
#include "spi.h"
#include "debugmsgcli.h"

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/
extern I2C_HandleTypeDef hi2c2;


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/



/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/
uint8_t      CurrentAmpGain = 6; // ( 0 ~ 0x1e)

boolean     IsAmpInitialize = FALSE;
boolean     IsAmpON         = FALSE;
/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/
uint8_t ReadAmpCircuitStatus(void)
{
    uint8_t command;
    uint8_t data = 0;
    
    HAL_StatusTypeDef status = HAL_OK;

    command = IC_FUNC_CTR;
    status =  HAL_I2C_Master_Transmit(&hi2c2, TPA2016D2_ADDRESS, &command, 1, AMPDEVICE_TIMEOUT);
    if(status == HAL_OK)
    {
        status = HAL_I2C_Master_Receive(&hi2c2, TPA2016D2_ADDRESS, &data, 1, AMPDEVICE_TIMEOUT);
    }
    
    return data;
}

/*-----------------------------------------------------------*/

HAL_StatusTypeDef WriteAmpRegister(uint8_t reg, uint8_t value)
{
    uint8_t command[2];
    HAL_StatusTypeDef status = HAL_OK;

    command[0] = reg;
    command[1] = value;
    status =  HAL_I2C_Master_Transmit(&hi2c2, TPA2016D2_ADDRESS, command, 2, AMPDEVICE_TIMEOUT);

    return status;
}

/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/
boolean AmpInitialize(void)
{
    uint8_t amp_status;
    
    //if(IsAmpInitialize == FALSE)
    {
        AmpTurnOnOff(ON);
        vTaskDelay(50);

        amp_status = ReadAmpCircuitStatus();
        
        if( (amp_status & 0x1C) != 0 )
        {
            // reset error 
            WriteAmpRegister(IC_FUNC_CTR,0xC3);

            amp_status = ReadAmpCircuitStatus();

            if( (amp_status & 0x1C) != 0 )
            {
                IsAmpInitialize = FALSE;
                if((amp_status & 0x18) != 0)
                {
                    DBGERR(MP3, "AMP channel over-current event has occurred.!!!\r\n");
                }
                if((amp_status & 0x04) != 0)
                {
                    DBGERR(MP3, "AMP die temperature is above 150��C. !!!\r\n");
                }

                AmpTurnOnOff(OFF);
            }
            else
            {
                SetAmpGain(CurrentAmpGain);
                IsAmpInitialize = TRUE;                
            }
        }
        else
        {
            SetAmpGain(CurrentAmpGain);
            IsAmpInitialize = TRUE;
        }
    }

    return IsAmpInitialize;
}


/*-----------------------------------------------------------*/
HAL_StatusTypeDef SetAmpGain(uint8_t gain)
{
    uint8_t command[2];
    HAL_StatusTypeDef status = HAL_OK;

    CurrentAmpGain = gain;
    
    if(IsAmpON == TRUE)
    {
        command[0] = AGC_FIXED_GAIN_CTR;
        command[1] = gain;
        status =  HAL_I2C_Master_Transmit(&hi2c2, TPA2016D2_ADDRESS, command, 2, AMPDEVICE_TIMEOUT);
        DBGHI(MP3,"Amp Gain set to : %d, status: %d\r\n", CurrentAmpGain,status);

#if 0        
        command[0] = AGC_CONTROL6;
        command[1] = 0x3F;  // Output Limiter : 0, NoiseGate : 01 (4mVrms) , Output Limiter 11111 (9dBV)
        status =  HAL_I2C_Master_Transmit(&hi2c2, TPA2016D2_ADDRESS, command, 2, AMPDEVICE_TIMEOUT);
#endif        
    }
    else
    {
        IsAmpInitialize = FALSE;
        DBGERR(MP3,"SetAmpGain Failed : ISAMPON is FALSE.\r\n");
    }
    
    return status;
}

/*-----------------------------------------------------------*/

uint8_t ReadAmpGain(void)
{
    uint8_t command;
    uint8_t data = 0;
    
    HAL_StatusTypeDef status = HAL_OK;

    command = AGC_FIXED_GAIN_CTR;
    status =  HAL_I2C_Master_Transmit(&hi2c2, TPA2016D2_ADDRESS, &command, 1, AMPDEVICE_TIMEOUT);
    if(status == HAL_OK)
    {
        status = HAL_I2C_Master_Receive(&hi2c2, TPA2016D2_ADDRESS, &data, 1, AMPDEVICE_TIMEOUT);
    }
    
    return data;
}

/*-----------------------------------------------------------*/
void AmpTurnOnOff(boolean onoff)
{
    if(onoff == ON)
    {
        HAL_GPIO_WritePin(AMP_SDZ_GPIO_Port,AMP_SDZ_Pin, GPIO_PIN_SET);
        IsAmpON = TRUE;
    }
    else
    {
        HAL_GPIO_WritePin(AMP_SDZ_GPIO_Port,AMP_SDZ_Pin, GPIO_PIN_RESET);
        IsAmpON = FALSE;
    }
}

/*-----------------------------------------------------------*/


/*-----------------------------------------------------------*/


/*-----------------------------------------------------------*/


/*-----------------------------------------------------------*/


/*-----------------------------------------------------------*/

/*===============================================================================================*/
