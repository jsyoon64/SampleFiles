#ifndef TPA2016D2_H_
#define TPA2016D2_H_
/*===============================================================================================*/
/**
 *   @file tpa2016d2.h
 *
 *   @version v1.0
 */
/*=================================================================================================


Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------


===================================================================================================*/
/* Standard includes. */

/* Scheduler include files. */
#include "stm32f4xx_hal.h"

/* Application include files. */

/*=================================================================================================
 CONSTANTS
=================================================================================================*/
#define AMPDEVICE_TIMEOUT   200
#define TPA2016D2_ADDRESS   0xB0  // 0xB0 for write, 0xB1 for read

#define IC_FUNC_CTR		    0x01
#define AGC_ATTACK_CTR		0x02
#define AGC_RELEASE_CTR		0x03
#define AGC_HOLDTIME_CTR	0x04
#define AGC_FIXED_GAIN_CTR	0x05
#define AGC_CONTROL6		0x06
#define AGC_CONTROL7		0x07

/*=================================================================================================
 FUNCTION PROTOTYPES
=================================================================================================*/

boolean AmpInitialize(void);
HAL_StatusTypeDef SetAmpGain(uint8_t gain);
uint8_t ReadAmpGain(void);
void AmpTurnOnOff(boolean onoff);

/*===============================================================================================*/
#endif  /* TPA2016D2_H_ */
