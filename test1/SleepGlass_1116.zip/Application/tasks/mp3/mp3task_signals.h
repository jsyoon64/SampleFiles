#ifndef MP3TASK_SIGNALS_H
#define MP3TASK_SIGNALS_H
/*===============================================================================================
 *
 *   @file mp3task_signals.h
 *
 *   @version v1.0
 *
 *=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/
/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Enumerations for substates                                              */

/*****************************************************
                   SIGNAL GROUP

    1. MP3 TASK      : 0x4000 ~
    2. TIMER        : 0x4000 ~ 0x40FF
    3. EVENT        : 0x4100 ~ 0x41FF
    4. COMMAND      : 0x4200 ~ 0x42FF
    5. RESPONSE     : 0x4300 ~ 0x43FF

*****************************************************/

/* MP3 COMMANDS. */
typedef enum
{
    MP3_DUMMY_TIMER  = 0x4000,
	MP3_GEN_TIMER_F,
	MP3_POLL_TIMER_F,

    MP3_DUMMY_EVENT  = 0x4100,
    MP3_SONG_PLAYED_EVT,
    MP3_CURRENT_REPORT_EVT,
    MP3_DREQ_OCCURRED_EVT,

    MP3_TASK_F       = 0x4200,
    MP3_TASK_START_CMD_F,
    MP3_RESET_CMD_F,
    MP3_POWEROFF_CMD_F,
    MP3_TASK_STOP_F,

    MP3_OPEN_MUSIC_FILE_F,  /* rxed 0xC1 command */
    MP3_SET_VOLUME_F,       /* rxed 0xC2 command */
    MP3_LISTS_REQ_F,        /* rxed 0xC3 command */
    //MP3_PLAYSTOP_F,         /* rxed 0xC4 command */
    
	MP3_PLAY_F,
    MP3_STOP_F,
    MP3_PLAY_INDEX_F,
	MP3_PAUSE_F,

    MP3_AMPGAIN_F,
    MP3_AMPGAIN_READ_F,
    
    MP3_DATA_LOAD_F,

    MP3_MAX_COMMAND = 0x4FFF
} mp3task_signal_type;

/*===============================================================================================*/
#endif  /* MP3TASK_SIGNALS_H*/
