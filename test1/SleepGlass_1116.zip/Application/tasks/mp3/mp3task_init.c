/*===============================================================================================*/
/**
 *   @file mp3task_init.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "signals.h"
#include "command.h"
#include "task_cfg.h"
#include "mp3task_state.h"
#include "debugmsgcli.h"
#include "fat_api.h"
#include "vs1011e.h"
#include "sensor_data.h"


/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/
    
// init state
typedef enum
{
    INIT_ENTRY = MP3_INIT,  
    INIT_DEVICE_INIT,
    INIT_HANDLE,
    NO_STATE
} mp3task_init_state_type;
    

/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/

/*===========================================================================
FUNCTION           
DESCRIPTION     
DEPENDENCIES
RETURN VALUE
===========================================================================*/
uint16_t mp3task_init_state ( command_type *cmdptr )
{
    uint16_t new_state; /* new state if any */
    uint16_t ret_state; /* return state */

    ret_state = MP3_NOSTATE;    /* don't assume a return state */
    new_state = mp3task_state;

    while ( new_state != NO_STATE )
    {
        mp3task_state = new_state;
        new_state = NO_STATE;

        switch ( mp3task_state )
        {
            case INIT_ENTRY :
                UpdateSensorStatus(MUSIC_FLAG_POSITION, OFF);
                mp3task_state = INIT_DEVICE_INIT;
                // fall thru
            case INIT_DEVICE_INIT:
                
                if(fatfs_init() == FALSE)
                {
                    // send system reset command
                    // TODO

                    xTimerStart( xmp3GenTimer, 0 );
                }
                else
                {
                    ret_state = MP3_IDLE;
                }
                cmdptr->cmd = 0;
                break;
#if(0)
            case INIT_HANDLE:
                //Init VS1053
                Init_Codec();
                mp3task_state = MP3_IDLE;
                //ret_state = MP3_IDLE;
                break;
#endif
            default :
                DBGERR ( MP3, "bad init state = 0x%x, cmd = 0x%x\n", mp3task_state, cmdptr->cmd );
                cmdptr->cmd = 0;
                break;
        }
    }

    return ret_state;
}


/*===============================================================================================*/
