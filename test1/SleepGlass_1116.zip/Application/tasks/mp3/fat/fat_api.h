#ifndef FAT_API_H_
#define FAT_API_H_
/*===============================================================================================*/
/**
 *   @file fat_api.h
 *
 *   @version v1.0
 */
/*=================================================================================================


Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------


===================================================================================================*/
/* Standard includes. */

/* Scheduler include files. */

/* Application include files. */
#include "target.h"
#include "comdef.h"
#include "command.h"
#include "ff_gen_drv.h"
#include "fatfs.h"

/*=================================================================================================
 CONSTANTS
=================================================================================================*/
#define MP3_DATA_READ_SIZE          32
#define MAX_FILE_INDEXING_ARRAY     300 //4000 // 65535
#define MAX_SFN_SIZE                12

#if (_USE_LFN == 0)
    #define MAX_FILENAME_SIZE       MAX_SFN_SIZE+1
#else
    #define MAX_FILENAME_SIZE       _MAX_LFN+1
#endif

extern char        album_table[MAX_FILE_INDEXING_ARRAY][MAX_FILENAME_SIZE];

extern uint16_t    Mp3_Index ;
extern FIL         fp_mp3file;
extern uint16_t    Mp3_file_count;

/*=================================================================================================
 FUNCTION PROTOTYPES
=================================================================================================*/
boolean fatapi_open_music_file( command_type *cmdptr);
void fatapi_stop(void);
uint16_t fatapi_get_mp3_index(void);
void fatapi_set_mp3_index(uint16_t index);
uint16_t fatapi_inc_mp3_index(void);
void fatapi_close_current_file();
boolean fatapi_open_file(void);
unsigned int fatapi_read_buffer(uint16_t numbytes);
uint8_t *fatapi_get_buffer_ptr();

boolean fatfs_init(void);


/*===============================================================================================*/
#endif  /* FAT_API_H_ */
