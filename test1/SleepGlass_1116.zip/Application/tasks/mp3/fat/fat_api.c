/*===============================================================================================*/
/**
 *   @file fat_api.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */
#include <stdlib.h>

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "signals.h"
#include "command.h"
#include "task_cfg.h"
#include "fat_api.h"
#include "debugmsgcli.h"
#include "fatfs.h"
#include "ffconf.h"


/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/

uint16_t    Mp3_file_count = 1;

/* Short Filename support*/
char        album_table[MAX_FILE_INDEXING_ARRAY][MAX_FILENAME_SIZE];

uint8_t     mp3_databuf[MP3_DATA_READ_SIZE];

char        path[64]="/";
//Fatfs object
FATFS       FatFs;
//File object
FIL         fp_mp3file;
//Directory object
DIR         dir;
//Free and total space

//current song number
uint16_t    Mp3_Index = 1;

/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/
#if defined(USING_QSORT_FILENAME)
/* qsort struct comparision function (product C-string field) */ 
int qsort_cmp_func(const void *a, const void *b) 
{ 
    return strcmp(a, b);
	/* strcmp functions works exactly as expected from
	comparison function */ 
} 


void SortScanFilesWithName(int count)
{
    //void qsort(void *base, size_t nitems, size_t size, int (*compar)(const void *, const void*))
	char *base = album_table[1];
    qsort(base, count-1, MAX_FILENAME_SIZE, qsort_cmp_func);
}

#else
void SortScanFilesWithName(int count)
{
    int i,j,n = count;

    char temp[MAX_FILENAME_SIZE + 1];   /* Buffer to store the LFN */


    //for (i = 0; i < n; i++) 
    for (i = 1; i < n; i++) // 0���� ���� ������ ���� �Ǿ� �����Ƿ� 
    {
        for (j = 1; j < n - 1; j++) 
        {
            if (strncmp(album_table[j], album_table[j + 1],MAX_FILENAME_SIZE) > 0)
            {
                strncpy(temp, album_table[j],MAX_FILENAME_SIZE);
                strncpy(album_table[j], album_table[j + 1],MAX_FILENAME_SIZE);
                strncpy(album_table[j + 1], temp,MAX_FILENAME_SIZE);
            }
        }
    }    
}
#endif

/*-----------------------------------------------------------*/
FRESULT scan_files (
    char* path        /* Start node to be scanned (also used as work area) */
)
{
    FRESULT res;
    FILINFO fno;
    DIR dir;
    int i;
    char *fn;   /* This function assumes non-Unicode configuration */
#if _USE_LFN
    static char lfn[_MAX_LFN + 1];   /* Buffer to store the LFN */
    fno.lfname = lfn;
    fno.lfsize = sizeof lfn;
#endif


    res = f_opendir(&dir, path);                       /* Open the directory */
    if (res == FR_OK) 
    {
        i = strlen(path);
        for (;;) 
        {
            res = f_readdir(&dir, &fno);                   /* Read a directory item */
            if (res != FR_OK || fno.fname[0] == 0) break;  /* Break on error or end of dir */
            if (fno.fname[0] == '.') continue;             /* Ignore dot entry */
#if _USE_LFN
            fn = *fno.lfname ? fno.lfname : fno.fname;
#else
            fn = fno.fname;
#endif
            if (fno.fattrib & AM_DIR)                      /* It is a directory */
            {
                if(!(fno.fattrib & AM_SYS))
                {
                    //sprintf(*(path+i), "/%s", fn);

                    strcpy(path+i,fn);
                    res = scan_files(path);
                    path[i] = 0;
                    if (res != FR_OK) 
                        break;
                }
            } 
            else 
            {                                           /* It is a file. */
                DBGLOW(MP3,"%s/%s\n", path, fn);
                strcpy(album_table[Mp3_file_count++],fn);
            }
        }
        SortScanFilesWithName(Mp3_file_count);
        f_closedir(&dir);
    }

    return res;
}


/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/

boolean fatapi_open_music_file( command_type *cmdptr)
{
	uint8_t     *data = (uint8_t *)cmdptr->msg;
    Mp3_Index = (uint16_t)(data[0]);
    return TRUE;
}

/*-----------------------------------------------------------*/
void fatapi_stop(void)
{
    f_close(&fp_mp3file);
    f_mount(0, "", 1);
}
/*-----------------------------------------------------------*/

uint16_t fatapi_get_mp3_index(void)
{
    return Mp3_Index;
}

void fatapi_set_mp3_index(uint16_t index)
{
    Mp3_Index = index;
}

uint16_t fatapi_inc_mp3_index(void)
{
    Mp3_Index++;
    if(Mp3_Index > Mp3_file_count)
        Mp3_Index = 1;

    return Mp3_Index;
}

void fatapi_close_current_file()
{
    f_close(&fp_mp3file);
}

FRESULT fatapi_open_file(void)
{
    if(Mp3_Index < 1) Mp3_Index = 1;
    return f_open(&fp_mp3file, (const char*)(&album_table[Mp3_Index]),FA_READ);
    //return TRUE;
}

unsigned int fatapi_read_buffer(uint16_t numbytes)
{
    unsigned int readbytes;
    if(f_read(&fp_mp3file,mp3_databuf,numbytes,&readbytes) == FR_OK)
    {
        return readbytes;
    }
    else
    {
        return 0;
    }
}

uint8_t *fatapi_get_buffer_ptr()
{
    return mp3_databuf;
}



/*===========================================================================
FUNCTION           
DESCRIPTION     
DEPENDENCIES
RETURN VALUE
===========================================================================*/
boolean fatfs_init(void)
{
	unsigned int numbytes;
    
    if (f_mount(&FatFs,"", 1) == FR_OK) 
    {
        //Mounted OK
        DBGERR(MP3,"Mounted OK\r\n");
        scan_files(path);
        //Try to open file
        if (f_open(&fp_mp3file,  (const char*)(&album_table[0]),FA_READ) == FR_OK)
        {
            //File opened
            DBGLOW(MP3,"File Opens OK\n");
            //sd_init_flag = true;
            f_read(&fp_mp3file,mp3_databuf,32,&numbytes);
        }
        //Unmount drive, don't forget this!
        //f_mount(0, "", 1);
        return TRUE;
    }
    else
    {
        //Mounted OK
        DBGERR(MP3,"Mounted Fail!!!\r\n");
    }
    return FALSE;

}

/*===============================================================================================*/
