#ifndef VS1011E_H_
#define VS1011E_H_
/*===============================================================================================*/
/**
 *   @file vs1011e.h
 *
 *   @version v1.0
 */
/*=================================================================================================


Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------


===================================================================================================*/
/* Standard includes. */

/* Scheduler include files. */
#include "stm32f4xx_hal.h"

/* Application include files. */

/*=================================================================================================
 CONSTANTS
=================================================================================================*/

#define SCI_MODE			0x00
#define SCI_STATUS			0x01
#define SCI_BASS			0x02
#define SCI_CLOCKF			0x03
#define SCI_DECODE_TIME     0x04 
#define SCI_AUDATA			0x05
#define SCI_HDAT0           0x08 /* VS1063, VS1053, VS1033, VS1003, VS1011 */
#define SCI_HDAT1           0x09 /* VS1063, VS1053, VS1033, VS1003, VS1011 */ 


#define SCI_VOL				0x0B

#define VS1002_NATIVE_SPI_MODE	0x0800

//2015.02.02 VS1053B ���� datasheet p.42
#define XTALI				0x0000
#define XTALI_2_0			0x2000	// 2.0
#define XTALI_2_5			0x4000	// 2.5
#define XTALI_3_0			0x6000	// 3.0
#define XTALI_3_5			0x8000	// 3.5
#define XTALI_4_0			0xA000
#define XTALI_4_5			0xC000
#define XTALI_5_0			0xE000


#define SCI_READ_CMD		0x03
#define SCI_WRITE_CMD	    0x02

// codec volume
//#define MIN_VOLUME             0
//#define MAX_VOLUME           254
#define DEFAULT_VOLUME	     200

#define ZERO				0x00

#define ST_AMPLITUDE        0x00  // High tone initial value(8..7, 0 = off)
#define ST_FREQLIMIT        0x0A  // Low tone frequency bandwidth select(0..15)
#define SB_AMPLITUDE        0x00  // Low tone initial value(0..15, 0 = off)
#define SB_FREQLIMIT        0x06  // High tone frequency bandwidth select(2..15)

#define MAX_TREBLE_ENH      0x08  // High tone Max value
#define MIN_TREBLE_ENH      0x00  // HIgh tone Min value
#define MAX_BASS_ENH        0x0F  // Low tone Max value
#define MIN_BASS_ENH        0x00  // Low tone Min value

/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/

extern uint8_t      CurrentVolume;

/*=================================================================================================
 FUNCTION PROTOTYPES
=================================================================================================*/
void Init_Codec(void);
void Set_Volume(uint8_t Vol);

HAL_StatusTypeDef Send_Mp3_Databytes(uint8_t* data, uint8_t numbytes);
void Noise_Control(void);
void Mp3_Play_Status_Report(char *pcWriteBuffer);
void Mp3ResetDecodeTime(void);

/*===============================================================================================*/
#endif  /* VS1011E_H_ */
