/*===============================================================================================*/
/**
 *   @file vs1011e.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.

===================================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "signals.h"
#include "command.h"
#include "task_cfg.h"
#include "vs1011e.h"
#include "stm32f4xx_hal.h"
#include "spi.h"
#include "debugmsgcli.h"

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/
#define MP3_MAX_RESP_TIME   100 // 100 msec max operate time

#define MP3_VOLUME_MIN		200
#define MP3_VOLUME_MAX		255
#define MP3_VOLUME_MAX_MAX  255

/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/
uint8_t      CurrentVolume = 100;//250;



/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/
#if(1)
void  SCI_WriteByte(uint8_t addr, uint8_t tx_data)
{
    uint16_t    MaxRetryCount;
    uint8_t     sci_cmd;
    
    
    //Wait until DREQ go HIGH
    MaxRetryCount=0;
    while( HAL_GPIO_ReadPin(MP3_DREQ_GPIO_Port,MP3_DREQ_Pin) == GPIO_PIN_RESET)
    {
        HAL_Delay(2); 
        if(MaxRetryCount++ > 5)
        {
            break;
        }
    }

    HAL_GPIO_WritePin(MP3_CS, GPIO_PIN_RESET); // set VS1101 CS to low

    sci_cmd = SCI_WRITE_CMD;
    if( HAL_SPI_Transmit(&hspi1, &sci_cmd, 1, MP3_MAX_RESP_TIME) == HAL_OK) //Send WRITE command
    {
        HAL_SPI_Transmit(&hspi1, &addr, 1, MP3_MAX_RESP_TIME);              //Send REGISTER address
        HAL_SPI_Transmit(&hspi1, &tx_data, 1, MP3_MAX_RESP_TIME);
    }
    HAL_GPIO_WritePin(MP3_CS, GPIO_PIN_SET); // set VS1101 CS to High
    HAL_Delay(2); 

    //Wait until DREQ go HIGH
    MaxRetryCount=0;
    while( HAL_GPIO_ReadPin(MP3_DREQ_GPIO_Port,MP3_DREQ_Pin) == GPIO_PIN_RESET)
    {
        HAL_Delay(2); 
        if(MaxRetryCount++ > 5)
            break;
    }    
}
#endif

void  SCI_Write(uint8_t addr, uint16_t tx_data)
{
    uint16_t    MaxRetryCount;
    uint8_t     sci_cmd;
    uint8_t     data[2];

    data[0] =(uint8_t) (tx_data>>8);
    data[1] = (uint8_t) tx_data;
    
    HAL_GPIO_WritePin(MP3_CS, GPIO_PIN_RESET); // set VS1101 CS to low
    
    //Wait until DREQ go HIGH
    MaxRetryCount=0;
    while( HAL_GPIO_ReadPin(MP3_DREQ_GPIO_Port,MP3_DREQ_Pin) == GPIO_PIN_RESET)
    {
        HAL_Delay(10); 
        if(MaxRetryCount++ > 5)
        {
            break;
        }
    }
    sci_cmd = SCI_WRITE_CMD;
    if( HAL_SPI_Transmit(&hspi1, &sci_cmd, 1, MP3_MAX_RESP_TIME) == HAL_OK) //Send WRITE command
    {
        HAL_SPI_Transmit(&hspi1, &addr, 1, MP3_MAX_RESP_TIME);              //Send REGISTER address
        HAL_SPI_Transmit(&hspi1, &data[0], 2, MP3_MAX_RESP_TIME);                //read data
    }
    HAL_GPIO_WritePin(MP3_CS, GPIO_PIN_SET); // set VS1101 CS to High
    HAL_Delay(2); 

    //Wait until DREQ go HIGH
    MaxRetryCount=0;
    while( HAL_GPIO_ReadPin(MP3_DREQ_GPIO_Port,MP3_DREQ_Pin) == GPIO_PIN_RESET)
    {
        HAL_Delay(10); 
        if(MaxRetryCount++ > 5)
            break;
    }    
}

/*-----------------------------------------------------------*/
boolean SCI_Read_bytes(uint8_t addr, uint8_t* rx_data, uint8_t numbytes)
{
    uint16_t    MaxRetryCount;
    uint8_t     sci_cmd;

    //Wait until DREQ go HIGH
     MaxRetryCount=0;
    while( HAL_GPIO_ReadPin(MP3_DREQ_GPIO_Port,MP3_DREQ_Pin) == GPIO_PIN_RESET)
    {
        HAL_Delay(10); 
        if(MaxRetryCount++ > 5)
        {
            return FALSE;
        }
    }

    HAL_GPIO_WritePin(MP3_CS, GPIO_PIN_RESET); // set VS1101 CS to low
    sci_cmd = SCI_READ_CMD;
    if( HAL_SPI_Transmit(&hspi1, &sci_cmd, 1, MP3_MAX_RESP_TIME) == HAL_OK) //Send WRITE command
    {
        HAL_SPI_Transmit(&hspi1, &addr, 1, MP3_MAX_RESP_TIME);              //Send REGISTER address
        HAL_SPI_Receive(&hspi1, rx_data, numbytes, MP3_MAX_RESP_TIME);                //read data
    }

    HAL_GPIO_WritePin(MP3_CS, GPIO_PIN_SET); // set VS1101 CS to High

    //Wait until DREQ go HIGH
     MaxRetryCount=0;
    while( HAL_GPIO_ReadPin(MP3_DREQ_GPIO_Port,MP3_DREQ_Pin) == GPIO_PIN_RESET)
    {
        HAL_Delay(5); 
        if(MaxRetryCount++ > 5)
            return FALSE;
    }    

    return TRUE;
}


/*-----------------------------------------------------------*/

/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/
void codec_reset(void)
{
    HAL_GPIO_WritePin(MP3_RESET_GPIO_Port,MP3_RESET_Pin,GPIO_PIN_RESET); // VS1101 Reset to low
    //HAL_Delay(100);
    vTaskDelay(100);
    
    HAL_GPIO_WritePin(MP3_RESET_GPIO_Port,MP3_RESET_Pin,GPIO_PIN_SET); // VS1101 Reset to high
    HAL_Delay(5);
}


/*-----------------------------------------------------------*/
void Init_Codec(void)
{
    uint16_t rx_data=0;
    uint8_t read_data[2];

    HAL_GPIO_WritePin(MP3_CS, GPIO_PIN_SET); // set VS1101 CS to High
    HAL_GPIO_WritePin(MP3_DCS_GPIO_Port,MP3_DCS_Pin,GPIO_PIN_SET); // VS1101 DCS to high
    HAL_GPIO_WritePin(MP3_RESET_GPIO_Port,MP3_RESET_Pin,GPIO_PIN_SET); // VS1101 Reset to high
    HAL_Delay(10);

    codec_reset();

    SCI_Read_bytes(SCI_MODE,&read_data[0],2);
    //SCI_Write(SCI_MODE, 0x0C00);
    SCI_Write(SCI_MODE, 0x0804);
    //SCI_Write(SCI_MODE, 0x0000);

    SCI_Read_bytes(SCI_MODE,&read_data[0],2);
	rx_data = (uint16_t)read_data[0];
	rx_data = (uint16_t)((rx_data<<8)|read_data[1]);
    
    DBGLOW(MP3,"SCI_MODE setting to. (0x%x)\r\n",rx_data);
    
    SCI_Read_bytes(SCI_CLOCKF,&read_data[0],2);
    SCI_Write(SCI_CLOCKF, 0x9800);

    SCI_Read_bytes(SCI_CLOCKF,&read_data[0],2);
    
	rx_data = (uint16_t)read_data[0];
	rx_data = (uint16_t)((rx_data<<8)|read_data[1]);
    if(rx_data != 0x9800)
    {
    	DBGERR(MP3,"SCI_CLOCKF setting Fail. (0x%x/0x9800)\r\n",rx_data);
    }

#if(0)
/*
When decoding correct data, the current sample rate and number of channels can be found in
bits 15:1 and 0 of SCI_AUDATA, respectively. Bits 15:1 contain the sample rate divided by two,
and bit 0 is 0 for mono data and 1 for stereo. Writing to this register will change the sample rate
on the run to the number given.
Example: 44100 Hz stereo data reads as 0xAC45 (44101).
Example: 11025 Hz mono data reads as 0x2B10 (11024).
Example: Writing 0xAC80 sets sample rate to 44160 Hz, stereo mode does not change.

*/
    SCI_Read_bytes(SCI_AUDATA,&read_data[0],2);
    SCI_Write(SCI_AUDATA, 0xAC45);
#endif

    Set_Volume(CurrentVolume); // default value 200
}

/*-----------------------------------------------------------*/
void Set_Volume(uint8_t Vol)
{
    uint16_t temp;
	uint8_t  edited_vol;		//add volume formula

    CurrentVolume = Vol;
	edited_vol = ((Vol * (MP3_VOLUME_MAX - MP3_VOLUME_MIN)) / MP3_VOLUME_MAX_MAX) + MP3_VOLUME_MIN;		//input data to formula

    // 0 is real MAX volume, 255 is MIN voume
    temp = (MP3_VOLUME_MAX_MAX - edited_vol);
	DBGHI(MP3,"User Input Vol = %d, System Output Vol = %d\r\n", CurrentVolume, edited_vol);
    
    //SCI_Write(SCI_VOL, (temp << 8) | temp); 
    SCI_Write(SCI_VOL, (uint16_t)(temp*0x101)); 
}

/*-----------------------------------------------------------*/

HAL_StatusTypeDef Send_Mp3_Databytes(uint8_t* data, uint8_t numbytes)
{
    HAL_StatusTypeDef ret;
    
    HAL_GPIO_WritePin(MP3_DCS_GPIO_Port,MP3_DCS_Pin,GPIO_PIN_RESET); // VS1101 DCS to low
    ret = HAL_SPI_Transmit(&hspi1, data, numbytes, MP3_MAX_RESP_TIME);  //Send WRITE command
    HAL_GPIO_WritePin(MP3_DCS_GPIO_Port,MP3_DCS_Pin,GPIO_PIN_SET); // VS1101 DCS to high
    
    return ret;
}


/*-----------------------------------------------------------*/
void Noise_Control(void)
{
    uint16_t    i;
    uint8_t     data;

    data = 0x00;

#if 0    
    for(i=0; i<2048; i++)
    {
        Send_Mp3_Databytes(&data,1);
    }
#else
    HAL_GPIO_WritePin(MP3_DCS_GPIO_Port,MP3_DCS_Pin,GPIO_PIN_RESET); // VS1101 DCS to low
    for(i=0; i<512; i++)
    {
        HAL_SPI_Transmit(&hspi1, &data, 1, MP3_MAX_RESP_TIME);  //Send WRITE command
    }
    HAL_GPIO_WritePin(MP3_DCS_GPIO_Port,MP3_DCS_Pin,GPIO_PIN_SET); // VS1101 DCS to high
#endif
}

/*-----------------------------------------------------------*/

void Mp3_Play_Status_Report(char *pcWriteBuffer)
{
    uint8_t  data[2];
    uint16_t h1;
    char *TempString,temp[20];

    SCI_Read_bytes(SCI_HDAT1, data, 2);
    
	h1 = (uint16_t)data[0];
	h1 = (uint16_t)((h1<<8)|data[1]);

    if (h1 == 0x7665) {
        TempString = "Rif";
    } else if ((h1 & 0xffe6) == 0xffe2) {
        TempString = "MP3";
    } else if ((h1 & 0xffe6) == 0xffe4) {
        TempString = "MP2";
    } else if ((h1 & 0xffe6) == 0xffe6) {
        TempString = "MP1";
    } else {
        TempString = "???";
    }

    strncpy(pcWriteBuffer,"\r\n",2);
    strcat(pcWriteBuffer,"---------\r\n");
    strcat(pcWriteBuffer,TempString);
    strcat( pcWriteBuffer, "  " );
    
    SCI_Read_bytes(SCI_AUDATA, data, 2);
    
	h1 = (uint16_t)data[0];
	h1 = (uint16_t)((h1<<8)|data[1]);

    sprintf(temp,"Sample Rate %dHz ",h1 & 0xFFFE);
    strcat( pcWriteBuffer,temp);

    if((h1 & 1) == 1)
    {
        strcat( pcWriteBuffer,"stereo ");
    }
    else
    {
        strcat( pcWriteBuffer,"mono ");
    }
    
    SCI_Read_bytes(SCI_DECODE_TIME, data, 2);
    
	h1 = (uint16_t)data[0];
	h1 = (uint16_t)((h1<<8)|data[1]);

    sprintf(temp,"Decode Time %ds \r\n",h1);
    strcat( pcWriteBuffer,temp);
    
    strcat(pcWriteBuffer,"---------\r\n");

}

/*-----------------------------------------------------------*/

void Mp3ResetDecodeTime(void)
{
    SCI_Write(SCI_DECODE_TIME, 0x00);
}
/*-----------------------------------------------------------*/

/*===============================================================================================*/
