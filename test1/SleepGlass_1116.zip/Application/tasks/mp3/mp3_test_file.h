#ifndef MP3_TEST_FILE
#define MP3_TEST_FILE

static const unsigned char mp3_test_file[] = {
0x00,0x00
};

#endif
