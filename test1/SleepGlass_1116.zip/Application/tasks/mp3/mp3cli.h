/*
*/

#ifndef MP3CLI_H
#define MP3CLI_H

void mp3CLIregister(void);

#endif

