/*===============================================================================================*/
/**
 *   @file mp3task_idle.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "signals.h"
#include "command.h"
#include "task_cfg.h"
#include "mp3task_state.h"
#include "debugmsgcli.h"
#include "vs1011e.h"
#include "fat_api.h"
#include "sensor_data.h"
#include "tpa2016d2.h"

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/
        
// idle state
typedef enum
{
    IDLE_ENTRY = MP3_IDLE,
    IDLE_HANDLE,

    NO_STATE
} mp3task_idle_state_type;
    
    
/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/

/*===========================================================================
FUNCTION           
DESCRIPTION     
DEPENDENCIES
RETURN VALUE
===========================================================================*/
uint16_t mp3task_idle_state ( command_type *cmdptr )
{
    uint16_t new_state; /* new state if any */
    uint16_t ret_state; /* return state */
    uint8_t *data = (uint8_t*)(cmdptr->msg);

    ret_state = MP3_NOSTATE;    /* don't assume a return state */
    new_state = mp3task_state;

    while ( new_state != NO_STATE )
    {
        mp3task_state = new_state;
        new_state = NO_STATE;

        switch ( mp3task_state )
        {
            case IDLE_ENTRY :
                
                UpdateSensorStatus(MUSIC_FLAG_POSITION, OFF);
                mp3task_state = IDLE_HANDLE;
                //break;

            case IDLE_HANDLE :
                switch ( cmdptr->cmd )
                {
                    case MP3_DATA_LOAD_F:
                        break;
                        
                    case MP3_OPEN_MUSIC_FILE_F:
                        Mp3_Index = data[0];
                        sendMP3Result2mc(0);
                        break;
                        
                    case MP3_SET_VOLUME_F:
               			Set_Volume(data[0]);
                        sendMP3Result2mc(0);
                        break;
                    
                    case MP3_AMPGAIN_F:
               			SetAmpGain(data[0]);
                        break;
                        
                    case MP3_PAUSE_F:         /* rxed 0xC4 command */
                    case MP3_STOP_F:
                    	break;

                    case MP3_PLAY_F:
                        ret_state = MP3_PLAY;
                        break;
                        
                    case MP3_PLAY_INDEX_F:
                        Mp3_Index = data[0];
                        ret_state = MP3_PLAY;
                        break;
                        
                    case MP3_SONG_PLAYED_EVT:
                        break;

                    case MC_MODE_DEMO_MODE_F:
                    case MC_MODE_START_MODE_F:
                        Mp3_Index = 1;
                        //ret_state = MP3_PLAY;
                        break;
                    
                    case MC_MODE_IDLE_MODE_F:
                        break;
                        
                    default:
                        break;
                }
                cmdptr->cmd = 0;
                break;

            default :
                DBGERR ( MP3, "bad idle state = 0x%x, cmd = 0x%x\n", mp3task_state, cmdptr->cmd );
                cmdptr->cmd = 0;
                break;
        }
    }

    return ret_state;
}

/*===============================================================================================*/
