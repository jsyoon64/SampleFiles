/*===============================================================================================*/
/**
 *   @file mp3task_test.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "signals.h"
#include "command.h"
#include "task_cfg.h"
#include "mp3task_state.h"
#include "vs1011e.h"
#include "fat_api.h"
#include "debugmsgcli.h"
#include "sensor_data.h"
#include "tpa2016d2.h"
#include "mp3_test_file.h"

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/
            
// play state
typedef enum
{
    TEST_INIT = MP3_TEST,
    TEST_ENTRY,
    TEST_SEND_NOISE,
    TEST_SEND_DATA,
    TEST_DATA_READ,
    TEST_HANDLE,
    TEST_PAUSED,
    TEST_SONG_PLAYED,
    TEST_STOP,
    TEST_EXIT,
    NO_STATE
} mp3task_test_state_type;
        

/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/
static uint16_t next_buffer_pos = 0;
static uint16_t current_buffer_pos = 0;


/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/
unsigned int testmp3_read_buffer(uint16_t numbytes, boolean isfirst)
{
    unsigned int readbytes;
    static uint16_t mp3_test_file_len = sizeof(mp3_test_file);
    
    if(isfirst == TRUE)
    {
        next_buffer_pos = 0;
    }

    if(mp3_test_file_len > next_buffer_pos)
    {
        readbytes = MIN(numbytes,(mp3_test_file_len - next_buffer_pos));
        current_buffer_pos = next_buffer_pos;
        next_buffer_pos += readbytes;
        return readbytes;
    }
    else
    {
        return 0;
    }
}


/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/

/*===========================================================================
FUNCTION           
DESCRIPTION     
DEPENDENCIES
RETURN VALUE
===========================================================================*/
uint16_t mp3task_test_state ( command_type *cmdptr )
{
    uint16_t new_state; /* new state if any */
    uint16_t ret_state; /* return state */
    HAL_StatusTypeDef result;
    uint8_t *data = (uint8_t*)(cmdptr->msg);
    
    ret_state = MP3_NOSTATE;    /* don't assume a return state */
    new_state = mp3task_state;

    while ( new_state != NO_STATE )
    {
        mp3task_state = new_state;
        new_state = NO_STATE;

        switch ( mp3task_state )
        {
            case TEST_INIT:
                AmpTurnOnOff(OFF);
                fatapi_close_current_file();
                xTimerStart( xmp3GenTimer, 0 );
                mp3task_state = TEST_HANDLE;
                break;
                
            case TEST_ENTRY :
                Mp3ResetDecodeTime();
                read_bytes_raw = testmp3_read_buffer(MP3_DATA_READ_SIZE, TRUE);
                new_state = TEST_SEND_DATA;
                break;

            case TEST_SEND_DATA:
                result = Send_Mp3_Databytes((uint8_t*)&mp3_test_file[current_buffer_pos], read_bytes_raw);

                (void)result;
                if(read_bytes_raw < MP3_DATA_READ_SIZE)
                {
                    // start mp3 dreq polling timer
                    xTimerStart( xmp3PollTimer, 0 );
                    mp3task_state = TEST_HANDLE;
                }
                else
                {
                    new_state = TEST_DATA_READ;
                }
                break;
                
            case TEST_DATA_READ:
                read_bytes_raw = testmp3_read_buffer(MP3_DATA_READ_SIZE, FALSE);
            
#ifdef USE_MP3_DREQ_POLL
                // start mp3 dreq polling timer
                xTimerStart( xmp3PollTimer, 0 );
                mp3task_state = TEST_HANDLE;
#else
                if( HAL_GPIO_ReadPin(MP3_DREQ_GPIO_Port,MP3_DREQ_Pin) == GPIO_PIN_SET)
                {
                    new_state = TEST_SEND_DATA;
                }
                else
                {
                    mp3task_state = TEST_HANDLE;                    
                }
#endif
                break;
                
            case TEST_HANDLE :
                switch ( cmdptr->cmd )
                {
                    case MP3_GEN_TIMER_F:
                        //Init VS1053
                        Init_Codec();
                        AmpTurnOnOff(ON);
                        AmpInitialize();
                        mp3task_state = TEST_ENTRY;
                        break;
               
                    case MP3_POLL_TIMER_F:
                        //check DREQ go HIGH
                        if( HAL_GPIO_ReadPin(MP3_DREQ_GPIO_Port,MP3_DREQ_Pin) == GPIO_PIN_SET)
                        {
                            if(read_bytes_raw < MP3_DATA_READ_SIZE)
                            {
                                new_state = TEST_SONG_PLAYED;
                            }
                            else
                            {
                                new_state = TEST_SEND_DATA;
                            }
                        }
#ifdef USE_MP3_DREQ_POLL      
                        else
                        {
                            // start mp3 dreq polling timer
                            xTimerStart( xmp3PollTimer, 0 );
                        }
#endif                        
                        break;

                    // MP3_DREQ interrupt event occurred
                    case MP3_DREQ_OCCURRED_EVT:
                        if(read_bytes_raw < MP3_DATA_READ_SIZE)
                        {
                            new_state = TEST_SONG_PLAYED;
                        }
                        else
                        {
                            new_state = TEST_SEND_DATA;
                        }
                        break;

                    case MP3_SET_VOLUME_F:
                  		Set_Volume(data[0]);
                        sendMP3Result2mc(Mp3_Index);
                        break;

                    case MP3_AMPGAIN_F:
               			SetAmpGain(data[0]);
                        break;

                    case MP3_AMPGAIN_READ_F:
                        DBGHI(MP3,"AMP Gain is %d\r\n",ReadAmpGain());
                        break;
                                                                                           
                    case MP3_STOP_F:
                        new_state = TEST_STOP;
                        break;
                        
                    case MP3_PAUSE_F:         /* rxed 0xC4 command */
                        mp3task_state = TEST_PAUSED;
                        break;

                    case MP3_PLAY_F:
                        break;
                    
                    case MP3_SONG_PLAYED_EVT:
                        new_state = TEST_SONG_PLAYED;
                        break;

                    case MP3_OPEN_MUSIC_FILE_F:
                    case MP3_PLAY_INDEX_F:
                        break;

                    case MC_MODE_DEMO_MODE_F:
                    case MC_MODE_START_MODE_F:
                    case MC_MODE_STANDBY_MODE_F:
                    case MC_MODE_MASS_MODE_F:
                    case MC_MODE_IDLE_MODE_F:
                        new_state = TEST_EXIT;
                        break;
                        
                    default:
                        break;
                }
                cmdptr->cmd = 0;
                break;

            case TEST_PAUSED:
                switch ( cmdptr->cmd )
                {
                    case MP3_STOP_F:
                    	new_state = TEST_STOP;
                    	break;

                    case MP3_PLAY_F:
                        new_state = TEST_SEND_DATA;
                        break;

                    case MC_MODE_DEMO_MODE_F:
                    case MC_MODE_START_MODE_F:
                    case MC_MODE_STANDBY_MODE_F:
                    case MC_MODE_MASS_MODE_F:
                    case MC_MODE_IDLE_MODE_F:
                        new_state = TEST_EXIT;
                    	break;

                    default:
                        break;
                        
                }
                break;
                
            case TEST_SONG_PLAYED:
                DBGHI( MP3, "album_table[%d] file %s: played Complete.\r\n", Mp3_Index, album_table[Mp3_Index] );
                #if (0)
                if(autoRepete == 0)
                {
                    fatapi_inc_mp3_index();
                    sendMP3Result2mc();
                }
                #endif
                
				Noise_Control();
                new_state = TEST_ENTRY;
                break;

            case TEST_STOP:
                switch ( cmdptr->cmd )
                {
                    case MP3_PLAY_F:
                        new_state = TEST_ENTRY;
                        break;

                    case MC_MODE_DEMO_MODE_F:
                    case MC_MODE_START_MODE_F:
                    case MC_MODE_STANDBY_MODE_F:
                    case MC_MODE_MASS_MODE_F:
                    case MC_MODE_IDLE_MODE_F:
                        new_state = TEST_EXIT;
                    	break;

                    default:
                        break;
                }
                break;
                
            case TEST_EXIT:
                // AMP OFF
                AmpTurnOnOff(OFF);
                ret_state = MP3_IDLE;
                break;
                
            default :
                DBGERR ( MP3, "bad test state = 0x%x, cmd = 0x%x\r\n", mp3task_state, cmdptr->cmd );
                cmdptr->cmd = 0;
                break;
        }
    }

    return ret_state;
}

/*===============================================================================================*/
