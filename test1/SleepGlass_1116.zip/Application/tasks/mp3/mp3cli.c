/*
    FreeRTOS V8.2.0rc1 - Copyright (C) 2014 Real Time Engineers Ltd.
    All rights reserved

    VISIT http://www.FreeRTOS.org TO ENSURE YOU ARE USING THE LATEST VERSION.

    This file is part of the FreeRTOS distribution.

    FreeRTOS is free software; you can redistribute it and/or modify it under
    the terms of the GNU General Public License (version 2) as published by the
    Free Software Foundation >>!AND MODIFIED BY!<< the FreeRTOS exception.

    >>!   NOTE: The modification to the GPL is included to allow you to     !<<
    >>!   distribute a combined work that includes FreeRTOS without being   !<<
    >>!   obliged to provide the source code for proprietary components     !<<
    >>!   outside of the FreeRTOS kernel.                                   !<<

    FreeRTOS is distributed in the hope that it will be useful, but WITHOUT ANY
    WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
    FOR A PARTICULAR PURPOSE.  Full license text is available on the following
    link: http://www.freertos.org/a00114.html

    1 tab == 4 spaces!

    ***************************************************************************
     *                                                                       *
     *    Having a problem?  Start by reading the FAQ "My application does   *
     *    not run, what could be wrong?".  Have you defined configASSERT()?  *
     *                                                                       *
     *    http://www.FreeRTOS.org/FAQHelp.html                               *
     *                                                                       *
    ***************************************************************************

    ***************************************************************************
     *                                                                       *
     *    FreeRTOS provides completely free yet professionally developed,    *
     *    robust, strictly quality controlled, supported, and cross          *
     *    platform software that is more than just the market leader, it     *
     *    is the industry's de facto standard.                               *
     *                                                                       *
     *    Help yourself get started quickly while simultaneously helping     *
     *    to support the FreeRTOS project by purchasing a FreeRTOS           *
     *    tutorial book, reference manual, or both:                          *
     *    http://www.FreeRTOS.org/Documentation                              *
     *                                                                       *
    ***************************************************************************

    ***************************************************************************
     *                                                                       *
     *   Investing in training allows your team to be as productive as       *
     *   possible as early as possible, lowering your overall development    *
     *   cost, and enabling you to bring a more robust product to market     *
     *   earlier than would otherwise be possible.  Richard Barry is both    *
     *   the architect and key author of FreeRTOS, and so also the world's   *
     *   leading authority on what is the world's most popular real time     *
     *   kernel for deeply embedded MCU designs.  Obtaining your training    *
     *   from Richard ensures your team will gain directly from his in-depth *
     *   product knowledge and years of usage experience.  Contact Real Time *
     *   Engineers Ltd to enquire about the FreeRTOS Masterclass, presented  *
     *   by Richard Barry:  http://www.FreeRTOS.org/contact
     *                                                                       *
    ***************************************************************************

    ***************************************************************************
     *                                                                       *
     *    You are receiving this top quality software for free.  Please play *
     *    fair and reciprocate by reporting any suspected issues and         *
     *    participating in the community forum:                              *
     *    http://www.FreeRTOS.org/support                                    *
     *                                                                       *
     *    Thank you!                                                         *
     *                                                                       *
    ***************************************************************************

    http://www.FreeRTOS.org - Documentation, books, training, latest versions,
    license and Real Time Engineers Ltd. contact details.

    http://www.FreeRTOS.org/plus - A selection of FreeRTOS ecosystem products,
    including FreeRTOS+Trace - an indispensable productivity tool, a DOS
    compatible FAT file system, and our tiny thread aware UDP/IP stack.

    http://www.FreeRTOS.org/labs - Where new FreeRTOS products go to incubate.
    Come and try FreeRTOS+TCP, our new open source TCP/IP stack for FreeRTOS.

    http://www.OpenRTOS.com - Real Time Engineers ltd license FreeRTOS to High
    Integrity Systems ltd. to sell under the OpenRTOS brand.  Low cost OpenRTOS
    licenses offer ticketed support, indemnification and commercial middleware.

    http://www.SafeRTOS.com - High Integrity Systems also provide a safety
    engineered and independently SIL3 certified version for use in safety and
    mission critical applications that require provable dependability.

    1 tab == 4 spaces!
*/


/**
 * Creates eight tasks, each of which flash an LED at a different rate.  The first 
 * LED flashes every 125ms, the second every 250ms, the third every 375ms, etc.
 *
 * The LED flash tasks provide instant visual feedback.  They show that the scheduler 
 * is still operational.
 *
 * The PC port uses the standard parallel port for outputs, the Flashlite 186 port 
 * uses IO port F.
 *
 * \page flashC flash.c
 * \ingroup DemoFiles
 * <HR>
 */

/*
Changes from V2.0.0

	+ Delay periods are now specified using variables and constants of
	  TickType_t rather than unsigned long.

Changes from V2.1.1

	+ The stack size now uses configMINIMAL_STACK_SIZE.
	+ String constants made file scope to decrease stack depth on 8051 port.
*/

#include <stdlib.h>

/* Scheduler include files. */
#include "FreeRTOS.h"
#include "task.h"

/* Demo program include files. */
#include "consol.h"
#include "mp3cli.h"
#include "debugmsgcli.h"
#include "task_cfg.h"
#include "FreeRTOS_CLI.h"
#include "fat_api.h"
#include "signals.h"
#include "mp3task_state.h"
#include "vs1011e.h"
#include "consolcli.h"

/*-----------------------------------------------------------*/

static portBASE_TYPE prvMP3StatsCommand( char *pcWriteBuffer, size_t xWriteBufferLen, const char *pcCommandString );
static portBASE_TYPE prvsdCommand( char *pcWriteBuffer, size_t xWriteBufferLen, const char *pcCommandString );

/* Structure that defines the "task-stats" command line command.  This generates
a table that gives information on each task in the system. */
static const CLI_Command_Definition_t xTaskStats =
{
	"mp3",				/* The command string to type. */
	"\r\nmp3 low/med/high/error/none :\r\n Set MP3 Debug message state.\r\n",
	prvMP3StatsCommand,	/* The function to run. */
	-1					/* 1 parameters are expected. */
						/* -1 �� ��� ���� parameter */
};

static const CLI_Command_Definition_t sdCommands =
{
	"music",				/* The command string to type. */
	"\r\nmusic list/playstop/play/stop/status/ampgain/readgain : \r\n Display mp3 relate commands.\r\n",
	prvsdCommand,	/* The function to run. */
	-1					/* 1 parameters are expected. */
						/* -1 �� ��� ���� parameter */
};

static portBASE_TYPE prvMP3StatsCommand( char *pcWriteBuffer, size_t xWriteBufferLen, const char *pcCommandString )
{
	const char *const pcHeader = "\r\nMP3 Debug display set to ";
	const char *pcParameter;
	portBASE_TYPE xParameterStringLength;

	/* Remove compile time warnings about unused parameters, and check the
	write buffer is not NULL.  NOTE - for simplicity, this example assumes the
	write buffer length is adequate, so does not check for buffer overflows. */

	( void ) xWriteBufferLen;
	configASSERT( pcWriteBuffer );

	/* Obtain the parameter string. */
	pcParameter = FreeRTOS_CLIGetParameter
						(
							pcCommandString,		/* The command string itself. */
							1,						/* ���° parameter�� �ʿ� ����?, Return the next parameter. */
							&xParameterStringLength	/* Store the parameter string length. */
						);

	if( pcParameter == NULL)
	{
		char *tt,temp[10];

		strncpy( pcWriteBuffer, xTaskStats.pcHelpString, xWriteBufferLen );
		tt = debugGetCurLevelStr(DEBUGMCMSG);
		strcat( pcWriteBuffer, "MP3 " );
		strcat( pcWriteBuffer, tt );
		strcat( pcWriteBuffer, "\r\n" );
		strcat( pcWriteBuffer, "MP3 Task State = ");
		sprintf(temp,"0x%x",mp3task_state);
		strcat( pcWriteBuffer, temp );
		strcat( pcWriteBuffer, "\r\n" );
	}
	else
	{
		if( strncmp(pcParameter,"low",3) == 0) 
		{
			//
			// ���� 2 ��° parameter�� �ʿ� �Ѱ�� 
			// 	pcParameter = FreeRTOS_CLIGetParameter(pcCommandString, 2 ,&xParameterStringLength);
			//
			debugSetCurLevel(DEBUGMP3MSG,DEBUGMSGLOW);
		}
		else if( strncmp(pcParameter,"med",3) == 0) 
		{
			debugSetCurLevel(DEBUGMP3MSG,DEBUGMSGMED);
		}
		else if( strncmp(pcParameter,"hi",2) == 0) 
		{
			debugSetCurLevel(DEBUGMP3MSG,DEBUGMSGHI);
		}
		else if( strncmp(pcParameter,"err",3) == 0) 
		{
			debugSetCurLevel(DEBUGMP3MSG,DEBUGMSGERR);
		}
		else if( strncmp(pcParameter,"none",4) == 0) 
		{
			debugSetCurLevel(DEBUGMP3MSG,DEBUGMSGNON);
		}
		strcpy( pcWriteBuffer, pcHeader );
		strcat( pcWriteBuffer, pcParameter );
		strcat( pcWriteBuffer, "\r\n" );
	}
	/* There is no more data to return after this single string, so return
	pdFALSE. */
	return pdFALSE;
}

static portBASE_TYPE prvsdCommand( char *pcWriteBuffer, size_t xWriteBufferLen, const char *pcCommandString )
{
	const char *const pcHeader = "\r\nmusic list... ";
	const char *pcParameter;
	portBASE_TYPE xParameterStringLength;
    command_type    cmd;
    uint8_t *data;

	/* Remove compile time warnings about unused parameters, and check the
	write buffer is not NULL.  NOTE - for simplicity, this example assumes the
	write buffer length is adequate, so does not check for buffer overflows. */

	( void ) xWriteBufferLen;
	configASSERT( pcWriteBuffer );

	/* Obtain the parameter string. */
	pcParameter = FreeRTOS_CLIGetParameter
						(
							pcCommandString,		/* The command string itself. */
							1,						/* ���° parameter�� �ʿ� ����?, Return the next parameter. */
							&xParameterStringLength	/* Store the parameter string length. */
						);

	if( pcParameter == NULL)
	{
		strncpy( pcWriteBuffer, sdCommands.pcHelpString, xWriteBufferLen );
	}
	else
	{
		if( strncmp(pcParameter,"list",4) == 0) 
		{
			//
			// ���� 2 ��° parameter�� �ʿ� �Ѱ�� 
			// 	pcParameter = FreeRTOS_CLIGetParameter(pcCommandString, 2 ,&xParameterStringLength);
			//
            int i;

            if(mp3task_state > MP3_INIT)
            {
            	char char_index[10];
                strcpy( pcWriteBuffer, pcHeader );
                strcat( pcWriteBuffer, "\r\n" );

                vDisplayMessage(pcWriteBuffer);

                for(i=1;i<Mp3_file_count;i++)
                {
                    if(album_table[i][0] == 0x00)
                        break;
                    
                    strcpy( pcWriteBuffer, itoa(i,char_index,10) );
                    strcat( pcWriteBuffer, " : " );
                    strcat( pcWriteBuffer, album_table[i] );
                    strcat( pcWriteBuffer, "\r\n" );
                    vDisplayMessage(pcWriteBuffer);
                }
                strcpy( pcWriteBuffer, "\r\n" );
            }
            else
            {
                strcpy( pcWriteBuffer, "\r\nSD Card Not Detected !!!\r\n");
            }
                        
		}
		else if( strncmp(pcParameter,"pause",5) == 0)
		{
            portENTER_CRITICAL();
            cmd.len = 0;
            cmd.isconst = TRUE;
            cmd.cmd = MP3_PAUSE_F;
            cmd.msg = NULL;
            xQueueSend(xMp3TaskQueue,&cmd,taskNO_BLOCK);
            portEXIT_CRITICAL();
		}
		else if( strncmp(pcParameter,"play",4) == 0) 
		{
			pcParameter = FreeRTOS_CLIGetParameter(pcCommandString, 2 ,&xParameterStringLength);
            
            if( pcParameter != NULL)
            {
                if((data = (uint8_t *)cmd_malloc(xParameterStringLength)) != NULL)
                {
                    portENTER_CRITICAL();
                    cmd.len = xParameterStringLength;
                    cmd.isconst = FALSE;
                    cmd.cmd = MP3_PLAY_INDEX_F;
                    data[0] = (uint8_t)(atoi((const char *)pcParameter));
                    cmd.msg = data;
                    xQueueSend(xMp3TaskQueue,&cmd,taskNO_BLOCK);
                    portEXIT_CRITICAL();
                }
                
                else
                {
                    DBGERR(GEN,"MEM Alloc Error!!!....\r\n");
                }
            }
		}
		else if( strncmp(pcParameter,"stop",4) == 0)
		{
            portENTER_CRITICAL();
            cmd.len = 0;
            cmd.isconst = TRUE;
            cmd.cmd = MP3_STOP_F;
            cmd.msg = NULL;
            xQueueSend(xMp3TaskQueue,&cmd,taskNO_BLOCK);
            portEXIT_CRITICAL();
		}
		else if( strncmp(pcParameter,"status",6) == 0) 
		{
            Mp3_Play_Status_Report(pcWriteBuffer);
		}
		else if( strncmp(pcParameter,"vol",3) == 0) 
		{
			pcParameter = FreeRTOS_CLIGetParameter(pcCommandString, 2 ,&xParameterStringLength);
            
            if( pcParameter != NULL)
            {
                if((data = (uint8_t *)cmd_malloc(xParameterStringLength)) != NULL)
                {
                    portENTER_CRITICAL();
                    cmd.len = xParameterStringLength;
                    cmd.isconst = FALSE;
                    cmd.cmd = MP3_SET_VOLUME_F;
                    data[0] = (uint8_t)(atoi(pcParameter));
                    cmd.msg = data;
                    xQueueSend(xMp3TaskQueue,&cmd,taskNO_BLOCK);
                    portEXIT_CRITICAL();
                }
                
                else
                {
                    DBGERR(GEN,"MEM Alloc Error!!!....\r\n");
                }
            }
		}
        else if( strncmp(pcParameter,"ampgain",7) == 0) 
		{
			pcParameter = FreeRTOS_CLIGetParameter(pcCommandString, 2 ,&xParameterStringLength);
            
            if( pcParameter != NULL)
            {
                if((data = (uint8_t *)cmd_malloc(xParameterStringLength)) != NULL)
                {
                    portENTER_CRITICAL();
                    cmd.len = xParameterStringLength;
                    cmd.isconst = FALSE;
                    cmd.cmd = MP3_AMPGAIN_F;
                    data[0] = (uint8_t)(atoi(pcParameter));
                    cmd.msg = data;
                    xQueueSend(xMp3TaskQueue,&cmd,taskNO_BLOCK);
                    portEXIT_CRITICAL();
                }
                else
                {
                    DBGERR(GEN,"MEM Alloc Error!!!....\r\n");
                }
            }
		}
        else if( strncmp(pcParameter,"readgain",8) == 0) 
		{
            portENTER_CRITICAL();
            cmd.len = 0;
            cmd.isconst = TRUE;
            cmd.cmd = MP3_AMPGAIN_READ_F;
            cmd.msg = NULL;
            xQueueSend(xMp3TaskQueue,&cmd,taskNO_BLOCK);
            portEXIT_CRITICAL();
		}
        else
        {
        }
        

	}
	/* There is no more data to return after this single string, so return
	pdFALSE. */
	return pdFALSE;
}

void mp3CLIregister(void)
{
	/* Register debug command line commands defined above. */
	FreeRTOS_CLIRegisterCommand( &xTaskStats );
	FreeRTOS_CLIRegisterCommand( &sdCommands );
}
