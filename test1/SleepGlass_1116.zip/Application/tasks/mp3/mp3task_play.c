/*===============================================================================================*/
/**
 *   @file mp3task_play.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "signals.h"
#include "command.h"
#include "task_cfg.h"
#include "mp3task_state.h"
#include "vs1011e.h"
#include "fat_api.h"
#include "debugmsgcli.h"
#include "sensor_data.h"
#include "tpa2016d2.h"

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/
            
// play state
typedef enum
{
    PLAY_INIT0 = MP3_PLAY,
    PLAY_INIT1,
    PLAY_INIT2,
    PLAY_ENTRY,
    PLAY_SEND_NOISE,
    PLAY_SEND_DATA,
    PLAY_DATA_READ,
    PLAY_HANDLE,
    PLAY_PAUSED,
    PLAY_SONG_PLAYED,
    PLAY_EXIT,
    NO_STATE
} mp3task_play_state_type;
        
        

/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/

uint32_t sendbytes;
/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/

/*===========================================================================
FUNCTION           
DESCRIPTION     
DEPENDENCIES
RETURN VALUE
===========================================================================*/
uint16_t mp3task_play_state ( command_type *cmdptr )
{
    uint16_t new_state; /* new state if any */
    uint16_t ret_state; /* return state */
    HAL_StatusTypeDef result;
    uint8_t *data = (uint8_t*)(cmdptr->msg);
    
    ret_state = MP3_NOSTATE;    /* don't assume a return state */
    new_state = mp3task_state;

    while ( new_state != NO_STATE )
    {
        mp3task_state = new_state;
        new_state = NO_STATE;

        switch ( mp3task_state )
        {
            case PLAY_INIT0:
                //Init VS1053
                Init_Codec();
                xTimerStart( xmp3GenTimer, 0 );
                mp3task_state = PLAY_INIT1;
                break;

            case PLAY_INIT1:
                switch ( cmdptr->cmd )
                {
                    case MP3_GEN_TIMER_F:
                        // AMP ON
                        AmpTurnOnOff(ON);
                        if( AmpInitialize() == FALSE)
                        {
                            new_state= PLAY_EXIT;
                        }
                        else
                        {
                            new_state = PLAY_ENTRY;
                        }
                        break;
                        
                    case MP3_SET_VOLUME_F:
                        Set_Volume(data[0]);
                        sendMP3Result2mc(Mp3_Index);
                        break;

                    case MP3_AMPGAIN_F:
               			SetAmpGain(data[0]);
                        break;
                        
                    case MP3_AMPGAIN_READ_F:
                        DBGHI(MP3,"AMP Gain is %d\r\n",ReadAmpGain());
                        break;
                                                
                    case MP3_OPEN_MUSIC_FILE_F:
                    case MP3_PLAY_INDEX_F:
                        Mp3_Index = data[0];
                        sendMP3Result2mc(Mp3_Index);
                        //new_state = PLAY_ENTRY;
                        break;
                    
                    case MC_MODE_DEMO_MODE_F:
                    case MC_MODE_START_MODE_F:
                        break;
                    
                    case MC_MODE_STANDBY_MODE_F:
                    case MC_MODE_MASS_MODE_F:
                    case MC_MODE_IDLE_MODE_F:
                        fatapi_close_current_file();
                        //ret_state = MP3_IDLE;
                        new_state = PLAY_EXIT;
                        break;

                    default:
                        break;
                }
                break;
                
            case PLAY_ENTRY :
                UpdateSensorStatus(MUSIC_FLAG_POSITION, ON);
                fatapi_close_current_file();
                //Init_Codec();

                Mp3ResetDecodeTime();
                
                if (fatapi_open_file() == FR_OK) {
                    //File opened
                    DBGHI( MP3, "album_table[%d] file : %s opened.\r\n", Mp3_Index, album_table[Mp3_Index] );
                    read_bytes_raw = fatapi_read_buffer(MP3_DATA_READ_SIZE);
					sendMP3Result2mc(Mp3_Index);
                    sendbytes = read_bytes_raw;
                    new_state = PLAY_SEND_DATA;
                }
                else
                {
                    DBGERR( MP3, "album_table[%d] file : %s open Failed!!!\r\n Returned To Idle state.\r\n", Mp3_Index, album_table[Mp3_Index] );
                    //ret_state = MP3_IDLE;
                    new_state = PLAY_EXIT;
                }
                break;

            case PLAY_SEND_NOISE:
            case PLAY_SEND_DATA:
                // send data to codec
                result = Send_Mp3_Databytes(fatapi_get_buffer_ptr(), read_bytes_raw);
                (void)result;

                if( ( sendbytes % 3200 ) == 0)
                {
                    DBGMED(MP3,"MP3 Data Send : %d bytes.\r\n",sendbytes);
                }
                
                if(read_bytes_raw < MP3_DATA_READ_SIZE)
                {
                    // start mp3 dreq polling timer
                    xTimerStart( xmp3PollTimer, 0 );
                    mp3task_state = PLAY_HANDLE;
                    
                    DBGHI(MP3,"MP3 last data bytes Send : %d bytes.\r\n",sendbytes);
                }
                else
                {
                    new_state = PLAY_DATA_READ;
                }
                break;
                
            case PLAY_DATA_READ:
                read_bytes_raw = fatapi_read_buffer(MP3_DATA_READ_SIZE);
                sendbytes += read_bytes_raw;
                
#ifdef USE_MP3_DREQ_POLL
                // start mp3 dreq polling timer
                xTimerStart( xmp3PollTimer, 0 );
                mp3task_state = PLAY_HANDLE;

#else
                if( HAL_GPIO_ReadPin(MP3_DREQ_GPIO_Port,MP3_DREQ_Pin) == GPIO_PIN_SET)
                {
                    new_state = PLAY_SEND_DATA;
                }
                else
                {
                    mp3task_state = PLAY_HANDLE;                    
                }
#endif
                DBGLOW(MP3,"MP3 Data PreBuffering: %d bytes\r\n",read_bytes_raw );
                
                break;
                
            case PLAY_HANDLE :
                {
                    boolean isRemoveCommand = TRUE;
                    
                    switch ( cmdptr->cmd )
                    {
                        case MP3_POLL_TIMER_F:
                            //check DREQ go HIGH
                            if( HAL_GPIO_ReadPin(MP3_DREQ_GPIO_Port,MP3_DREQ_Pin) == GPIO_PIN_SET)
                            {
                                if(read_bytes_raw < MP3_DATA_READ_SIZE)
                                {
                                    new_state = PLAY_SONG_PLAYED;
                                }
                                else
                                {
                                    new_state = PLAY_SEND_DATA;
                                    //sendMP3Taskcmd(MP3_DATA_LOAD_F);
                                }
                            } 
                            else
                            {
                                // start mp3 dreq polling timer
                                xTimerStart( xmp3PollTimer, 0 );
                            }                       
                            break;

                        // MP3_DREQ interrupt event occurred
                        case MP3_DREQ_OCCURRED_EVT:
                            if(read_bytes_raw < MP3_DATA_READ_SIZE)
                            {
                                new_state = PLAY_SONG_PLAYED;
                            }
                            else
                            {
                                new_state = PLAY_SEND_DATA;
                            }
                            break;
                            
                        case MP3_DATA_LOAD_F:
                            new_state = PLAY_SEND_DATA;
                            break;
                            
                        case MP3_SET_VOLUME_F:
                      		Set_Volume(data[0]);
                            sendMP3Result2mc(Mp3_Index);
                            break;

                        case MP3_AMPGAIN_F:
                   			SetAmpGain(data[0]);
                            break;

                        case MP3_AMPGAIN_READ_F:
                            DBGHI(MP3,"AMP Gain is %d\r\n",ReadAmpGain());
                            break;
                                                                                               
                        case MP3_STOP_F:
                            new_state = PLAY_EXIT;
                            break;
                            
                        case MP3_PAUSE_F:         /* rxed 0xC4 command */
                            mp3task_state = PLAY_PAUSED;
                            break;

                        case MP3_PLAY_F:
                            break;
                        
                        case MP3_SONG_PLAYED_EVT:
                            new_state = PLAY_SONG_PLAYED;
                            break;

                        case MP3_OPEN_MUSIC_FILE_F:
                        case MP3_PLAY_INDEX_F:
                            isRemoveCommand = FALSE;
                            AmpTurnOnOff(OFF);
            				sendMP3Result2mc(0);
                
                            ret_state = MP3_IDLE;                            
                            break;

                        case MC_MODE_DEMO_MODE_F:
                        case MC_MODE_START_MODE_F:
                            break;

                        case MC_MODE_STANDBY_MODE_F:
                        case MC_MODE_MASS_MODE_F:
                        case MC_MODE_IDLE_MODE_F:
                            fatapi_close_current_file();
                            //ret_state = MP3_IDLE;
                            new_state = PLAY_EXIT;
                            break;
                            
                        default:
                            break;
                    }
                    
                    if(isRemoveCommand)
                    {
                        cmdptr->cmd = 0;
                    }
                }

                break;

            case PLAY_PAUSED:
				sendMP3Result2mc(0);
                switch ( cmdptr->cmd )
                {
                    case MP3_PAUSE_F:         /* rxed 0xC4 command */
                    	break;

                    case MP3_STOP_F:
                    	new_state = PLAY_EXIT;
                    	break;

                    case MP3_PLAY_F:
						sendMP3Result2mc(Mp3_Index);
                        new_state = PLAY_SEND_DATA;
                        break;

                    case MC_MODE_DEMO_MODE_F:
                    case MC_MODE_START_MODE_F:
                    case MC_MODE_STANDBY_MODE_F:
                    case MC_MODE_MASS_MODE_F:
                    case MC_MODE_IDLE_MODE_F:
                    	break;

                    default:
                        break;
                        
                }
                break;
                
            case PLAY_SONG_PLAYED:
                DBGHI( MP3, "album_table[%d] file %s: played Complete.\r\n", Mp3_Index, album_table[Mp3_Index] );
                #if (0)
                if(autoRepete == 0)
                {
                    fatapi_inc_mp3_index();
                    sendMP3Result2mc();
                }
                #endif
                
				Noise_Control();

                //fatapi_inc_mp3_index();
                sendMP3Result2mc(Mp3_Index);
                new_state = PLAY_ENTRY;
                break;

            case PLAY_EXIT:
                // AMP OFF
                AmpTurnOnOff(OFF);
				
				sendMP3Result2mc(0);
                
                ret_state = MP3_IDLE;
                break;
                
            default :
                DBGERR ( MP3, "bad play state = 0x%x, cmd = 0x%x\r\n", mp3task_state, cmdptr->cmd );
                cmdptr->cmd = 0;
                break;
        }
    }

    return ret_state;
}

/*===============================================================================================*/
