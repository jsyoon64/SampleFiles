/*===============================================================================================*/
/**
 *   @file mp3task_state.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "signals.h"
#include "command.h"
#include "task_cfg.h"
#include "mp3task_state.h"
#include "mp3cli.h"
#include "debugmsgcli.h"
#include "vs1011e.h"
#include "fat_api.h"
#include "interface.h"

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/
uint16_t    mp3task_state = MP3_INIT;
unsigned int read_bytes_raw;

/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/

void sendMP3Taskcmd( uint16_t command)
{
	command_type	cmd;

    portENTER_CRITICAL();
	cmd.len = 0;
	cmd.msg = NULL;
    cmd.isconst = FALSE;

	cmd.cmd = command;
	xQueueSend(xMp3TaskQueue,&cmd,taskNO_BLOCK);
    portEXIT_CRITICAL();
}

void sendMP3Result2mc( uint16_t Index)
//void sendMP3Result2mc( void);
{
	command_type	cmd;
	uint8_t * data;

    if((data = (uint8_t *)cmd_malloc(FDPOS(mp3_current_status_field_type,EndofData))) != NULL)
    {
        cmd.len = FDPOS(mp3_current_status_field_type,EndofData);
        cmd.isconst = FALSE;
        cmd.cmd = MP3_CURRENT_REPORT_EVT;

        memcpy(&data[FDPOS(mp3_current_status_field_type,Mp3_Index)],
               &Index,
               FDSIZ(mp3_current_status_field_type,Mp3_Index));

        memcpy(&data[FDPOS(mp3_current_status_field_type,Mp3_SetVolume)],
               &CurrentVolume,
               FDSIZ(mp3_current_status_field_type,Mp3_SetVolume));


        cmd.msg = data;

        portENTER_CRITICAL();
        xQueueSend(xMcTaskQueue,&cmd,taskNO_BLOCK);
        portEXIT_CRITICAL();
    }

    else
    {
        DBGERR(MP3,"MEM Alloc Error!!!....\r\n");
    }
}

/*===========================================================================
FUNCTION           
DESCRIPTION     
DEPENDENCIES
RETURN VALUE
===========================================================================*/
void mp3task_state_machine (command_type *cmdptr)
{
    uint16_t  new_state;

    do
    {
        new_state = MP3_NOSTATE;

        switch ( MP3_STATE ( mp3task_state ) )
        {
            case MP3_INIT :
                new_state = mp3task_init_state ( cmdptr );        /* Process the initialization state */
                break;

            case MP3_IDLE :
                new_state = mp3task_idle_state ( cmdptr );        /* Process the idle state */
                break;

            case MP3_PLAY :
                new_state = mp3task_play_state ( cmdptr );        /* Process the play state */
                break;

            case MP3_TEST :
                new_state = mp3task_test_state ( cmdptr );        /* Process the test state */
                break;

            default:
                DBGERR(MP3, "bad state = 0x%x, cmd = 0x%x\n", mp3task_state, cmdptr->cmd );
                new_state = MP3_NOSTATE;
                break;
        }

        if ( new_state != MP3_NOSTATE )
        {
            mp3task_state = new_state;
        }

    } while ( new_state != MP3_NOSTATE );
}


/*===============================================================================================*/
