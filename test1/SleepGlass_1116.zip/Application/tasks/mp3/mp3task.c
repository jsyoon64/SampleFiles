/*===============================================================================================*/
/**
 *   @file mp3task.c
 *
 *   @version v1.0
 */
/*================================================================================================*/


/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/
/* Standard includes. */
//#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>


/* Scheduler include files. */
#include "FreeRTOS.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "queue.h"
#include "task.h"
#include "timers.h"

/* Application include files. */
#include "command.h"
#include "signals.h"
#include "consol.h"
#include "task_cfg.h"
#include "timergen.h"
#include "debugmsgcli.h"
#include "mp3cli.h"
#include "mp3task_state.h"
#include "vs1011e.h"
#include "fat_api.h"
#include "fatfs.h"


/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/
void vMP3Task( void *pvParameters );


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/
#define mp3TIMER_QUEUE_LENGTH 10


/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/


/*-----------------------------------------------------------*/
/* The handle of the queue set to which the queues are added. */
static QueueSetHandle_t xQueueSet;

static QueueHandle_t xmp3TimerQueue;

TimerHandle_t xmp3PollTimer = NULL;

TimerHandle_t xmp3GenTimer = NULL;

/*-----------------------------------------------------------*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/

/*-----------------------------------------------------------*/

void prvmp3TimerCallback( TimerHandle_t pxExpiredTimer )
{
    uint32_t ulTimerID;

    portENTER_CRITICAL();
	ulTimerID = ( uint32_t ) pvTimerGetTimerID( pxExpiredTimer );
	xQueueSend(xmp3TimerQueue,&ulTimerID,0);
    portEXIT_CRITICAL();
}

/*-----------------------------------------------------------*/
static void waitTaskStartSignal(QueueSetMemberHandle_t  xQueue)
{
	QueueSetMemberHandle_t	xActivatedMember;
	command_type			cmd;
    uint32_t                timerid;

	for(;;)
	{
		xActivatedMember =  xQueueSelectFromSet( xQueue, queueNO_DELAY );

        if( xActivatedMember == xMp3TaskQueue )
        {
            xQueueReceive( xActivatedMember, &cmd, 0 );
        }
        else if( xActivatedMember == xmp3TimerQueue )
        {
            xQueueReceive( xActivatedMember, &timerid, 0 );
            cmd.cmd = (uint16_t)timerid;
            cmd.len = 0;
			cmd.msg = NULL;
        }
		else
		{
			cmd.cmd = 0;
			cmd.msg = NULL;
		}

		if(cmd.cmd == MP3_TASK_START_CMD_F)
		{
			// start normal processing
			if( (cmd.msg != NULL) && (cmd.isconst == FALSE))
		    {
			    cmd_mfree(cmd.msg);
		    }
			break;
		}
		if( (cmd.msg != NULL) && (cmd.isconst == FALSE))
		{
			cmd_mfree(cmd.msg);
		}
        
	}
}

/*-----------------------------------------------------------*/
void mp3task_init(QueueSetMemberHandle_t  xQueue)
{
    waitTaskStartSignal(xQueue);
    /* init code for FATFS */
    MX_FATFS_Init();
	mp3CLIregister();
}


/*-----------------------------------------------------------*/

/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/
void vStartMP3Tasks( void )
{
	/*First Create the queue set such that it will be able to hold a message for
	every space in every queue in the set. */
	xQueueSet = xQueueCreateSet( taskMP3_QUEUE_LENGTH + mp3TIMER_QUEUE_LENGTH );

	/* Create the queue that we are going to use for the
	prvSendFrontAndBackTest demo. */
	xMp3TaskQueue = xQueueCreate( taskMP3_QUEUE_LENGTH, sizeof( command_type ) );
	xmp3TimerQueue = xQueueCreate( mp3TIMER_QUEUE_LENGTH, sizeof( uint32_t ) );

	/* vQueueAddToRegistry() adds the queue to the queue registry, if one is
	in use.  The queue registry is provided as a means for kernel aware
	debuggers to locate queues and has no purpose if a kernel aware debugger
	is not being used.  The call to vQueueAddToRegistry() will be removed
	by the pre-processor if configQUEUE_REGISTRY_SIZE is not defined or is
	defined to be less than 1. */
	//vQueueAddToRegistry( xMp3TaskQueue, "MP3_Queue" );
	//vQueueAddToRegistry( xmp3TimerQueue, "MP3_Queue" );

	xQueueAddToSet( xMp3TaskQueue, xQueueSet );//vQueueAddToRegistry( xPrintQueue, "CLI_Queue" );
	xQueueAddToSet( xmp3TimerQueue, xQueueSet );


	/* Create a one-shot timer for use later on in this test. */
	xmp3PollTimer = xTimerCreate(	"",				/* Text name to facilitate debugging.  The kernel does not use this itself. */
								1,					/* The period for the timer(10 msec). */
								pdFALSE,				/* Don't auto-reload - hence a one shot timer. */
								( void * )MP3_POLL_TIMER_F,	/* The timer identifier. */
								prvmp3TimerCallback );	/* The callback to be called when the timer expires. */

	xmp3GenTimer = xTimerCreate(	"",				/* Text name to facilitate debugging.  The kernel does not use this itself. */
								1000,					/* The period for the timer(10 msec). */
								pdFALSE,				/* Don't auto-reload - hence a one shot timer. */
								( void * )MP3_GEN_TIMER_F,	/* The timer identifier. */
								prvmp3TimerCallback );	/* The callback to be called when the timer expires. */

	/* Spawn the task. */
	xTaskCreate( vMP3Task, "MP3", taskMP3_TASK_STACK_SIZE, xQueueSet, taskMP3_TASK_PRIORITY, ( TaskHandle_t * ) NULL );

}


/*-----------------------------------------------------------*/

void vMP3Task( void *pvParameters )
{
	//QueueHandle_t   xQueue;		// mctask�� queue �ϳ��� ��� �Ҷ�
	QueueSetMemberHandle_t  xQueue;
	QueueSetMemberHandle_t	xActivatedMember;
	command_type	        cmd;
    uint32_t                timerid;

	xQueue = ( QueueHandle_t * ) pvParameters;

	mp3task_init(xQueue);
	
	for(;;)
	{
		// �ִ� 2000 msec���� q�� ��ٸ�.
		xActivatedMember =  xQueueSelectFromSet( xQueue, queueSHORT_DELAY );
		// xMcTaskQueue �ϳ��� ��� �� ���
		//if( xQueueReceive( xQueue, &cmd, 2000 ) == pdPASS )

		/* Which set member was selected?  Receives/takes can use a block time
        of zero as they are guaranteed to pass because xQueueSelectFromSet() would
        not have returned the handle unless something was available. */
        if( xActivatedMember == xMp3TaskQueue )
        {
            xQueueReceive( xActivatedMember, &cmd, 0 );
        }
        else if( xActivatedMember == xmp3TimerQueue )
        {
            xQueueReceive( xActivatedMember, &timerid, 0 );
            cmd.cmd = (uint16_t)timerid;
            cmd.len = 0;
			cmd.msg = NULL;
        }
		else
		{
			cmd.cmd = 0;
			cmd.msg = NULL;
		}

		//processing
		switch(cmd.cmd)
		{
			case 0:
                DBGMED(MP3,"Current MP3 Status is %x \r\n",mp3task_state);
				// No cmd rxed, 2000 msec wait timeout
				break;

            case MP3_TASK_STOP_F:
                fatapi_stop();
                break;

            case MC_MODE_TEST_MODE_F:
                mp3task_state = MP3_TEST;
                mp3task_state_machine( &cmd );
                break;

            case MP3_OPEN_MUSIC_FILE_F:    /*case 0xC1 : Open music file by ID*/
                fatapi_open_music_file(&cmd);
                // fall thru
			default:
                mp3task_state_machine( &cmd );
				break;
                
		}

		if( (cmd.msg != NULL) && (cmd.isconst == FALSE))
		{
			cmd_mfree(cmd.msg);
		}
	}
}



/*-----------------------------------------------------------*/

