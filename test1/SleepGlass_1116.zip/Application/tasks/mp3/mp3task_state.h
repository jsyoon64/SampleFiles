#ifndef MP3TASK_STATE_H_
#define MP3TASK_STATE_H_
/*===============================================================================================*/
/**
 *   @file mp3task_state.h
 *
 *   @version v1.0
 */
/*=================================================================================================


Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------


===================================================================================================*/
/* Standard includes. */

/* Scheduler include files. */
#include "FreeRTOS.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "queue.h"
#include "task.h"
#include "timers.h"

/* Application include files. */
#include "command.h"


/*=================================================================================================
 CONSTANTS
=================================================================================================*/
/* MP3TASK main states */
#define MP3_INIT            0x0100
#define MP3_IDLE            0x0200
#define MP3_PLAY            0x0300
#define MP3_TEST            0x0400
    
#define MP3_NOSTATE         0xFF00
#define MP3_EXIT            0xFF00
    
#define MP3_STATE(state)    (state & 0xFF00 )



extern uint16_t mp3task_state;
extern TimerHandle_t xmp3PollTimer;
extern TimerHandle_t xmp3GenTimer;
extern unsigned int read_bytes_raw;

/*=================================================================================================
 FUNCTION PROTOTYPES
=================================================================================================*/
void sendMP3Taskcmd( uint16_t cmd);
void sendMP3Result2mc( uint16_t Index);
//void sendMP3Result2mc( void);
void mp3task_state_machine ( command_type *cmdptr);
uint16_t mp3task_init_state ( command_type *cmdptr);
uint16_t mp3task_idle_state ( command_type *cmdptr);
uint16_t mp3task_play_state ( command_type *cmdptr);
uint16_t mp3task_test_state ( command_type *cmdptr);

/*===============================================================================================*/
#endif  /* MP3TASK_STATE_H_ */
