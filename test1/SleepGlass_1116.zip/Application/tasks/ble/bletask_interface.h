#ifndef BLETASK_INTERFACE_H
#define BLETASK_INTERFACE_H
/*===============================================================================================
 *
 *   @file bletask_interface.h
 *
 *   @version v1.0
 *
 =================================================================================================


Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*================================================================================================
 INCLUDE FILES
=================================================================================================*/

/*=================================================================================================
 CONSTANTS
=================================================================================================*/


/*=================================================================================================
 ENUMS
=================================================================================================*/


/*=================================================================================================
 STRUCTURES AND OTHER TYPEDEFS
=================================================================================================*/

typedef struct {
    uint8               DevContact[1];
    uint8               OperMode[1];
    uint8               Sensor_status[1];
    //uint8               UsartRxCmd0[1];
    uint8               BatteryStatus[1];
    uint8               Temp[1];
    uint8               AmbientLight[1];
    uint8               EDA_Value[1];
    uint8               Mp3_Index[1];
    uint8               Mp3_SetVolume[1];
    //uint8               ledFrequency[1];
    uint8               MicPeak[1];
    uint8               Heart_Rate[1];
    uint8               SpO2[1];
    uint8               bDelta[2];
    uint8               bTheta[2];
    uint8               bAlpha[2];
    uint8               bBeta[2];
    uint8               AcceXValue[2];
	uint8				AcceYValue[2];
	uint8				AcceZValue[2];
    uint8               ledBrightness[3];
    uint8               EndofData[1];
} ble_packet_msg_field_type;



typedef struct {
    uint8               UsartRxCmd0[1];
    uint8               EndofData[1];
} ble_status_event_field_type;

typedef struct {
    uint8_t             cmd[1];
    uint8_t             data1[1];
    uint8_t             data2[1];
    uint8_t             EndofData[1];
} ble_rxed_cmd_msg_field_type;

/*===============================================================================================*/
#endif  /* BLETASK_INTERFACE_H */
