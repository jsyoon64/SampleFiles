/*===============================================================================================*/
/**
 *   @file bletask.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */
//#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>


/* Scheduler include files. */
#include "FreeRTOS.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "queue.h"
#include "task.h"

/* Application include files. */
#include "command.h"
#include "signals.h"
#include "consol.h"
#include "task_cfg.h"
#include "timers.h"
#include "timergen.h"
#include "debugmsgcli.h"
#include "usart.h"
#include "blertx_packet.h"
#if defined(MURATA_BLE)
#include "ble_prop_dl.h"
#endif

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/
void vBLETask( void *pvParameters );

/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/

#define bleTIMER_QUEUE_LENGTH   10


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/
TaskHandle_t BleTaskHandle;

/*-----------------------------------------------------------*/
/* The handle of the queue set to which the queues are added. */
static QueueSetHandle_t xQueueSet;
static QueueHandle_t xbleTimerQueue;

static TimerHandle_t xbleTimer1 = NULL;
static TimerHandle_t xbleDlTimer = NULL;
/*-----------------------------------------------------------*/

/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/

/*-----------------------------------------------------------*/
void prvbleTimerCallback( TimerHandle_t pxExpiredTimer )
{
    uint32_t ulTimerID;
    
    portENTER_CRITICAL();
	ulTimerID = ( uint32_t ) pvTimerGetTimerID( pxExpiredTimer );
	xQueueSend(xbleTimerQueue,&ulTimerID,0);
    portEXIT_CRITICAL();
}

/*-----------------------------------------------------------*/
static void waitTaskStartSignal(QueueSetMemberHandle_t  xQueue)
{
	QueueSetMemberHandle_t	xActivatedMember;
	command_type			cmd;
    uint32_t                timerid;
    boolean                 isDownloadComplete = FALSE;
    boolean                 isStartCmdRxed = FALSE;

	for(;;)
	{
		xActivatedMember =  xQueueSelectFromSet( xQueue, queueSHORT_DELAY );

        if( xActivatedMember == xBleTaskQueue )
        {
            xQueueReceive( xActivatedMember, &cmd, 0 );
        }
        else if( xActivatedMember == xbleTimerQueue )
        {
            xQueueReceive( xActivatedMember, &timerid, 0 );
            cmd.cmd = (uint16_t)timerid;
            cmd.len = 0;
			cmd.msg = NULL;
        }
		else
		{
			cmd.cmd = 0;
			cmd.msg = NULL;
		}
#if defined(MURATA_BLE)
        switch(cmd.cmd)
        {
            case 0:
                break;
                
            case BLE_DL_TIMER_F:
                DBGERR(GEN,"Reset BLE Module to Profile Download.\r\n");
                resetBleModule();
                blepacket_init_usart(BLERXDOWNLOADCMDLEN);
                xTimerStart( xbleDlTimer, 0 );
                break;

            case BLE_RX_COMPLETE_F:
                xTimerStop( xbleDlTimer, 0 );
                blepacket_init_usart(BLERXDOWNLOADCMDLEN);
                isDownloadComplete = StartDownloadProc();
                if(isDownloadComplete == FALSE)
                {
                    xTimerChangePeriod(xbleDlTimer,2000,0);
                    xTimerStart( xbleDlTimer, 0 );
                }
                break;

            case BLE_TASK_START_CMD_F:
                isStartCmdRxed = TRUE;
                break;
                
            default:
                break;
        }

        if((isDownloadComplete == TRUE) && (isStartCmdRxed == TRUE))
        {
			// start normal processing
            DBGERR(GEN,"BLE Profile Download Complete.!!!\r\n");
			break;
        }
#else
		if(cmd.cmd == BLE_TASK_START_CMD_F)
		{
			// start normal processing
			break;
		}
#endif        
		if( (cmd.msg != NULL) && (cmd.isconst == FALSE))
		{
			cmd_mfree(cmd.msg);
		}
        
	}
}

/*-----------------------------------------------------------*/
void bletask_init(QueueSetMemberHandle_t  xQueue)
{
    #if defined(MURATA_BLE)
        vTaskPrioritySet(BleTaskHandle,taskMC_TASK_PRIORITY);
        DBGERR(GEN,"BLE Profile Download Start.!!!\r\n");
	    MX_USART2_UART_Init_Baud(57600);
        blepacket_init_usart(BLERXDOWNLOADCMDLEN);
        resetBleModule();
        xTimerStart( xbleDlTimer, 0 );
    #else
        MX_USART2_UART_Init();
    #endif
    
	waitTaskStartSignal(xQueue);
    
    vTaskPrioritySet(BleTaskHandle,taskBLE_TASK_PRIORITY);
    
    MX_USART2_UART_Init_Baud(57600);
    blepacket_init_usart(BLERXCMDLENGTH);
}


/*-----------------------------------------------------------*/
void vBLETask( void *pvParameters )
{
	//QueueHandle_t   xQueue;		// mctask�� queue �ϳ��� ��� �Ҷ�
	QueueSetMemberHandle_t  xQueue;
	QueueSetMemberHandle_t	xActivatedMember;
	command_type	        cmd;
    uint32_t                timerid;

	xQueue = ( QueueHandle_t * ) pvParameters;

	bletask_init(xQueue);
	
	for(;;)
	{
		// �ִ� 2000 msec���� q�� ��ٸ�.
		xActivatedMember =  xQueueSelectFromSet( xQueue, queueSHORT_DELAY );
		// xMcTaskQueue �ϳ��� ��� �� ���
		//if( xQueueReceive( xQueue, &cmd, 2000 ) == pdPASS )

		/* Which set member was selected?  Receives/takes can use a block time
        of zero as they are guaranteed to pass because xQueueSelectFromSet() would
        not have returned the handle unless something was available. */
        if( xActivatedMember == xBleTaskQueue )
        {
            xQueueReceive( xActivatedMember, &cmd, 0 );
        }
        else if( xActivatedMember == xbleTimerQueue )
        {
            xQueueReceive( xActivatedMember, &timerid, 0 );
            cmd.cmd = (uint16_t)timerid;
            cmd.len = 0;
			cmd.msg = NULL;
        }
		else
		{
			cmd.cmd = 0;
			cmd.msg = NULL;
		}

		//processing
		switch(cmd.cmd)
		{
			case 0:
				// No cmd rxed, 2000 msec wait timeout
                DBGLOW(GEN,"BLE Task Alive!!!\r\n");
				break;
                
            case BLE_SEND_F:
                // send to uart
                PacketdataSend(cmd);
#if !defined(USART_USE_TX_IT_METHOD)                
                DBGHI(GEN,"BLE Send packet complete.\r\n");
#endif
                break;
                
#if defined(USART_USE_TX_IT_METHOD)
            case BLE_TX_COMPLETE_F:
                DBGHI(GEN,"BLE Send packet complete.\r\n");
                break;
#endif

            case BLE_RX_COMPLETE_F:
                blepacket_init_usart(BLERXCMDLENGTH);
                //xTimerStop(xbleTimer1,0);
                getPacketNparse();
                break;
                
            case BLE_RXING_COMPLETE_F:
                xTimerStart(xbleTimer1,0);
                break;


            case BLE_GEN_TIMER_F:
                resetWaitingCommand();
                blepacket_init_ovr_usart(BLERXCMDLENGTH);
                break;

            case BLE_OVERRUN_ERROR_F:
                blepacket_init_ovr_usart(BLERXCMDLENGTH);
                DBGERR(GEN,"BLE USART Overrun Error.!!!\r\n");                
                break;

			default:
				break;
		}

		if( (cmd.msg != NULL) && (cmd.isconst == FALSE))
		{
			cmd_mfree(cmd.msg);
		}
	}
}


/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/
void vStartBLETasks( void )
{
    /*First Create the queue set such that it will be able to hold a message for
    every space in every queue in the set. */
    xQueueSet = xQueueCreateSet( taskBLE_QUEUE_LENGTH + bleTIMER_QUEUE_LENGTH );

    /* Create the queue that we are going to use for the
    prvSendFrontAndBackTest demo. */
    xBleTaskQueue = xQueueCreate( taskBLE_QUEUE_LENGTH , sizeof( command_type ) );
    xbleTimerQueue = xQueueCreate( bleTIMER_QUEUE_LENGTH, sizeof( uint32_t ) );

    /* vQueueAddToRegistry() adds the queue to the queue registry, if one is
    in use.  The queue registry is provided as a means for kernel aware
    debuggers to locate queues and has no purpose if a kernel aware debugger
    is not being used.  The call to vQueueAddToRegistry() will be removed
    by the pre-processor if configQUEUE_REGISTRY_SIZE is not defined or is
    defined to be less than 1. */
    //vQueueAddToRegistry( xBleTaskQueue, "BLE_Queue" );
    //vQueueAddToRegistry( xbleTimerQueue, "BLE_Queue" );

    xQueueAddToSet( xBleTaskQueue, xQueueSet );//vQueueAddToRegistry( xPrintQueue, "CLI_Queue" );
    xQueueAddToSet( xbleTimerQueue, xQueueSet );


    /* Create a one-shot timer for use later on in this test. */
    xbleTimer1 = xTimerCreate(  "",             /* Text name to facilitate debugging.  The kernel does not use this itself. */
                                500,                   /* The period for the timer(1 sec). */
                                pdFALSE,                /* Don't auto-reload - hence a one shot timer. */
                                ( void * )BLE_GEN_TIMER_F, /* The timer identifier. */
                                prvbleTimerCallback );  /* The callback to be called when the timer expires. */

    /* Create a one-shot timer for use later on in this test. */
    xbleDlTimer = xTimerCreate(  "",             /* Text name to facilitate debugging.  The kernel does not use this itself. */
                                1000,                   /* The period for the timer(1.5 sec). */
                                pdFALSE,                /* Don't auto-reload - hence a one shot timer. */
                                ( void * )BLE_DL_TIMER_F, /* The timer identifier. */
                                prvbleTimerCallback );  /* The callback to be called when the timer expires. */

    /* Spawn the task. */
    //xTaskCreate( vBLETask, "BLE", taskBLE_TASK_STACK_SIZE, xQueueSet, taskBLE_TASK_PRIORITY, ( TaskHandle_t * ) NULL );
    xTaskCreate( vBLETask, "BLE", taskBLE_TASK_STACK_SIZE, xQueueSet, taskBLE_TASK_PRIORITY, ( TaskHandle_t * ) BleTaskHandle );

}

/*-----------------------------------------------------------*/

