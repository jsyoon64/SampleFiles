#ifndef BLETASK_SIGNALS_H
#define BLETASK_SIGNALS_H
/*===============================================================================================
 *
 *   @file bletask_signals.h
 *
 *   @version v1.0
 *
 *=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/
/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Enumerations for substates                                              */

/*****************************************************
                   SIGNAL GROUP

    1. BLE TASK      : 0x7000 ~
    2. TIMER        : 0x7000 ~ 0x70FF
    3. EVENT        : 0x7100 ~ 0x71FF
    4. COMMAND      : 0x7200 ~ 0x72FF
    5. RESPONSE     : 0x7300 ~ 0x73FF

*****************************************************/

/* BLE COMMANDS. */
typedef enum
{
    BLE_DUMMY_TIMER  = 0x7000,
    BLE_GEN_TIMER_F,
    BLE_DL_TIMER_F,

    BLE_DUMMY_EVENT  = 0x7100,
	SEND_COMPLETE_EVT,

    BLE_TASK_F       = 0x7200,
    BLE_TASK_START_CMD_F,
    BLE_RESET_CMD_F,
    BLE_TASK_STOP_F,

    BLE_TX_COMPLETE_F,
    BLE_RX_COMPLETE_F,
    BLE_RXING_COMPLETE_F,
    BLE_OVERRUN_ERROR_F,
    
	BLE_READ_F,
	BLE_SEND_F,
	
    BLE_DATA_RXED_F,


    BLE_MAX_COMMAND = 0x7FFF
} bletask_signal_type;

/*===============================================================================================*/
#endif  /* BLETASK_SIGNALS_H*/
