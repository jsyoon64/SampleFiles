/*===============================================================================================*/
/**
 *   @file ble_prop_dl.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"

#if defined(MURATA_BLE)

#include "stm32f4xx_hal.h"
#include "comdef.h"
#include "signals.h"
#include "command.h"
#include "task_cfg.h"
#include "ble_profile.h"
#include "timers.h"
#include "timergen.h"
#include "debugmsgcli.h"
#include "usart.h"
#include "blertx_packet.h"
#include "ble_prop_dl.h"


/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/
ble_down_state_type DownloadState = WAIT_STX_CMD; 
uint16_t            BleProfileBinLen;

/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/

/*===========================================================================
FUNCTION           
DESCRIPTION     
DEPENDENCIES
RETURN VALUE
===========================================================================*/

void resetBleModule(void)
{
    uint8_t     sendCount=0;
    
    DownloadState = WAIT_STX_CMD; 
    BleProfileBinLen = sizeof(ble_profile_bin);
    
    BlerxData[0] = 0;

    BletxBuf[sendCount++] = 0x01; // SOH
    BletxBuf[sendCount++] = BleProfileBinLen & 0xFF;  //LSB
    BletxBuf[sendCount++] = (BleProfileBinLen >> 8 ) & 0xFF; // MSB

    //HAL_GPIO_WritePin(EMMC__RESET_GPIO_Port,EMMC__RESET_Pin,GPIO_PIN_SET);
    HAL_GPIO_WritePin(BLE_RST_GPIO_Port,BLE_RST_Pin,GPIO_PIN_SET);
    vTaskDelay(100);
    //HAL_GPIO_WritePin(EMMC__RESET_GPIO_Port,EMMC__RESET_Pin,GPIO_PIN_RESET);
    HAL_GPIO_WritePin(BLE_RST_GPIO_Port,BLE_RST_Pin,GPIO_PIN_RESET);
}


boolean StartDownloadProc(void)
{
	uint8_t     sendCount=0;
    boolean     result = FALSE;
    HAL_StatusTypeDef txStatus;
    uint8_t     rxdata;

    
    rxdata = BlerxData[0];

    if(DownloadState == WAIT_STX_CMD)
    {
        if(rxdata == 0x02) // STX
        {
            DownloadState = WAIT_ACK_CMD; 
            HAL_UART_Transmit(&huart2, BletxBuf, 3, USART2_TIMEOUT);
        }
    }
    else if(DownloadState == WAIT_ACK_CMD)
    {
        if(rxdata == 0x06) // STX
        {
            txStatus = HAL_UART_Transmit(&huart2, (uint8_t *)ble_profile_bin, BleProfileBinLen, 12000);
            if(txStatus == HAL_OK)
            {
                DownloadState = WAIT_CRC_CMD; 
            }
        }
    }
    else if (DownloadState == WAIT_CRC_CMD)
    {
        sendCount=0;
        BletxBuf[sendCount++] = 0x06; // ACK
        HAL_UART_Transmit(&huart2, BletxBuf, sendCount, USART2_TIMEOUT);
        DownloadState = SEND_ACK_CMD; 
        result = TRUE;
    }

    return result;
}

#endif
/*===============================================================================================*/
