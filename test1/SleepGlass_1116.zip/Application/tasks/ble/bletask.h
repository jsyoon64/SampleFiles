#ifndef BLETASK_H
#define BLETASK_H

void vStartBLETasks( void );

#endif

