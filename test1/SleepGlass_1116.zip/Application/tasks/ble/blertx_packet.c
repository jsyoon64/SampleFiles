/*===============================================================================================*/
/**
 *   @file blertx_packet.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "comdef.h"
#include "signals.h"
#include "command.h"
#include "task_cfg.h"
#include "interface.h"
#include "stm32f4xx_hal.h"
#include "usart.h"
#include "blertx_packet.h"
#include "mc_data.h"
#include "debugmsgcli.h"

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/
static uint8_t Packet_Count=0;
uint8_t BletxBuf[MAXTXBUFFERSIZE];
uint8_t BlerxBuf[MAXRXBUFFERSIZE];
uint8_t BlerxData[MAXRXBUFFERSIZE];

    
/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/

/*===========================================================================
FUNCTION           
DESCRIPTION     
DEPENDENCIES
RETURN VALUE
===========================================================================*/

/*
uint8   *ptrMsg = &rx_ptr->msg[FDPOS(sms_msg_field_type,rxmsg)];
int     len     = rx_ptr->len - FDPOS(sms_msg_field_type,rxmsg); 

memcpy(tempid,&pMsg[4], FDSIZ(bis_beacon_msg_field_type,BeaconID));
*/


/* @brief 	format data in 20bytes and send through BLE
 *
 * @param	OperMode: mode that mask is in (IDLE, START, CHARGING,..)
 * @param	DevContact: EEG is contact or not (0: not contact, 1: contact)
 *
 * @retvl	none
 */
 
void PacketdataSend(command_type command)
{
	uint8_t     sendCount;
    uint8_t     DevContact,OperMode;
    //uint8_t     PCbasedPacketCount = 0;
        
	sendCount = 0;

    uint8_t *data = (uint8_t *)command.msg;

	BletxBuf[sendCount++] = 0xFF; //1
	BletxBuf[sendCount++] = 0xFE;	//2
	BletxBuf[sendCount++] = Packet_Count; //3

	DevContact= (uint8_t)data[FDPOS(ble_packet_msg_field_type,DevContact)];//3
	BletxBuf[sendCount++] = DevContact;
	
	OperMode = (uint8_t)data[FDPOS(ble_packet_msg_field_type,OperMode)];//4
    BletxBuf[sendCount++] = OperMode;
    
    BletxBuf[sendCount++]= (uint8_t)data[FDPOS(ble_packet_msg_field_type,Sensor_status)];//5

	BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,BatteryStatus)];//6
	BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,Temp)];//7
	BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,AmbientLight)];//8
	BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,EDA_Value)];//9
	BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,Mp3_Index)];//10
	BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,Mp3_SetVolume)];//11
	

	/*  -- Common --
		ChgStatus : m_ChgStatus
		Mp3_Index
		SetVolume
		Mp3_total_count;
		ledSet_red;
		ledSet_grn;
		ledSet_blu;
	*/

    memset(&BletxBuf[sendCount],0x00,17);

    switch(OperMode& 0x07) 
    {
        default:
            sendCount += 14; 

            // bypass LEDR,G,B Index
            sendCount += 3;
            break;
            
		case IDLE_MODE :
            sendCount += 14; 

            // LEDR,G,B Index
            //memcpy(&BletxBuf[sendCount],&data[FDPOS(ble_packet_msg_field_type,ledBrightness)],FDSIZ(ble_packet_msg_field_type,ledBrightness));
			//IDLE_MODE LED Index data delete
            sendCount += 3;
            break;
            
		case STANBY_MODE :

			// bypass EEG, PPG, MIC, Acc Index
			sendCount +=14;
			// bypass LEDR,G,B Index
			sendCount += 3;
		    break;
            
		case  START_MODE:
			{
				BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,MicPeak)];//12
				BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,Heart_Rate)];//13
				BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,SpO2)];//14
               
				BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,bDelta)+1];//15
				BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,bDelta)];//16
                BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,bTheta)+1];//17
				BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,bTheta)];//18
                BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,bAlpha)+1];//19
				BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,bAlpha)];//20
                BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,bBeta)+1];//21
				BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,bBeta)];//22

                
                memcpy(&BletxBuf[sendCount],&data[FDPOS(ble_packet_msg_field_type,AcceXValue)],FDSIZ(ble_packet_msg_field_type,AcceXValue));
                sendCount += 2; // 23,24
                memcpy(&BletxBuf[sendCount],&data[FDPOS(ble_packet_msg_field_type,AcceYValue)],FDSIZ(ble_packet_msg_field_type,AcceYValue));
                sendCount += 2; // 25,26
                memcpy(&BletxBuf[sendCount],&data[FDPOS(ble_packet_msg_field_type,AcceZValue)],FDSIZ(ble_packet_msg_field_type,AcceZValue));
                sendCount += 2; // 27,28               
                
                memcpy(&BletxBuf[sendCount],&data[FDPOS(ble_packet_msg_field_type,ledBrightness)],FDSIZ(ble_packet_msg_field_type,ledBrightness));
                sendCount += 3; //29,30,31
			}
		    break;
            
        case  DEMO_MODE:
            BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,MicPeak)];//12
			BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,Heart_Rate)];//13
			BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,SpO2)];//14
               
			BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,bDelta)+1];//15
			BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,bDelta)];//16
            BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,bTheta)+1];//17
			BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,bTheta)];//18
            BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,bAlpha)+1];//19
			BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,bAlpha)];//20
            BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,bBeta)+1];//21
			BletxBuf[sendCount++] = (uint8_t)data[FDPOS(ble_packet_msg_field_type,bBeta)];//22
				
            memcpy(&BletxBuf[sendCount],&data[FDPOS(ble_packet_msg_field_type,AcceXValue)],FDSIZ(ble_packet_msg_field_type,AcceXValue));
            sendCount += 2; // 23,24
            memcpy(&BletxBuf[sendCount],&data[FDPOS(ble_packet_msg_field_type,AcceYValue)],FDSIZ(ble_packet_msg_field_type,AcceYValue));
            sendCount += 2; // 25,26
            memcpy(&BletxBuf[sendCount],&data[FDPOS(ble_packet_msg_field_type,AcceZValue)],FDSIZ(ble_packet_msg_field_type,AcceZValue));
            sendCount += 2; // 27,28               
                
            memcpy(&BletxBuf[sendCount],&data[FDPOS(ble_packet_msg_field_type,ledBrightness)],FDSIZ(ble_packet_msg_field_type,ledBrightness));
            sendCount += 3; //26, 27, 28
            
            break;
            
	}

	BletxBuf[sendCount++] = 0;

#if defined(USART_USE_DMA_METHOD)    
    HAL_UART_Transmit_DMA(&huart2, BletxBuf, sendCount);
#else
    #if defined(USART_USE_TX_IT_METHOD)
        HAL_UART_Transmit_IT(&huart2, BletxBuf, sendCount);
    #else
        HAL_UART_Transmit(&huart2, BletxBuf, sendCount, USART2_TIMEOUT);
    #endif
#endif    

    // for next packet use
    Packet_Count++;
}


static boolean SohHeaderFounded = FALSE;
static boolean SohHeader1Rxed = FALSE;
static uint8_t  RxCount = 0;

void getPacketNparse(void)
{
    uint8_t index = 0;

    do
    {
        if(SohHeaderFounded == TRUE)
        {
            BlerxBuf[RxCount++] = BlerxData[index];
            
            if(RxCount >= BLE_RX_CMD_LEN)
            {
                SohHeaderFounded = FALSE;
                SohHeader1Rxed = FALSE;
                RxCount = 0;
                parsePacket();
            }
        }
        else
        {
            if(SohHeader1Rxed == TRUE)
            {
                SohHeader1Rxed = FALSE;
                if(BlerxData[index] == SOH_HEADER2)
                {
                    SohHeaderFounded = TRUE;
                    RxCount = 0;
                }
                else if(BlerxData[index] == SOH_HEADER1)
                {
                        SohHeader1Rxed = TRUE;
                }
            }
            else
            {
                if(BlerxData[index] == SOH_HEADER1)
                {
                    SohHeader1Rxed = TRUE;
                }
            }
        }
    }while(++index < BLERXCMDLENGTH);
}


void resetWaitingCommand(void)
{
    SohHeaderFounded = FALSE;
    SohHeader1Rxed = FALSE;
}


/*
 * @brief	do command send from mobile
 *
 * @param	rxcmd: code of command after ParsingPacket()
 *
 * @retvl	none
 */
void parsePacket()
{
    command_type cmd;

    #if 0
        uint8_t *rdata = (uint8_t *)command.msg;
        
        uint8_t rxcmd = (uint8_t)rdata[FDPOS(ble_rxed_cmd_msg_field_type,cmd)];
        uint8_t data = (uint8_t)rdata[FDPOS(ble_rxed_cmd_msg_field_type,data1)];
    #else
        uint8_t rxcmd = BlerxBuf[0];
        uint8_t data  = BlerxBuf[1];
    #endif
    uint8_t *cmdmsg;

    DBGHI(GEN,"BLE Rxed Command. 0x%x 0x%x\r\n",BlerxBuf[0],BlerxBuf[1]);

    if((cmdmsg = (uint8_t *)cmd_malloc(FDPOS(gen_cmd_msg_field_type,EndofData))) != NULL)
    {
        cmd.len = FDPOS(gen_cmd_msg_field_type,EndofData);
        cmd.isconst = FALSE;
        cmd.cmd = 0;

        cmdmsg[FDPOS(gen_cmd_msg_field_type,data1)] = rxcmd;        
        cmdmsg[FDPOS(gen_cmd_msg_field_type,data2)] = data;
        
        cmd.msg = cmdmsg;

        switch (rxcmd) 
        {
            /* Music Commands */
            case 0xC1 ://Open music file by ID
                cmd.cmd = MP3_OPEN_MUSIC_FILE_F;
                break;
                
            case 0xC2 ://Set sound volume
                cmd.cmd = MP3_SET_VOLUME_F;
                break;
                
            case 0xC3 ://Set device to Start Mode
                cmd.cmd = MP3_LISTS_REQ_F;
                break;
                
            case 0xC4 ://If music is on -> off and vice versa
                switch (data)
                {
                	case 0x00 :
                		cmd.cmd = MP3_STOP_F;
                		break;
                	case 0x01 :
                		cmd.cmd = MP3_PAUSE_F;
                		break;
                	case 0x02 :
                		cmd.cmd = MP3_PLAY_F;
                		break;
                	default :
                		break;
                }
                break;

            /* LED Control commands */
            case 0xC5 :     //Set LED red intensity (0~99)
                cmd.cmd = LED_BRIGHT_F;
                cmdmsg[FDPOS(gen_cmd_msg_field_type,data3)] = (uint8_t)TIM_CHANNEL_1;
                break;
                
            case 0xC6 :     //Set LED green intensity (0~99)
                cmd.cmd = LED_BRIGHT_F;
                cmdmsg[FDPOS(gen_cmd_msg_field_type,data3)] = (uint8_t)TIM_CHANNEL_2;
                break;

            case 0xC7 :     //Set LED blue intensity (0~99)
                cmd.cmd = LED_BRIGHT_F;
                cmdmsg[FDPOS(gen_cmd_msg_field_type,data3)] = (uint8_t)TIM_CHANNEL_3;
                break;

            case 0xC8 :     //Set LED frequency
                cmd.cmd = LED_FREQ_F;
                break;

            case 0xC9 :     //Turn off LED and vice versa
                switch (data)
                {
                	case 0x00 :
                	case 0x01 :
                		cmd.cmd = LED_ONOFF_F;
                		break;
                        
                	case 0xA0 :
                        cmdmsg[FDPOS(gen_cmd_msg_field_type,data2)] = (uint8_t)TIM_CHANNEL_1;
                        cmd.cmd = LED_OFF_F;
                		break;
                    case 0xB0 :
                        cmdmsg[FDPOS(gen_cmd_msg_field_type,data2)] = (uint8_t)TIM_CHANNEL_2;
                        cmd.cmd = LED_OFF_F;
                		break;
                    case 0xC0 :
                        cmdmsg[FDPOS(gen_cmd_msg_field_type,data2)] = (uint8_t)TIM_CHANNEL_3;
                		cmd.cmd = LED_OFF_F;
                		break;

                	case 0xA1 :
                        cmdmsg[FDPOS(gen_cmd_msg_field_type,data2)] = (uint8_t)TIM_CHANNEL_1;    
                		cmd.cmd = LED_ON_F;
                        break;
                    case 0xB1 :
                        cmdmsg[FDPOS(gen_cmd_msg_field_type,data2)] = (uint8_t)TIM_CHANNEL_2;    
                		cmd.cmd = LED_ON_F;
                        break;                        
                    case 0xC1 :
                        cmdmsg[FDPOS(gen_cmd_msg_field_type,data2)] = (uint8_t)TIM_CHANNEL_3;    
                		cmd.cmd = LED_ON_F;
                		break;
                        
                	default :
                		break;
                }
                break;

            /* System Commands */    
            case 0xCA :     // turn off device
                cmd.cmd = MC_POWEROFF_CMD_F;
                break;
                
            case 0xCB : //When this command is received, 0x00 -> Do nothing (default); See Working modes Transition for details
                cmd.cmd = MC_MODE_CHG_F;
                break;
                
            case 0xCC : //When this command is received, turn PPG module ON/OFF based on data 0x00 -> OFF; 0x01 --> ON
                cmd.cmd = MC_PPG_CONTROL_F;
                break;
                
            case 0xCD : //When this command is received, turn Temperature module ON/OFF based on data 0x00 -> OFF; 0x01 --> ON
                cmd.cmd = MC_TEMP_CONTROL_F;
                break;
                
            case 0xCE : //When this command is received, turn EDA module ON/OFF based on data 0x00 -> OFF; 0x01 --> ON
                cmd.cmd = MC_EDA_CONTROL_F;
                break;
                
            case 0xCF : // When this command is received, turn Ambient light module ON/OFF based on data  0x00 -> OFF; 0x01 --> ON
                cmd.cmd = AML_CONTROL_F;
                break;
                
            case 0xD1 : // Wait for EEG to stablize, time length based on data: 8-bit time. Unit: 1s
                cmd.cmd = MC_WAIT_EEG_STAB_TIME_F;
                break;
                
            default : 
                break;                    
        }

        if(cmd.cmd != 0)
        {
            portENTER_CRITICAL();
            xQueueSend(xMcTaskQueue,&cmd,taskNO_BLOCK);
            portEXIT_CRITICAL();
        }
        else
        {
            cmd_mfree(cmd.msg);
        }
    }
    else
    {
        DBGERR(GEN,"MEM Alloc Error!!!....\r\n");
    }
}


void blepacket_init_usart(uint16_t packetcount)
{
#if defined(USART_USE_DMA_METHOD)    
    HAL_UART_Receive_DMA(&huart2, BlerxData, packetcount);
#else
    HAL_UART_Receive_IT(&huart2, BlerxData, packetcount);
#endif    
}

void blepacket_init_ovr_usart(uint16_t packetcount)
{
#if defined(USART_USE_DMA_METHOD)  
    #error " Override Function Must be ...."  
    //HAL_UART_Receive_DMA(&huart2, BlerxData, packetcount);
#else
    HAL_UART_Receive_Override_IT(&huart2, BlerxData, packetcount);
#endif    
}



/*===============================================================================================*/
