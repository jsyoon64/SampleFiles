#ifndef BLERTX_PACKET_H_
#define BLERTX_PACKET_H_
/*===============================================================================================*/
/**
 *   @file blertx_packet.h
 *
 *   @version v1.0
 */
/*=================================================================================================


Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------


===================================================================================================*/
/* Standard includes. */

/* Scheduler include files. */

/* Application include files. */
#include "target.h"

/*=================================================================================================
 CONSTANTS
=================================================================================================*/
#define USART2_TIMEOUT      300
#define MAXTXBUFFERSIZE     40
#define MAXRXBUFFERSIZE     20

#define BLERX_HEADER_LEN    2
#define BLE_RX_CMD_LEN      2

#if defined (USART_RX_PROCESS_SINGLE_BYTE)
    #define BLERXCMDLENGTH      1
#else
    #define BLERXCMDLENGTH      (BLERX_HEADER_LEN + BLE_RX_CMD_LEN)
#endif
#define BLERXDOWNLOADCMDLEN     1


#define SOH_HEADER1     0xFF
#define SOH_HEADER2     0xFE

/*=================================================================================================
 FUNCTION PROTOTYPES
=================================================================================================*/
extern uint8_t BletxBuf[MAXTXBUFFERSIZE];
extern uint8_t BlerxBuf[MAXRXBUFFERSIZE];

extern uint8_t BlerxData[MAXRXBUFFERSIZE];

void PacketdataSend(command_type command);

void getPacketNparse(void);
void resetWaitingCommand(void);

void parsePacket();
void blepacket_init_usart(uint16_t packetcount);
void blepacket_init_ovr_usart(uint16_t packetcount);

/*===============================================================================================*/
#endif  /* BLERTX_PACKET_H_ */
