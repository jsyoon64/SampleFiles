#ifndef _FFT_H_
#define _FFT_H_
/*===============================================================================================*/
/**
 *   @file fft.h
 *
 *   @version v1.0
 */
/*=================================================================================================


Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------


===================================================================================================*/

/* Standard includes. */

/* Scheduler include files. */
#include "FreeRTOS.h"


/* Application include files. */
#include "target.h"
#include "comdef.h"
#include "afe4400.h"


/*=================================================================================================
 CONSTANTS
=================================================================================================*/



/*=================================================================================================
 STRUCTURES AND OTHER TYPEDEFS
=================================================================================================*/

typedef struct 
{
    float real; 
    float imag;
} COMPLEX;


//struct for storaging EEG data
struct eeg_data {
	int16_t bDelta;
	int16_t bTheta;
	int16_t bAlpha;
	int16_t bBeta;
};

/*=================================================================================================
 FUNCTION PROTOTYPES
=================================================================================================*/
boolean HeartBeat_Spo2(ppg_data_type *buf, uint16_t len );
boolean fft_eeg(float *buf, uint16_t len);
void FFTVariableInit(void);
void InitEEGData(void);
void InitPPGData(void);
void InitPPGRingbuf();
void InitSpO2Ringbuf();


extern uint8_t SpO2_orig, SpO2, SpO2_Smooth, Heart_Rate, Heart_Rate_Smooth;
extern struct eeg_data eegAnalData;
/*===============================================================================================*/
#endif  /* _FFT_H_ */
