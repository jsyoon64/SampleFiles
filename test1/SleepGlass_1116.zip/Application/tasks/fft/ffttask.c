/*
        1 tab == 4 spaces!
*/

/* Standard includes. */
//#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>


/* Scheduler include files. */
#include "FreeRTOS.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "queue.h"
#include "task.h"

/* Application include files. */
#include "target.h"
#include "comdef.h"
#include "command.h"
#include "signals.h"
#include "consol.h"
#include "task_cfg.h"
#include "timers.h"
#include "timergen.h"
#include "debugmsgcli.h"
#include "afe4400.h"
#include "ads1292.h"
#include "fft.h"
#include "interface.h"

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/
void vFFTTask( void *pvParameters );

/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/

/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/
#define fftNO_BLOCK			( 0 )
#define fftTIMER_QUEUE_LENGTH 10

/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/
/*-----------------------------------------------------------*/
/* The handle of the queue set to which the queues are added. */
static QueueSetHandle_t xQueueSet;
static QueueHandle_t xfftTimerQueue;

static TimerHandle_t xfftTimer1 = NULL;

boolean isPpg_fft_data_ready = FALSE;
boolean isEeg_fft_data_ready = FALSE;
/*-----------------------------------------------------------*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/
void prvfftTimerCallback( TimerHandle_t pxExpiredTimer )
{
    uint32_t ulTimerID;

	ulTimerID = ( uint32_t ) pvTimerGetTimerID( pxExpiredTimer );
    portENTER_CRITICAL();
	xQueueSend(xfftTimerQueue,&ulTimerID,0);
    portEXIT_CRITICAL();
}


/*-----------------------------------------------------------*/

static void waitTaskStartSignal(QueueSetMemberHandle_t  xQueue)
{
	QueueSetMemberHandle_t	xActivatedMember;
	command_type			cmd;
    uint32_t                timerid;

	for(;;)
	{
		xActivatedMember =  xQueueSelectFromSet( xQueue, queueNO_DELAY );

        if( xActivatedMember == xFftTaskQueue )
        {
            xQueueReceive( xActivatedMember, &cmd, 0 );
        }
        else if( xActivatedMember == xfftTimerQueue )
        {
            xQueueReceive( xActivatedMember, &timerid, 0 );
            cmd.cmd = (uint16_t)timerid;
            cmd.len = 0;
			cmd.msg = NULL;
        }
		else
		{
			cmd.cmd = 0;
			cmd.msg = NULL;
		}

		if(cmd.cmd == FFT_TASK_START_CMD_F)
		{
			// start normal processing
			break;
		}
		if( (cmd.msg != NULL) && (cmd.isconst == FALSE))
		{
			cmd_mfree(cmd.msg);
		}
        
	}
}

/*-----------------------------------------------------------*/
void ffttask_init(QueueSetMemberHandle_t  xQueue)
{
    FFTVariableInit();

	waitTaskStartSignal(xQueue);
	
	/* Start the one shot timer and check that it reports its state correctly. */
	xTimerStart( xfftTimer1, 0 );
    
    InitPPGRingbuf();
    InitSpO2Ringbuf();
        
}

/*-----------------------------------------------------------*/
#if (0)
void sendToMcCmdFft(uint16_t command, void * buf, uint16_t len)
{
	command_type	cmd;

    portENTER_CRITICAL();
	cmd.len = len;
	cmd.msg = buf;
    cmd.isconst = FALSE;
	cmd.cmd = command;
	xQueueSend(xMcTaskQueue,&cmd,fftNO_BLOCK);
    portEXIT_CRITICAL();
}
#endif

/*-----------------------------------------------------------*/
boolean sendToFftCompleteCmd(void)
{
	command_type	cmd;
    uint16_t        fft_resp_buf_size;
    uint8_t         *resp_buf;
    //uint16_t        index=0;
    
    fft_resp_buf_size = FDPOS(fft_result_resp_field_type,EndofData);

    if( (resp_buf = cmd_malloc(fft_resp_buf_size + 5)) != NULL)
    {
        memset(resp_buf,0x00,fft_resp_buf_size);
        resp_buf[FDPOS(fft_result_resp_field_type,Heart_Rate)] = Heart_Rate_Smooth;
        resp_buf[FDPOS(fft_result_resp_field_type,SpO2)] = SpO2_Smooth;
        memcpy(&resp_buf[FDPOS(fft_result_resp_field_type,bDelta)],&eegAnalData.bDelta, FDSIZ(fft_result_resp_field_type,bDelta));
        memcpy(&resp_buf[FDPOS(fft_result_resp_field_type,bTheta)],&eegAnalData.bTheta, FDSIZ(fft_result_resp_field_type,bTheta));
        memcpy(&resp_buf[FDPOS(fft_result_resp_field_type,bAlpha)],&eegAnalData.bAlpha, FDSIZ(fft_result_resp_field_type,bAlpha));
        memcpy(&resp_buf[FDPOS(fft_result_resp_field_type,bBeta)],&eegAnalData.bBeta, FDSIZ(fft_result_resp_field_type,bBeta));

        portENTER_CRITICAL();
        cmd.len = fft_resp_buf_size;
        cmd.msg = resp_buf;
        cmd.isconst = FALSE;
        cmd.cmd = FFT_COMPLETE_EVT;
        xQueueSend(xMcTaskQueue,&cmd,fftNO_BLOCK);
        portEXIT_CRITICAL();
        
        return TRUE;
    }
    else
    {
        DBGERR(GEN,"MEM Alloc Error!!!....\r\n");
    }

    return FALSE;
}

/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/
void vStartFFTTasks( void )
{
	/*First Create the queue set such that it will be able to hold a message for
	every space in every queue in the set. */
	xQueueSet = xQueueCreateSet( taskFFT_QUEUE_LENGTH + fftTIMER_QUEUE_LENGTH );

	/* Create the queue that we are going to use for the
	prvSendFrontAndBackTest demo. */
	xFftTaskQueue = xQueueCreate( taskFFT_QUEUE_LENGTH , sizeof( command_type ) );
	xfftTimerQueue = xQueueCreate( fftTIMER_QUEUE_LENGTH, sizeof( uint32_t ) );

	/* vQueueAddToRegistry() adds the queue to the queue registry, if one is
	in use.  The queue registry is provided as a means for kernel aware
	debuggers to locate queues and has no purpose if a kernel aware debugger
	is not being used.  The call to vQueueAddToRegistry() will be removed
	by the pre-processor if configQUEUE_REGISTRY_SIZE is not defined or is
	defined to be less than 1. */
	//vQueueAddToRegistry( xFftTaskQueue, "FFT_Queue" );
	//vQueueAddToRegistry( xfftTimerQueue, "FFT_Queue" );

	xQueueAddToSet( xFftTaskQueue, xQueueSet );//vQueueAddToRegistry( xPrintQueue, "CLI_Queue" );
	xQueueAddToSet( xfftTimerQueue, xQueueSet );


	/* Create a one-shot timer for use later on in this test. */
	xfftTimer1 = xTimerCreate(	"",				/* Text name to facilitate debugging.  The kernel does not use this itself. */
								1000,					/* The period for the timer(1 sec). */
								pdFALSE,				/* Don't auto-reload - hence a one shot timer. */
								( void * )FFT_TIMER_1SEC_F,	/* The timer identifier. */
								prvfftTimerCallback );	/* The callback to be called when the timer expires. */

	/* Spawn the task. */
	xTaskCreate( vFFTTask, "FFT", taskFFT_TASK_STACK_SIZE, xQueueSet, taskFFT_TASK_PRIORITY, ( TaskHandle_t * ) NULL );

}

/*-----------------------------------------------------------*/
void vFFTTask( void *pvParameters )
{
	//QueueHandle_t   xQueue;		// mctask�� queue �ϳ��� ��� �Ҷ�
	QueueSetMemberHandle_t  xQueue;
	QueueSetMemberHandle_t	xActivatedMember;
	command_type	        cmd;
    uint32_t                timerid;

    
	xQueue = ( QueueHandle_t * ) pvParameters;

	ffttask_init(xQueue);
	
	for(;;)
	{
		// �ִ� 2000 msec���� q�� ��ٸ�.
		xActivatedMember =  xQueueSelectFromSet( xQueue, queueSHORT_DELAY );
		// xMcTaskQueue �ϳ��� ��� �� ���
		//if( xQueueReceive( xQueue, &cmd, 2000 ) == pdPASS )

		/* Which set member was selected?  Receives/takes can use a block time
        of zero as they are guaranteed to pass because xQueueSelectFromSet() would
        not have returned the handle unless something was available. */
        if( xActivatedMember == xFftTaskQueue )
        {
            xQueueReceive( xActivatedMember, &cmd, 0 );
        }
        else if( xActivatedMember == xfftTimerQueue )
        {
            xQueueReceive( xActivatedMember, &timerid, 0 );
            cmd.cmd = (uint16_t)timerid;
            cmd.len = 0;
			cmd.msg = NULL;
        }
		else
		{
			cmd.cmd = 0;
			cmd.msg = NULL;
		}

		//processing
		switch(cmd.cmd)
		{
			case 0:
				// No cmd rxed, 2000 msec wait timeout
                DBGMED(GEN,"FFT Task Alive!!!\r\n");
				break;

            case FFT_PPG_REQ_F:
                isPpg_fft_data_ready = HeartBeat_Spo2( (ppg_data_type *)cmd.msg, cmd.len);
                DBGMED(GEN,"PPG FFT Result: Heart Rate:%d, Spo2:%d\r\n",Heart_Rate,SpO2);
                DBGTEST(2,"PPG_Heart_Rate&SpO2:(%d,%d)SpO2_orig: %d\r\n",Heart_Rate,SpO2, SpO2_orig);
                
                DBGHI(GEN,"Smoothing Result: Heart Rate:%d, Spo2:%d\r\n",Heart_Rate_Smooth,SpO2_Smooth);
                DBGTEST(2,"Smoothing PPG_Heart_Rate&SpO2:(%d,%d)\r\n",Heart_Rate_Smooth,SpO2_Smooth);
                break;

                
            case FFT_EEG_REQ_F:
                isEeg_fft_data_ready = fft_eeg((float *)cmd.msg, 512);
                DBGHI(GEN,"EEG FFT Result: Delta:%d, Theta:%d, Alpha:%d, Beta:%d\r\n",eegAnalData.bDelta,eegAnalData.bTheta,eegAnalData.bAlpha,eegAnalData.bBeta);
                DBGTEST(3,"EEG_D_T_A_B:(%d,%d,%d,%d)\r\n",eegAnalData.bDelta,eegAnalData.bTheta,eegAnalData.bAlpha,eegAnalData.bBeta);

                // send FFT_COMPLETE_EVT to mc
                sendToFftCompleteCmd();
                DBGMED(GEN,"Send FFT result to MC\r\n");
                break;
                
            case FFT_PPG_DATA_INIT_F:
                InitPPGData();
                break;
                
            case FFT_EEG_DATA_INIT_F:
                InitEEGData();
                break;

            case MC_MODE_IDLE_MODE_F:
                InitPPGRingbuf();
                InitSpO2Ringbuf();
                break;

			default:
				break;
		}

		if( (cmd.msg != NULL) && (cmd.isconst == FALSE))
		{
			cmd_mfree(cmd.msg);
		}
	}
}



/*-----------------------------------------------------------*/

