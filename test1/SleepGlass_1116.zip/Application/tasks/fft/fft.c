/*===============================================================================================*/
/**
 *   @file fft.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.

===================================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */
#include <math.h>
#include <string.h>

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "fft.h"
#include "debugmsgcli.h"
#include "ringbuf.h"

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/
//#define HEARTBEAT_DEBUG

/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/
#define FFT_SIZE			512
#define pi					3.1416
    
#define DELTA_LIMIT			8//5 *2
#define THETA_LIMIT			16//11 *2
#define ALPHA_LIMIT			24//17 *2
#define BETA_LIMIT			60//39 *2

// PPG
#define PPG_fs  25 //sampling rate
#define PPG_FFT_SIZE	128 //FFT size
#define start_index  5

#define MEDIAN_SAMPLE_SIZE	(PPG_FFT_SIZE-PPG_fs/5)

#define MAX_RINGBUF_SIZE    10

/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/
#define MAX_PEAK_BUFF_SIZE  ((PPG_FFT_SIZE/PPG_fs)+1)

/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/
COMPLEX w[FFT_SIZE/2], samples[FFT_SIZE];
COMPLEX temp1, temp2;

volatile float eegTheta, eegDelta, eegAlpha, eegBeta, eegGamma, eegFFTMax;

struct eeg_data eegAnalData;
    
uint8_t SpO2_orig, SpO2, SpO2_Smooth, Heart_Rate, Heart_Rate_Smooth;

uint16_t peak[MAX_PEAK_BUFF_SIZE]={0};
uint16_t peak_index = 0;
uint16_t sample_over_count=0;  

/* local value */
uint16_t localpeak[MAX_PEAK_BUFF_SIZE]={0};
float localpeak_value[MAX_PEAK_BUFF_SIZE]={0};
float PPG_median[MEDIAN_SAMPLE_SIZE];

ringbuf_t ppgRB, spo2RB;

/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/

/*
 * @brief: function for calculating FFT
 *
 * @param	Y: pointer to data array (COMPLEX struct)and results of FFT
 * @param	N: number of data point (128, 256, 512)
 * @param	dir: direction 0:FFT, 1: inversed FFT
 */
void FFT(COMPLEX *Y, uint16_t N, uint8_t dir)//, float *out_re, float *out_im)
{
	uint16_t i, j, k, i2;			// local variable for loop
	uint16_t upper_leg, lower_leg;  // butterfly level (leg)
	uint16_t leg_count; 			// number of calculation for butterfly per block.
	uint16_t num_stages = 0; 		// FFF stage
	uint16_t index, step;			// variable for W factor

	i=1;
	do {							// state  (ORDER = 2^n)
		num_stages += 1;
		i=i*2;
	//}while(i!=N);
	}while(i < N);
    
	leg_count = N/2;		 		// Step Block  N/2 (Block = only 1  )
	step = 1;

	for(i=0; i<num_stages; i++)
	{
		index = 0;
		for(j=0; j<leg_count; j++) 											// N/2(initial) -> N/4 -> N/8 -> ...
		{
			for(upper_leg=j; upper_leg < N; upper_leg+=(2*leg_count))		// Block level	: 1, 2, 4,... 2^n  : n=0,1,2,...n
			{
				lower_leg = upper_leg+leg_count;

				temp1.real = Y[upper_leg].real + Y[lower_leg].real;			//  x(n) + x(n+N/(2^stage), stage = 0, 1, 2,...  : real
				temp1.imag = Y[upper_leg].imag + Y[lower_leg].imag;			//  x(n) + x(n+N/(2^stage), stage = 0, 1, 2,...  : imaginary
				temp2.real = Y[upper_leg].real - Y[lower_leg].real;			//  x(n) - x(n+N/(2^stage), stage = 0, 1, 2,...  : real
				temp2.imag = Y[upper_leg].imag - Y[lower_leg].imag;			//  x(n) - x(n+N/(2^stage), stage = 0, 1, 2,...  : imaginary

				(Y[lower_leg]).real = temp2.real*(w[index]).real - temp2.imag*(w[index]).imag;	//{ x(n) - x(n+N/(2^stage)} * WNn, : stage=i, n=j
				(Y[lower_leg]).imag = temp2.real*(w[index]).imag + temp2.imag*(w[index]).real;  // -(i*i) = -(-1) = +1

				(Y[upper_leg]).real = temp1.real;
				(Y[upper_leg]).imag = temp1.imag;
			}
			index +=step;
		}
		leg_count = leg_count /2;
		step *=2;

	}  //FFT complete !

	j=0;
	i2 = N/2;
	for (i=0;i<N-1;i++) // Bit reverse (Order)
	{
		if (i < j)
		{
			temp1.real = (Y[i]).real;	//  tx = x[i];
			temp1.imag = (Y[i]).imag;	//ty = y[i];
			(Y[i]).real = (Y[j]).real;
			(Y[i]).imag = (Y[j]).imag;
			(Y[j]).real = temp1.real;
			(Y[j]).imag = temp1.imag;
		}
		k = i2;
		while (k <= j)
		{
			j -= k;
			k >>= 1;
		}
		j += k;
	}


	for(i=0; i<N; i++)		// Copy to output buffer, dir=0 : FFT, dir=1: IFFT
	{
		if(dir)
		{
			Y[i].real = Y[i].real/2;
			Y[i].imag = Y[i].imag/2;
		}else
		{
			Y[i].real = Y[i].real/(N/2);
			Y[i].imag = Y[i].imag/(N/2);

			if(Y[i].imag<0)
			Y[i].imag = -Y[i].imag;
		}
	}
}

/*-----------------------------------------------------------*/

int16_t SearchPeakValue(float value, uint16_t index)
{
	static float prevValue =0;
	static uint16_t prevIndex =0;
	static boolean isIncrement =FALSE;
	static uint16_t TempIncCount =0;
	int16_t ret =-1;

	if(isIncrement)
	{
		if(prevValue > value)
		{
			ret = prevIndex;
			isIncrement = FALSE;
#if defined (HEARTBEAT_DEBUG)
			DBGHI(GEN,"Peak (value,index) = (%f,%d)\r\n",prevValue,prevIndex);
#endif
		}
	}
	else
	{
		if(prevValue < value)
		{
			TempIncCount++;
		}
		else
		{
			TempIncCount = 0;
		}

		if(TempIncCount >= 2)
        //if(TempIncCount >= 1)
		{
			isIncrement = TRUE;
			TempIncCount = 0;
		}
	}
	prevValue = value;
	prevIndex = index;

	return ret;
}
/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/
#if defined(NEW_HEARTBEAT_CALC)
boolean HeartBeat_Spo2(ppg_data_type *buf, uint16_t len )
{  
    boolean isfoundpeak = FALSE;
    boolean isfoundpeakFromPrev = FALSE;
	uint16_t i,j;
    uint16_t current_peak_index=0;

    uint16_t local_max_i;
    float local_max;
    
    uint16_t pk_RED_i,pk_IR_i;
	float YY[7]={0};
	float R_RED, R_IR;
    boolean isContacted = FALSE;
    float localpeakAvg = 0.0;

 /* for Heart_Rate 42 BPM ~ 140BPM */

 // 1. ���� 5�� sample�� ��� �� �� ��ü ��� ��� 
    {
        float local_sum=0.0;

        for( i = 0; i < MEDIAN_SAMPLE_SIZE ; i++)
        {
        	local_sum =0;
        	for (j =0; j<(PPG_fs/5);j++)
        	{
        		local_sum += buf[i+j].sample_LED;
        	}
        	PPG_median[i]=local_sum/(float)((float)PPG_fs / (float)5);
        }
    }

// 2. 25���� max peak�� index���� peak[]�� ���� 
    {
        uint16_t leap;
        float yy[PPG_fs]={0.0};
        uint16_t localsamples ;

        leap = 0;
    	local_max_i =0;

    	localsamples = PPG_fs;

        while (leap <= (MEDIAN_SAMPLE_SIZE -localsamples))
    	{
    		for (i=0; i<localsamples; i++){
    			yy[i] = PPG_median[i+leap];
    		}

    		local_max_i = 0;
    		local_max = yy[local_max_i];

    		for (i=1;i<localsamples;i++)
            {
    			if (local_max < yy[i])
                {
    				local_max_i = i;
    				local_max = yy[i];
    			}
    		}

            localpeak[current_peak_index] = leap + local_max_i;;
            localpeak_value[current_peak_index++] = local_max;
    		leap =leap + PPG_fs;

    		if( (leap + PPG_fs ) >  MEDIAN_SAMPLE_SIZE)
    		{
    			localsamples =(MEDIAN_SAMPLE_SIZE - leap);
    		}
    		else
    		{
    			localsamples = PPG_fs;
    		}
            localpeakAvg += local_max;
            
#if defined (HEARTBEAT_DEBUG)
    		DBGHI(GEN,"PeakValue = %f\r\n",local_max);
#endif
    	}
    }

    if( (localpeakAvg/current_peak_index) < 0.6)
    {
        isContacted = FALSE;
    }
    else
    {
        isContacted = TRUE;
    }

// 3. ���� �����ϴٰ� ���� �ϴ� �κ��� peak ������ �ؼ� Heartbeat ���
    {
    	int16_t sPEAKindex;

		for(i=0;i<current_peak_index;i++)
		{
			if( (sPEAKindex = SearchPeakValue(localpeak_value[i], localpeak[i]) ) >= 0)
			{
				peak[peak_index++] = sPEAKindex;

				if(i == 0)
				{
					if( peak_index > 1) // if not first peak
					{
						if(sample_over_count > 0) sample_over_count--;
					}
					isfoundpeakFromPrev = TRUE;
				}
				else
				{
					isfoundpeak = TRUE;
				}
			}
		}
    }

// 4. Calculate Heartbeat     
    if(isContacted == TRUE)
    {
        #define PPG_SAMPLES_PER_SEC 250
    	float temp_heart_beat;
        uint16_t samples_peak;

        if( (isfoundpeak) || (isfoundpeakFromPrev))
        {
            if(peak_index >= 2)
            {
                if(sample_over_count == 0)
                {
                    samples_peak = peak[1] - peak[0];
                }
                else
                {
                    samples_peak = (PPG_FFT_SIZE - peak[0] ) + peak[1] + (sample_over_count - 1)*PPG_FFT_SIZE;
                }
                
                temp_heart_beat = 60.0 / (float)( (float)samples_peak / (float)PPG_SAMPLES_PER_SEC ) ;
#if defined (HEARTBEAT_DEBUG)
                DBGHI(GEN,"PeakDiff = %d, over = %d\r\n",samples_peak, sample_over_count);
#endif

        		if( (temp_heart_beat > 42 ) && (temp_heart_beat < 140) )
                {
                    Heart_Rate= (uint8_t)temp_heart_beat;
                    Heart_Rate_Smooth=ringbuf_add_getAvg(ppgRB,(uint8_t)temp_heart_beat);
                }    
              	sample_over_count = 1;
                peak[0] = peak[peak_index-1];
                peak_index = 1;
            }
            else
            {
            	sample_over_count++;
            }
        }

        if(isfoundpeak == FALSE)
        {
        	if(peak_index != 0)
        	{
				sample_over_count++;

				if(sample_over_count > 5)
				{
					//Heart_Rate = 0;
					sample_over_count = 0;
					peak_index = 0;
				}
        	}
        }
    }
    else
    {
		Heart_Rate = 0;
        Heart_Rate_Smooth = 0;
		sample_over_count = 0;
		peak_index = 0;  
        
        InitPPGRingbuf();
        //InitSpO2Ringbuf();
    }
/*---------------------------------------------------*/


/* for SpO2 */

//	//FFT for RED
	for(i = 0; i <PPG_FFT_SIZE; i++)
	{
		samples[i].real = buf[i].sample_LED ;
		samples[i].imag=0;
	}
	FFT(samples,PPG_FFT_SIZE,0);

//	//Find local maximum in RED spectrum
	for (i=5;i<12;i++)
	{
		 YY[i-5]=fabs(samples[i].real);
	}

	local_max_i=0;
	local_max=YY[0];

	for (i=1;i<6;i++){
		if (local_max<YY[i]){
			local_max_i=i;
			local_max=YY[i];
		}
	}
	pk_RED_i=start_index-1+local_max_i;

	R_RED = fabs(samples[pk_RED_i].real)/fabs(samples[0].real);

	//FFT for IR
	for(i = 0; i <PPG_FFT_SIZE; i++)
	{
		samples[i].real = buf[i].sample_IR ;
		samples[i].imag=0;
	}
	FFT(samples,PPG_FFT_SIZE,0);

	//Find local maximum in IR spectrum
	for (i=5;i<12;i++)
	{
		 YY[i-5]=fabs(samples[i].real);
	}
	local_max_i=0;
	local_max=YY[0];

	for (i=1;i<6;i++){
		if (local_max<YY[i]){
			local_max_i=i;
			local_max=YY[i];
		}
	}
	pk_IR_i=start_index-1+local_max_i;
	R_IR = fabs(samples[pk_IR_i].real)/fabs(samples[0].real);

	//SpO2
	SpO2_orig = (uint8_t)(104 - 28*(R_RED/R_IR));

    SpO2 = SpO2_orig;

    if(isContacted == FALSE)
    {
        InitSpO2Ringbuf();
    }
    else
    {
        if(SpO2 > 0)
        {
        	if(SpO2<80) SpO2=SpO2_Smooth;
            
    	    if(SpO2>99) SpO2=99;

            if(SpO2 > 0)
                SpO2_Smooth=ringbuf_add_getAvg(spo2RB,SpO2);
        }
    }

    
#if defined (HEARTBEAT_DEBUG)
        DBGHI(GEN,"28*(R_RED/R_IR)= %f, R_RED= %f, R_IR= %f\r\n",28*(R_RED/R_IR), R_RED, R_IR);
#endif

    return TRUE;
}

#else
boolean HeartBeat_Spo2(ppg_data_type *buf, uint16_t len )
{  
    uint16_t pk_RED_i,pk_IR_i;
	//uint8_t i,j, leap, pk_i,local_max_i,beat_i;
	uint16_t i,j, leap, pk_i,local_max_i,beat_i;
	float local_max =0;
	float beat =0;
	//float peak[PPG_FFT_SIZE]={0};
	float yy[PPG_fs]={0.0};
	float local_sum=0;
	float YY[7]={0};
	float R_RED, R_IR;
	//float PPG_median[PPG_FFT_SIZE];
	float temp_heart_beat;
    
	beat_i=0;

    //memset(peak,0x00,MAX_PEAK_BUFF_SIZE*sizeof(float));
    memset(PPG_median,0x00,PPG_FFT_SIZE*sizeof(float));


 /* for Heart_Rate 42 BPM ~ 140BPM */

 // 1. ���� 5�� sample�� ��� �� ��� 
	for( i =0; i < (PPG_FFT_SIZE-PPG_fs/5); i++)
	{
		local_sum =0;
		for (j =0; j<(PPG_fs/5);j++)
		{
			local_sum += buf[i+j].sample_LED;
		}
		PPG_median[i]=local_sum/(float)(PPG_fs / 5);
	}

// 2. 25���� peak index���� peak[]�� ���� 
    leap = 0;
	pk_i =0;
	local_max_i =0;
    while (leap <= (PPG_FFT_SIZE-PPG_fs))
	{
		for (i=0; i<PPG_fs; i++){
			yy[i] = PPG_median[i+leap];
		}

		local_max_i = 0;
		local_max = yy[local_max_i];

		for (i=1;i<PPG_fs;i++)
        {
			if (local_max < yy[i])
            {
				local_max_i = i;
				local_max = yy[i];
			}
		}

		peak[pk_i] = leap + local_max_i;
		pk_i++;
		leap =leap + PPG_fs;
	}

	beat_i=0;
	for (i=0; i<pk_i-1;i++)
    {
		if( peak[i] < (peak[i+1]-10))
        {
			beat += (float)(((float)PPG_fs / (float)(peak[i+1]-peak[i])) * (float)60.0);
			beat_i++;
		}
	}


	if(beat_i)
	{
		temp_heart_beat = beat/beat_i;
		if( (temp_heart_beat > 42 ) && (temp_heart_beat < 140) )
			Heart_Rate= (uint8_t)temp_heart_beat;
	}
/*---------------------------------------------------*/


/* for SpO2 */

//	//FFT for RED
	for(i = 0; i <PPG_FFT_SIZE; i++)
	{
		samples[i].real = buf[i].sample_LED ;
		samples[i].imag=0;
	}
	FFT(samples,PPG_FFT_SIZE,0);

//	//Find local maximum in RED spectrum
	for (i=5;i<12;i++)
	{
		 YY[i-5]=fabs(samples[i].real);
	}

	local_max_i=0;
	local_max=YY[0];

	for (i=1;i<6;i++){
		if (local_max<YY[i]){
			local_max_i=i;
			local_max=YY[i];
		}
	}
	pk_RED_i=start_index-1+local_max_i;

	R_RED = fabs(samples[pk_RED_i].real)/fabs(samples[0].real);

	//FFT for IR
	for(i = 0; i <PPG_FFT_SIZE; i++)
	{
		samples[i].real = buf[i].sample_IR ;
		samples[i].imag=0;
	}
	//FFT(samples,PPG_FFT_SIZE,0);

	//Find local maximum in IR spectrum
	for (i=5;i<12;i++)
	{
		 YY[i-5]=fabs(samples[i].real);
	}
	local_max_i=0;
	local_max=YY[0];

	for (i=1;i<6;i++){
		if (local_max<YY[i]){
			local_max_i=i;
			local_max=YY[i];
		}
	}
	pk_IR_i=start_index-1+local_max_i;
	R_IR = fabs(samples[pk_IR_i].real)/fabs(samples[0].real);
	//SpO2
	SpO2 = 104 - 28*(R_RED/R_IR);
	if(SpO2<95)
		SpO2=95;
	if(SpO2>99)
		SpO2=99;
	//FFT_complete_PPG =1;

    return TRUE;
}

#endif
/*-----------------------------------------------------------*/

boolean fft_eeg(float *buf, uint16_t len)
{
	uint32_t total;
    uint8_t f;
    
    for(total = 0; total <len; total ++) // 500
    {
        samples[total].real = buf[total] ;
        samples[total].imag=0;
    }
    FFT(samples, FFT_SIZE, 0);
    eegFFTMax = -1;
    eegTheta = 0;
    eegDelta = 0;
    eegAlpha =0;
    eegBeta = 0;
    eegGamma = 0;
    
    for( f=1; f<DELTA_LIMIT; f++)   //delta
    {
        //eegDelta += samples[f].imag;//fft_result_im[f];
        eegDelta += powf( samples[f].imag,2)+ powf(samples[f].real,2);
        //eegDelta += square(hypot(samples[f].imag,samples[f].real));
        if(samples[f].imag > eegFFTMax)
        {
            eegFFTMax = samples[f].imag;
        }
    }
    eegDelta =log(eegDelta)*16+128;
    eegAnalData.bDelta = floor(eegDelta+0.5);
    //eegAnalData.bDelta = (uint8_t)(((uint32_t)eegDelta)>>24);
    eegTheta = 0;
    for(; f<THETA_LIMIT; f++)   //Theta
    {
        //eegTheta += samples[f].imag;//fft_result_im[f];
        eegTheta += powf( samples[f].imag,2)+powf(samples[f].real,2);
        //eegTheta += square(hypot(samples[f].imag,samples[f].real));
        if(samples[f].imag > eegFFTMax)
        {
            eegFFTMax =samples[f].imag;// fft_result_im[f];
        }
    }
    eegTheta = log(eegTheta)*16+128;
    eegAnalData.bTheta = floor(eegTheta+0.5);
    //eegAnalData.bTheta = (uint8_t)(((uint32_t)eegTheta)>>24);
    eegAlpha= 0;
    for(; f<ALPHA_LIMIT; f++)   //alpha
    {
        //eegAlpha += samples[f].imag;//fft_result_im[f];
        eegAlpha += powf( samples[f].imag,2)+ powf(samples[f].real,2);
        //eegAlpha += square(hypot(samples[f].imag,samples[f].real));
        if(samples[f].imag > eegFFTMax)
        {
            eegFFTMax = samples[f].imag;//fft_result_im[f];
        }
    }
    eegAlpha= log(eegAlpha)*16+128;
    eegAnalData.bAlpha = floor(eegAlpha+0.5);
    //eegAnalData.bAlpha = (uint8_t)(((uint32_t)eegAlpha)>>24);
    eegBeta= 0;
    for(; f<BETA_LIMIT; f++)    //eegBeta
    {
        //eegBeta += samples[f].imag;//fft_result_im[f];
        eegBeta += powf( samples[f].imag,2)+ powf(samples[f].real,2);
        //eegBeta += square(hypot(samples[f].imag,samples[f].real));
        if(samples[f].imag > eegFFTMax)
        {
            eegFFTMax = samples[f].imag;//fft_result_im[f];
        }
    }
    eegBeta = log(eegBeta)*16+128;
    eegAnalData.bBeta = floor(eegBeta+0.5);
    //eegAnalData.bBeta = (uint8_t)(((uint32_t)eegBeta)>>24);

    
    return TRUE;
}

void FFTVariableInit(void)
{
	uint16_t i;
	for(i=0; i<(FFT_SIZE/2); i++)				
	{
		w[i].real = cos(2*pi*i/FFT_SIZE);
		w[i].imag = -sin(2*pi*i/FFT_SIZE);
	}
}

void InitPPGData(void)
{
    Heart_Rate = 0;
    SpO2 = 0;
    Heart_Rate_Smooth= 0;
    SpO2_Smooth= 0;
}

void InitEEGData(void)
{
    eegAnalData.bDelta = 0;
    eegAnalData.bTheta = 0;
    eegAnalData.bAlpha = 0;
    eegAnalData.bBeta = 0;
}

void InitPPGRingbuf()
{
  if(ppgRB == NULL)
  {
    ppgRB = ringbuf_new(MAX_RINGBUF_SIZE); 
  }
  else
  {
    ringbuf_reset(ppgRB);
  }
  Heart_Rate_Smooth= 0;
}

void InitSpO2Ringbuf()
{
  if(spo2RB == NULL)
  {
    spo2RB = ringbuf_new(MAX_RINGBUF_SIZE); 
  }
  else
  {
    ringbuf_reset(spo2RB);
  }
  SpO2_Smooth= 0;
}

/*===============================================================================================*/
