#ifndef FFTTASK_SIGNALS_H
#define FFTTASK_SIGNALS_H
/*===============================================================================================
 *
 *   @file FFTtask_signals.h
 *
 *   @version v1.0
 *
 *=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/
/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Enumerations for substates                                              */

/*****************************************************
                   SIGNAL GROUP

    1. FFT TASK      : 0x6000 ~
    2. TIMER        : 0x6000 ~ 0x60FF
    3. EVENT        : 0x6100 ~ 0x61FF
    4. COMMAND      : 0x6200 ~ 0x62FF
    5. RESPONSE     : 0x6300 ~ 0x63FF

*****************************************************/

/* FFT COMMANDS. */
typedef enum
{
    FFT_DUMMY_TIMER  = 0x6000,
	FFT_TIMER_1SEC_F,

    FFT_DUMMY_EVENT  = 0x6100,
	FFT_COMPLETE_EVT,

    FFT_TASK_F       = 0x6200,
    FFT_TASK_START_CMD_F,
    FFT_RESET_CMD_F,
    FFT_TASK_STOP_F,
    FFT_PPG_REQ_F,
    FFT_EEG_REQ_F,

    FFT_PPG_DATA_INIT_F,
    FFT_EEG_DATA_INIT_F,

    FFT_MAX_COMMAND = 0x6FFF
} ffttask_signal_type;

/*===============================================================================================*/
#endif  /* FFTTASK_SIGNALS_H*/
