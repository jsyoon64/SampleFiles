#ifndef LEDTASK_SIGNALS_H
#define LEDTASK_SIGNALS_H
/*===============================================================================================
 *
 *   @file ledtask_signals.h
 *
 *   @version v1.0
 *
 *===============================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.

- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Enumerations for substates                                              */

/*****************************************************
                   SIGNAL GROUP

    1. LED TASK  : 0x2000 ~
    2. TIMER        : 0x2000 ~ 0x20FF
    3. EVENT        : 0x2100 ~ 0x21FF
    4. COMMAND      : 0x2200 ~ 0x22FF
    5. RESPONSE     : 0x2300 ~ 0x23FF

*****************************************************/

/* LED COMMANDS. */
typedef enum
{
    LED_DUMMY_TIMER  = 0x2000,
    LED_TIMER_1SEC_F,
    LED_TIMER_Blink_F,

    LED_DUMMY_EVENT  = 0x2100,


    LED_TASK_F       = 0x2200,
    LED_TASK_START_CMD_F,
    LED_RESET_CMD_F,
    LED_TASK_STOP_F,

    LED_TEST_STOP_F,

    LED_ONOFF_F,
    LED_ON_F,
    LED_OFF_F,
    LED_BRIGHT_F,
    LED_FREQ_F,
    AML_CONTROL_F,

    LED_STATUS_ON_F,
    LED_STATUS_OFF_F,

    LED_MAX_COMMAND = 0x2FFF
} ledtask_signal_type;

/*===============================================================================================*/
#endif  /* LEDTASK_SIGNALS_H */
