/*===============================================================================================*/
/**
 *   @file ledtask_state.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "signals.h"
#include "command.h"
#include "task_cfg.h"
#include "ledtask_state.h"
#include "ledcli.h"
#include "debugmsgcli.h"


/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/
uint16_t    ledtask_state = LEDSTATE_INIT;


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/


/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/
void status_led_ctr(boolean onoff, uint8_t chan)
{
    if(onoff == ON)
    {
        switch(chan)
        {
            case 0: STATUS_LED_ON(STA_LED_R); break;
            case 1: STATUS_LED_ON(STA_LED_G); break;
            case 2: STATUS_LED_ON(STA_LED_B); break;
            default: break;
        }
    }
    else
    {
        switch(chan)
        {
            case 0: STATUS_LED_OFF(STA_LED_R); break;
            case 1: STATUS_LED_OFF(STA_LED_G); break;
            case 2: STATUS_LED_OFF(STA_LED_B); break;
            default: break;
        }
    }
}
    
    

/*===========================================================================
FUNCTION           
DESCRIPTION     
DEPENDENCIES
RETURN VALUE
===========================================================================*/
void ledtask_state_machine (command_type *cmdptr)
{
    uint16_t  new_state;

    do
    {
        new_state = LEDSTATE_NOSTATE;

        switch ( LEDSTATE_STATE( ledtask_state) )
        {
            case LEDSTATE_INIT :
                new_state = led_init_state ( cmdptr );        /* Process the initialization state */
                break;

            case LEDSTATE_IDLE :
                new_state = led_idle_state ( cmdptr );        /* Process the idle state */
                break;

            case LEDSTATE_CHARGE :
                new_state = led_charge_state ( cmdptr );        /* Process the charge state */
                break;

            case LEDSTATE_LOWBATT :
                new_state = led_lowbatt_state ( cmdptr );        /* Process the lowbatt state */
                break;

            case LEDSTATE_FULL :
                new_state = led_full_state ( cmdptr );        /* Process the full charge state */
                break;

            case LEDSTATE_TEST :
                new_state = led_test_state ( cmdptr );        /* Process the test state */
                break;

            default:
                DBGERR(MP3, "bad state = 0x%x, cmd = 0x%x\n", ledtask_state, cmdptr->cmd );
                new_state = LEDSTATE_NOSTATE;
                break;
        }

        if ( new_state != LEDSTATE_NOSTATE )
        {
            ledtask_state = new_state;
        }

    } while ( new_state != LEDSTATE_NOSTATE );
}


/*===============================================================================================*/
