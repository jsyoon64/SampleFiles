/*
*/

#ifndef LEDCLI_H
#define LEDCLI_H

void ledCLIregister(void);

#endif

