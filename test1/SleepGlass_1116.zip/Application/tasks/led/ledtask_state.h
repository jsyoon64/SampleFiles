#ifndef LEDTASK_STATE_H_
#define LEDTASK_STATE_H_
/*===============================================================================================*/
/**
 *   @file ledtask_state.h
 *
 *   @version v1.0
 */
/*=================================================================================================


Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------


===================================================================================================*/
/* Standard includes. */

/* Scheduler include files. */
#include "FreeRTOS.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "queue.h"
#include "task.h"
#include "timers.h"

/* Application include files. */
#include "command.h"


/*=================================================================================================
 CONSTANTS
=================================================================================================*/
/* LEDTASK main states */
#define LEDSTATE_INIT       0x0100
#define LEDSTATE_IDLE       0x0200
#define LEDSTATE_CHARGE     0x0300
#define LEDSTATE_LOWBATT    0x0400
#define LEDSTATE_FULL       0x0500
#define LEDSTATE_TEST       0x0600

#define LEDSTATE_NOSTATE    0xFF00
#define LEDSTATE_EXIT       0xFF00
    
#define LEDSTATE_STATE(state)    (state & 0xFF00 )


#define STATUS_LED_ON(mask)	    HAL_GPIO_WritePin(mask##_GPIO_Port, mask##_Pin, GPIO_PIN_RESET);
#define STATUS_LED_OFF(mask)	HAL_GPIO_WritePin(mask##_GPIO_Port, mask##_Pin, GPIO_PIN_SET);

extern uint16_t ledtask_state;
extern TimerHandle_t xledBlinkTimer;


/*=================================================================================================
 FUNCTION PROTOTYPES
=================================================================================================*/
void status_led_ctr(boolean onoff, uint8_t chan);

void ledtask_state_machine ( command_type *cmdptr);
uint16_t led_init_state ( command_type *cmdptr);
uint16_t led_idle_state ( command_type *cmdptr);
uint16_t led_charge_state ( command_type *cmdptr);
uint16_t led_lowbatt_state ( command_type *cmdptr);
uint16_t led_full_state ( command_type *cmdptr);
uint16_t led_test_state ( command_type *cmdptr );

/*===============================================================================================*/
#endif  /* LEDTASK_STATE_H_ */
