/*===============================================================================================*/
/**
 *   @file ledtask.c
 *
 *   @version v1.0
 */
/*================================================================================================*/


/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */
//#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>


/* Scheduler include files. */
#include "FreeRTOS.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "queue.h"
#include "task.h"

/* Application include files. */
#include "command.h"
#include "signals.h"
#include "consol.h"
#include "task_cfg.h"
#include "timers.h"
#include "timergen.h"
#include "debugmsgcli.h"
#include "ledcli.h"
#include "comdef.h"
#include "interface.h"
#include "ledtask_state.h"
#include "tim.h"
#include "comdef.h"

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/
void vLEDTask( void *pvParameters );
    
/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/
#define ledTIMER_QUEUE_LENGTH 10

/*
    PA0     STA_LED_R
    PC4     STA_LED_G
    PB0     STA_LED_B

    PD12,13,14 PWM LED */

/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/

static QueueHandle_t xledTimerQueue;

/*-----------------------------------------------------------*/
/* The handle of the queue set to which the queues are added. */
static QueueSetHandle_t xQueueSet;

TimerHandle_t xledTimer1 = NULL;
TimerHandle_t xledBlinkTimer = NULL;
/*-----------------------------------------------------------*/

/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/

/*-----------------------------------------------------------*/
void prvledTimerCallback( TimerHandle_t pxExpiredTimer )
{
	uint32_t ulTimerID;

    portENTER_CRITICAL();
	ulTimerID = ( uint32_t ) pvTimerGetTimerID( pxExpiredTimer );
	xQueueSend(xledTimerQueue,&ulTimerID,0);
    portEXIT_CRITICAL();
}


/*-----------------------------------------------------------*/
static void waitTaskStartSignal(QueueSetMemberHandle_t xQueue)
{
	QueueSetMemberHandle_t	xActivatedMember;
	command_type			cmd;
    uint32_t                timerid;
    
	for(;;)
	{
		xActivatedMember =  xQueueSelectFromSet( xQueue, queueNO_DELAY );

        if( xActivatedMember == xLedTaskQueue )
        {
            xQueueReceive( xActivatedMember, &cmd, 0 );
        }
        else if( xActivatedMember == xledTimerQueue )
        {
            xQueueReceive( xActivatedMember, &timerid, 0 );
            cmd.cmd = (uint16_t)timerid;
            cmd.len = 0;
			cmd.msg = NULL;
        }
		else
		{
			cmd.cmd = 0;
			cmd.msg = NULL;
		}
        
		if(cmd.cmd == LED_TASK_START_CMD_F)
		{
			// start normal processing
			break;
		}
        
		if( (cmd.msg != NULL) && (cmd.isconst == FALSE))
		{
			cmd_mfree(cmd.msg);
		}
        
	}
}

/*-----------------------------------------------------------*/
void ledtask_init(QueueSetMemberHandle_t  xQueue)
{
	ledCLIregister();

	waitTaskStartSignal(xQueue);
	
	/* Start the one shot timer and check that it reports its state correctly. */
	xTimerStart( xledBlinkTimer, 0 );
}

/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/
void vStartLEDTasks( void )
{
	/*First Create the queue set such that it will be able to hold a message for
	every space in every queue in the set. */
	xQueueSet = xQueueCreateSet( taskLED_QUEUE_LENGTH + ledTIMER_QUEUE_LENGTH );

	/* Create the queue that we are going to use for the
	prvSendFrontAndBackTest demo. */
	xLedTaskQueue = xQueueCreate( taskLED_QUEUE_LENGTH, sizeof( command_type ) );
	xledTimerQueue = xQueueCreate( ledTIMER_QUEUE_LENGTH, sizeof( uint32_t ) );

	/* vQueueAddToRegistry() adds the queue to the queue registry, if one is
	in use.  The queue registry is provided as a means for kernel aware
	debuggers to locate queues and has no purpose if a kernel aware debugger
	is not being used.  The call to vQueueAddToRegistry() will be removed
	by the pre-processor if configQUEUE_REGISTRY_SIZE is not defined or is
	defined to be less than 1. */
	//vQueueAddToRegistry( xLedTaskQueue, "LED_Queue" );
	//vQueueAddToRegistry( xledTimerQueue, "LED_Queue" );

	xQueueAddToSet( xLedTaskQueue, xQueueSet );//vQueueAddToRegistry( xPrintQueue, "CLI_Queue" );
	xQueueAddToSet( xledTimerQueue, xQueueSet );


	/* Create a one-shot timer for use later on in this test. */
	xledTimer1 = xTimerCreate(	"",				/* Text name to facilitate debugging.  The kernel does not use this itself. */
								1000,					/* The period for the timer(1 sec). */
								pdFALSE,				/* Don't auto-reload - hence a one shot timer. */
								( void * )LED_TIMER_1SEC_F,	/* The timer identifier. */
								prvledTimerCallback );	/* The callback to be called when the timer expires. */

	xledBlinkTimer = xTimerCreate(	"",				/* Text name to facilitate debugging.  The kernel does not use this itself. */
								500,					/* The period for the timer(500 msec). */
								pdFALSE,				/* Don't auto-reload - hence a one shot timer. */
								( void * )LED_TIMER_Blink_F,	/* The timer identifier. */
								prvledTimerCallback );	/* The callback to be called when the timer expires. */

	/* Spawn the task. */
	xTaskCreate( vLEDTask, "LED", taskLED_TASK_STACK_SIZE, xQueueSet, taskLED_TASK_PRIORITY, ( TaskHandle_t * ) NULL );

}


/*-----------------------------------------------------------*/
void vLEDTask( void *pvParameters )
{
	//QueueHandle_t   xQueue;		// mctask�� queue �ϳ��� ��� �Ҷ�
	QueueSetMemberHandle_t  xQueue;
	QueueSetMemberHandle_t	xActivatedMember;
	command_type	        cmd;
	uint8_t			        *data = NULL;
    uint32_t                timerid;
    uint8_t                 temp;
    boolean                 LednOffStatus = OFF;

	xQueue = ( QueueHandle_t * ) pvParameters;

	ledtask_init(xQueue);
	
	for(;;)
	{
		// �ִ� 2000 msec���� q�� ��ٸ�.
		xActivatedMember =  xQueueSelectFromSet( xQueue, queueSHORT_DELAY );
		// xMcTaskQueue �ϳ��� ��� �� ���
		//if( xQueueReceive( xQueue, &cmd, 2000 ) == pdPASS )

		/* Which set member was selected?  Receives/takes can use a block time
        of zero as they are guaranteed to pass because xQueueSelectFromSet() would
        not have returned the handle unless something was available. */



        if( xActivatedMember == xLedTaskQueue )
        {
            xQueueReceive( xActivatedMember, &cmd, 0 );
            data = (uint8_t *)cmd.msg;
        }
        else if( xActivatedMember == xledTimerQueue )
        {
            xQueueReceive( xActivatedMember, &timerid, 0 );
            cmd.cmd = (uint16_t)timerid;
            cmd.len = 0;
			cmd.msg = NULL;
        }
		else
		{
			cmd.cmd = 0;
			cmd.msg = NULL;
		}
        
        DBGLOW(LED,"LED SIGS %x\r\n", cmd.cmd);

		//processing
		switch(cmd.cmd)
		{
			case 0:
				// No cmd rxed, 2000 msec wait timeout
				
                DBGMED(LED,"LED Task Alive!!!\r\n");
				break;

            case MC_MODE_TEST_MODE_F:
            case LED_TASK_STOP_F:
                ledtask_state = LEDSTATE_TEST;
                ledtask_state_machine(&cmd);
                break;

            case LED_ON_F:
                {
                    uint8_t ctrlchan = (uint8_t)data[FDPOS(led_cmd_msg_field_type,Cmd)];  // chan
                    HAL_TIM_PWM_Start(&htim4,ctrlchan);
                    DBGHI(LED,"LED ON CMD: prev Status = 0x%x, Channel = 0x%x\r\n", LednOffStatus,ctrlchan);
                }
                LednOffStatus = ON;
                break;
                
            case LED_OFF_F:
                {
                    uint8_t ctrlchan = (uint8_t)data[FDPOS(led_cmd_msg_field_type,Cmd)];  // chan
                    HAL_TIM_PWM_Stop(&htim4,ctrlchan); 
                    DBGHI(LED,"LED OFF CMD: prev Status = 0x%x, Channel = 0x%x\r\n", LednOffStatus,ctrlchan);
                }
                LednOffStatus = OFF;
                break;
                
            case LED_ONOFF_F:
            	Tim4_PrintStatus();
                {
					uint8_t ctrlcmd = (uint8_t)data[FDPOS(led_cmd_msg_field_type,Cmd)];
					uint8_t ctrldata = (uint8_t)data[FDPOS(led_cmd_msg_field_type,Dummy)];
					DBGHI(LED,"LED OnOff Status = 0x%x, Input cmd = 0x%x, data=0x%x\r\n", LednOffStatus,ctrlcmd,ctrldata);
					if(ctrlcmd == 0x00)
					{
						HAL_TIM_PWM_Stop(&htim4,TIM_CHANNEL_1);
						HAL_TIM_PWM_Stop(&htim4,TIM_CHANNEL_2);
						HAL_TIM_PWM_Stop(&htim4,TIM_CHANNEL_3);
						LednOffStatus = OFF;
					}
					else if(ctrlcmd == 0x01)
					{
						HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_1);
						HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_2);
						HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_3);
						LednOffStatus = ON;
					}
					else
					{
						DBGHI(LED,"unknown Input cmd = 0x%x, data=0x%x\r\n", ctrlcmd,ctrldata);
					}
                }
                break;
                
            case LED_BRIGHT_F:
            	{
            		uint8_t ctrlcmd = (uint8_t)data[FDPOS(led_cmd_msg_field_type,Cmd)];
            		uint8_t ctrldata = (uint8_t)data[FDPOS(led_cmd_msg_field_type,Dummy)];
            		DBGHI(LED,"BriInput chan = 0x%x, bri=0x%x\r\n", ctrlcmd,ctrldata);
            		Local_PWM_Period(ctrlcmd,ctrldata);  // chan, pulse
            		//LED ON
            		switch(ctrlcmd)
            		{
            			case TIM_CHANNEL_1: HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_1); break;
            			case TIM_CHANNEL_2: HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_2); break;
            			case TIM_CHANNEL_3: HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_3); break;
            			default: break;
            		}
                	Tim4_PrintStatus();
            	}
                break;


            case LED_FREQ_F:

				{
					uint8_t ctrlcmd = (uint8_t)data[FDPOS(led_cmd_msg_field_type,Cmd)];
					temp = (uint8_t)data[FDPOS(led_cmd_msg_field_type,Dummy)];
					DBGHI(LED,"FreqInput cmd = 0x%x, data=0x%x\r\n", ctrlcmd,temp);
					Local_TIM4_Init(ctrlcmd);  // freq, pulse

					if(LednOffStatus == ON)
					{
						HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_1);
						HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_2);
						HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_3);
					}
	            	Tim4_PrintStatus();
				}
                break;

            case LED_STATUS_ON_F:
                status_led_ctr(ON, (uint8_t)data[FDPOS(led_cmd_msg_field_type,Cmd)]);
                break;

            case LED_STATUS_OFF_F:
                status_led_ctr(OFF, (uint8_t)data[FDPOS(led_cmd_msg_field_type,Cmd)]);
                break;
                
            case AML_CONTROL_F:
                //TODO
                break;
                
			default:
                ledtask_state_machine(&cmd);
				break;
		}

		if( (cmd.msg != NULL) && (cmd.isconst == FALSE))
		{
			cmd_mfree(cmd.msg);
		}
	}
}


/*-----------------------------------------------------------*/

