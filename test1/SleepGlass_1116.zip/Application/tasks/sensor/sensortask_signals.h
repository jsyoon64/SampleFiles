#ifndef SENSORTASK_SIGNALS_H
#define SENSORTASK_SIGNALS_H
/*===============================================================================================
 *
 *   @file sensortask_signals.h
 *
 *   @version v1.0
 *
 *=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/
/*- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -*/
/* Enumerations for substates                                              */

/*****************************************************
                   SIGNAL GROUP

    1. SENSOR TASK      : 0x5000 ~
    2. TIMER        : 0x5000 ~ 0x50FF
    3. EVENT        : 0x5100 ~ 0x51FF
    4. COMMAND      : 0x5200 ~ 0x52FF
    5. RESPONSE     : 0x5300 ~ 0x53FF

*****************************************************/

/* SENSOR COMMANDS. */
typedef enum
{
    SENSOR_DUMMY_TIMER  = 0x5000,
	SENSOR_TIMER_1SEC_F,
    SENSOR_MIC_ADC_CHECK_F,
    SENSOR_POLL_CHECK_F,
	SENSOR_ADC_CONV_CHECK_TIMER_F,
	SENSOR_ADC_START_DELAY_TIMER_F,
    SENSOR_SENSOR_CHECK_TIMER_F,

    SENSOR_DUMMY_EVENT  = 0x5100,
	EEG_DATA_READY_EVT,
	PPG_DATA_READY_EVT,
	SENSOR_DATA_RESULT_EVT,
	SENSOR_MASK_WORN_EVT,
    SENSOR_MASK_OFF_EVT,

    SENSOR_BATT_TEMP_EVT,
    SENSOR_BATT_VAL_EVT,
    SENSOR_CHARGE_STATUS_ADC_EVT,

    SENSOR_TASK_F       = 0x5200,
    SENSOR_TASK_START_CMD_F,
    SENSOR_RESET_CMD_F,
    SENSOR_TASK_STOP_F,
    SENSOR_START_ADC_F,
    SENSOR_STOP_ADC_F,

    SENSOR_READ_I2C_F,
    SENSOR_READ_TEMP_F,
    SENSOR_READ_ACCE_F,
    SENSOR_READ_BATT_ADC_F,
    SENSOR_READ_ETC_ADC_F,
    
    SENSOR_DATA_REQ_F,

	SENSOR_READ_F,
	EEG_COLECT_COMPLETE_F,
	PPG_COLECT_COMPLETE_F,
	
	ADC_CONV_COMPLETE_F,
	ADC_CONV_OUTOFWIN_F,
	ADC_ERROR_OCCUR_F,

    SENSOR_MAX_COMMAND = 0x5FFF
} sensortask_signal_type;

/*===============================================================================================*/
#endif  /* SENSORTASK_SIGNALS_H*/
