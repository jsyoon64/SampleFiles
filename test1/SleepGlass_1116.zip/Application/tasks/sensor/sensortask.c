/*
        1 tab == 4 spaces!
*/

/* Standard includes. */
//#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>


/* Scheduler include files. */
#include "FreeRTOS.h"
#include "stm32f4xx_hal.h"
#include "cmsis_os.h"
#include "queue.h"
#include "task.h"

/* Application include files. */
#include "command.h"
#include "signals.h"
#include "consol.h"
#include "task_cfg.h"
#include "timers.h"
#include "timergen.h"
#include "debugmsgcli.h"
#include "sensorcli.h"
#include "ads1292.h"
#include "afe4400.h"
#include "adc_operation.h"
#include "lis2dh.h"
#include "sht20.h"
#include "interface.h"
#include "sensor_data.h"

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/
void vSENSORTask( void *pvParameters );

/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/
#define sensorTIMER_QUEUE_LENGTH 10
#define sensorADC_QUEUE_LENGTH   (20 + MICADC_LOOP_MAX_COUNT)
#define sensorIIC_QUEUE_LENGTH   10

#define I2C1_READ_TEMP           1
#define I2C1_READ_ACCE           2
/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/
/*-----------------------------------------------------------*/
/* The handle of the queue set to which the queues are added. */
static QueueSetHandle_t xQueueSet;
static QueueHandle_t xsensorTimerQueue;
static QueueHandle_t xsensorAdcQueue;
static QueueHandle_t xsensorIICQueue;

#if defined (ADC_USE_POLLING_METHOD)
    static TimerHandle_t xadcConvCheckTimer = NULL;
#endif

#if defined (IIC_USE_WAIT_TIMER)
static TimerHandle_t xsensorPollCheckTimer = NULL;
#endif

static TimerHandle_t xmicAdcCheckTimer = NULL;

static TimerHandle_t xsensorCheckPeriodicTimer = NULL;


/*-----------------------------------------------------------*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/
/*-----------------------------------------------------------*/

static void waitTaskStartSignal(QueueSetMemberHandle_t  xQueue)
{
	QueueSetMemberHandle_t	xActivatedMember;
	command_type			cmd;
    uint32_t                timerid;

	for(;;)
	{
		xActivatedMember =  xQueueSelectFromSet( xQueue, queueNO_DELAY );

        if( xActivatedMember == xSensorTaskQueue )
        {
            xQueueReceive( xActivatedMember, &cmd, 0 );
        }
        else if( xActivatedMember == xsensorTimerQueue )
        {
            xQueueReceive( xActivatedMember, &timerid, 0 );
            cmd.cmd = (uint16_t)timerid;
            cmd.len = 0;
			cmd.msg = NULL;
        }
		else
		{
			cmd.cmd = 0;
			cmd.msg = NULL;
		}

		if(cmd.cmd == SENSOR_TASK_START_CMD_F)
		{
			// start normal processing
			break;
		}
		if( (cmd.msg != NULL) && (cmd.isconst == FALSE))
		{
			cmd_mfree(cmd.msg);
		}
        
	}
}


void sensortask_init(QueueSetMemberHandle_t  xQueue)
{
    uint8_t retry=0;
    int     result;
    
    SensorCLIregister();

    while(++retry < 3)
    {
        if((result = EEG_Init()) != 0)
        {
            DBGERR(SEN,"EEG Init Failed!!! Result %d\r\n",result);
        }
        else
        {
            break;
        }
    }
  
    InitMicRingbuf();
    
    PPG_Init();
    toggle_eeg_buffer_pointer();
    toggle_ppg_buffer_pointer();

    LIS2DH_Init();
    
    SHT20_config();

	waitTaskStartSignal(xQueue);

	/* Start the one shot timer and check that it reports its state correctly. */
	//xTimerStart( xmicAdcCheckTimer, 0 );
    
    xTimerStart( xsensorCheckPeriodicTimer, 0 );

    UpdateSensorStatus(LED_FLAG_POSITION, ON);
    UpdateSensorStatus(EDA_POSITION, ON);
    UpdateSensorStatus(LIGHT_POSITION, ON);
    UpdateSensorStatus(TEMP_POSITION, ON);
    UpdateSensorStatus(ACC_POSTION, ON);
    UpdateSensorStatus(PPG_POSTION, OFF);
    UpdateSensorStatus(EEG_POSTION, OFF);
    
 }

/*-----------------------------------------------------------*/

void prvsensorTimerCallback( TimerHandle_t pxExpiredTimer )
{
    uint32_t ulTimerID;

    portENTER_CRITICAL();
	ulTimerID = ( uint32_t ) pvTimerGetTimerID( pxExpiredTimer );
	xQueueSend(xsensorTimerQueue,&ulTimerID,0);
    portEXIT_CRITICAL();
}



/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/
void vStartSENSORTasks( void )
{
    /*First Create the queue set such that it will be able to hold a message for
    every space in every queue in the set. */
    xQueueSet = xQueueCreateSet( taskSENSOR_QUEUE_LENGTH + sensorTIMER_QUEUE_LENGTH );

    /* Create the queue that we are going to use for the
    prvSendFrontAndBackTest demo. */
    xSensorTaskQueue = xQueueCreate( taskSENSOR_QUEUE_LENGTH , sizeof( command_type ) );
    xsensorTimerQueue = xQueueCreate( sensorTIMER_QUEUE_LENGTH, sizeof( uint32_t ) );

    // for Queued ADC Conversion
    xsensorAdcQueue = xQueueCreate( sensorADC_QUEUE_LENGTH,   sizeof( uint8_t ) );

    // for Queued IIC Operation
    xsensorIICQueue = xQueueCreate( sensorIIC_QUEUE_LENGTH,   sizeof( uint8_t ) );

    /* vQueueAddToRegistry() adds the queue to the queue registry, if one is
    in use.  The queue registry is provided as a means for kernel aware
    debuggers to locate queues and has no purpose if a kernel aware debugger
    is not being used.  The call to vQueueAddToRegistry() will be removed
    by the pre-processor if configQUEUE_REGISTRY_SIZE is not defined or is
    defined to be less than 1. */
    //vQueueAddToRegistry( xSensorTaskQueue, "SENSOR_Queue" );
    //vQueueAddToRegistry( xsensorTimerQueue, "SENSOR_Queue" );

    xQueueAddToSet( xSensorTaskQueue, xQueueSet );//vQueueAddToRegistry( xPrintQueue, "CLI_Queue" );
    xQueueAddToSet( xsensorTimerQueue, xQueueSet );


#if defined (ADC_USE_POLLING_METHOD)
    /* Create a one-shot timer for use later on in this test. */
    xadcConvCheckTimer = xTimerCreate( "",              /* Text name to facilitate debugging.  The kernel does not use this itself. */
                                5,                      /* The period for the timer(5 msec). */
                                pdFALSE,                /* Don't auto-reload - hence a one shot timer. */
                                ( void * )SENSOR_ADC_CONV_CHECK_TIMER_F,  /* The timer identifier. */
                                prvsensorTimerCallback );   /* The callback to be called when the timer expires. */
#endif

#if defined (IIC_USE_WAIT_TIMER)
    xsensorPollCheckTimer = xTimerCreate( "",           /* Text name to facilitate debugging.  The kernel does not use this itself. */
                                50,                     /* The period for the timer(100 msec). */
                                pdFALSE,                /* Don't auto-reload - hence a one shot timer. */
                                ( void * )SENSOR_POLL_CHECK_F,  /* The timer identifier. */
                                prvsensorTimerCallback );   /* The callback to be called when the timer expires. */
#endif

    xmicAdcCheckTimer = xTimerCreate( "",               /* Text name to facilitate debugging.  The kernel does not use this itself. */
                                1000,                    /* The period for the timer(500 msec). */
                                pdFALSE,                /* Don't auto-reload - hence a one shot timer. */
                                ( void * )SENSOR_MIC_ADC_CHECK_F,  /* The timer identifier. */
                                prvsensorTimerCallback );   /* The callback to be called when the timer expires. */


    xsensorCheckPeriodicTimer = xTimerCreate( "",       /* Text name to facilitate debugging.  The kernel does not use this itself. */
                                1000,                   /* The period for the timer(500 msec). */
                                pdFALSE,                /* Don't auto-reload - hence a one shot timer. */
                                ( void * )SENSOR_SENSOR_CHECK_TIMER_F,  /* The timer identifier. */
                                prvsensorTimerCallback );   /* The callback to be called when the timer expires. */

    /* Spawn the task. */
    xTaskCreate( vSENSORTask, "SENSOR", taskSENSOR_TASK_STACK_SIZE, xQueueSet, taskSENSOR_TASK_PRIORITY, ( TaskHandle_t * ) NULL );

}
    
    
/*-----------------------------------------------------------*/

void vSENSORTask( void *pvParameters )
{
	//QueueHandle_t   xQueue;		// mctask�� queue �ϳ��� ��� �Ҷ�
	QueueSetMemberHandle_t  xQueue;
	QueueSetMemberHandle_t	xActivatedMember;
	command_type	cmd;
    
    ppg_data_type   ppg_data;
    float           eeg_data;
    uint8_t         adc_cmd, current_adc, currenti2c;
    uint32_t        timerid;
    boolean         isAdcStarted = FALSE;
    boolean         isIICStarted = FALSE;
#if defined (IIC_USE_WAIT_TIMER)
    uint8_t         RetryIIC = 0 ;
#endif
    boolean         isEnableMicAdc = FALSE;
    boolean         isEnablePPG = TRUE;
    boolean         isEnableEDA = TRUE;
    boolean         isEnableTEMP = TRUE;
    
    uint8_t         isContact;
    
    uint8_t         *controlDataPtr;
    
	xQueue = ( QueueHandle_t * ) pvParameters;

	sensortask_init(xQueue);
	
	for(;;)
	{
		// �ִ� 2000 msec���� q�� ��ٸ�.
		xActivatedMember =  xQueueSelectFromSet( xQueue, queueSHORT_DELAY );
		// xMcTaskQueue �ϳ��� ��� �� ���
		//if( xQueueReceive( xQueue, &cmd, 2000 ) == pdPASS )

		/* Which set member was selected?  Receives/takes can use a block time
        of zero as they are guaranteed to pass because xQueueSelectFromSet() would
        not have returned the handle unless something was available. */
        if( xActivatedMember == xSensorTaskQueue )
        {
            xQueueReceive( xActivatedMember, &cmd, 0 );
        }
        else if( xActivatedMember == xsensorTimerQueue )
        {
            xQueueReceive( xActivatedMember, &timerid, 0 );
            cmd.cmd = (uint16_t)timerid;
            cmd.len = 0;
			cmd.msg = NULL;
        }
		else
		{
			cmd.cmd = 0;
			cmd.msg = NULL;
		}

		//processing
		switch(cmd.cmd)
		{
			case 0:
				// No cmd rxed, 2000 msec wait timeout
                DBGHI(SEN,"Current Sensor task Status is \r\n");
				break;

            case MC_MODE_STANDBY_MODE_F:
            case MC_MODE_START_MODE_F:
            case MC_MODE_DEMO_MODE_F:
                xTimerStart( xmicAdcCheckTimer, 0 );
                isEnableMicAdc = TRUE;
                InitMicRingbuf();
                break;

            case MC_MODE_TEST_MODE_F:
                xTimerStart( xmicAdcCheckTimer, 0 );
                isEnableMicAdc = TRUE;
                InitMicRingbuf();
                isEnablePPG = TRUE;
                isEnableTEMP = TRUE;
                isEnableEDA = TRUE;
                break;
                
            case MC_MODE_MASS_MODE_F:
            case MC_MODE_IDLE_MODE_F:
                xTimerStop( xmicAdcCheckTimer, 0 );
                isEnableMicAdc = FALSE;
                break;

            case MC_PPG_CONTROL_F:
                controlDataPtr = (uint8_t *)cmd.msg;
                if(controlDataPtr[FDPOS(gen_cmd_msg_field_type,data1)] == 0)
                {
                    isEnablePPG = FALSE;
                    // TODO Stop PPG Driver
                }
                else
                {
                    isEnablePPG = TRUE;
                    // TODO Start PPG Driver
                }
                DBGHI(SEN,"MC_PPG_CONTROL_F (%d)\r\n",controlDataPtr[FDPOS(gen_cmd_msg_field_type,data1)]);
                break;

            case MC_TEMP_CONTROL_F:
                controlDataPtr = (uint8_t *)cmd.msg;
                if(controlDataPtr[FDPOS(gen_cmd_msg_field_type,data1)] == 0)
                {
                    isEnableTEMP = FALSE;
                }
                else
                {
                    isEnableTEMP = TRUE;
                }
                DBGHI(SEN,"MC_TEMP_CONTROL_F (%d)\r\n",controlDataPtr[FDPOS(gen_cmd_msg_field_type,data1)]);
                break;
                
            case MC_EDA_CONTROL_F:
                controlDataPtr = (uint8_t *)cmd.msg;
                if(controlDataPtr[FDPOS(gen_cmd_msg_field_type,data1)] == 0)
                {
                    isEnableEDA = FALSE;
                }
                else
                {
                    isEnableEDA = TRUE;
                }
                DBGHI(SEN,"MC_EDA_CONTROL_F (%d)\r\n",controlDataPtr[FDPOS(gen_cmd_msg_field_type,data1)]);
                break;
                
            case SENSOR_SENSOR_CHECK_TIMER_F:
                xTimerStart( xsensorCheckPeriodicTimer, 0 );
                
                if(isEnableTEMP == TRUE)
                {
                    portENTER_CRITICAL();
                    currenti2c = I2C1_READ_TEMP;
                    xQueueSend(xsensorIICQueue, &currenti2c, 0);
                    portEXIT_CRITICAL();
                }
                
                portENTER_CRITICAL();
                currenti2c = I2C1_READ_ACCE;
                xQueueSend(xsensorIICQueue, &currenti2c, 0);
                portEXIT_CRITICAL();
                
                sendtoSensorCmd(SENSOR_READ_I2C_F);  // next queue
                
                sendtoSensorCmd(SENSOR_READ_BATT_ADC_F);
                sendtoSensorCmd(SENSOR_READ_ETC_ADC_F);
                break;

            case SENSOR_MIC_ADC_CHECK_F:
                
                if(isEnableMicAdc == TRUE)
                {
                    uint8_t i;
                    
                    xTimerStart( xmicAdcCheckTimer, 0 );
                    portENTER_CRITICAL();
                    
                    isMicadc_loop_start = TRUE;

                    for(i=0;i<MICADC_LOOP_MAX_COUNT;i++)
                    {
                        adc_cmd = ADC_MIC;
                        xQueueSend(xsensorAdcQueue, &adc_cmd, 0);
                    }
                    
                    portEXIT_CRITICAL();
                    
                    sendtoSensorCmd(SENSOR_START_ADC_F);
                }
                break;
                
            case PPG_DATA_READY_EVT:
                if(isEnablePPG == TRUE)
                {
                    if( PPG_ReadData(&ppg_data) == TRUE)
                    {
                        // ADD Local Buffer
                        ppgActiveBuffer[ppg_buf_count].sample_IR = ppg_data.sample_IR;
                        ppgActiveBuffer[ppg_buf_count++].sample_LED = ppg_data.sample_LED;
                        DBGTDATA(90,"%f\r\n",ppg_data.sample_LED);
                        DBGTDATA(91,"%f\r\n",ppg_data.sample_IR);

                        if(ppg_buf_count >= MAX_PPG_SIZE_FOR_FFT)
                        {
                            toggle_ppg_buffer_pointer();
                            ppg_buf_count = 0;

                            // 128 �� �̻��̸� FFT Request
                            sendtoMcCmdConstBuf(MC_FFT_PPG_REQ_F, (void *)ppgBackBuffer, MAX_PPG_SIZE_FOR_FFT);
                            DBGMED(SEN,"PPG Data FFT req send to FFT Task \r\n");
                        }
                    }
                }
                break;

            case EEG_DATA_READY_EVT:
                if( EEG_Read_9Byte(&eeg_data, &isContact) == HAL_OK)
                {
                    sensordataCheckLeadOFF(isContact);
                    
                    //if(eegcontact == 0xC0)
                    //if(isEnableEEG == TRUE)
                    {
                        // ADD Local Buffer
                        eegActiveBuffer[eeg_buf_count++] = eeg_data;
                        DBGTDATA(92,"%f\r\n",eeg_data);

                        if(eeg_buf_count >= MAX_EEG_SIZE_FOR_FFT)
                        {
                            toggle_eeg_buffer_pointer();
                            eeg_buf_count = 0;

                            // 500 �� �̻��̸� FFT Request
                            sendtoMcCmdConstBuf(MC_FFT_EEG_REQ_F, eegBackBuffer, MAX_EEG_SIZE_FOR_FFT);
                            
                            LeadOffReportNSetContact(*ptrLeadOffBack);

                            DBGMED(SEN,"EEG Data FFT req send to MC Task \r\n");
                        }
                    }
                }
                else
                {
                    // EEG Data Read Error
                    // TODO
                }
                break;


#if defined (ADC_USE_POLLING_METHOD)
            case SENSOR_ADC_CONV_CHECK_TIMER_F:
#endif                

#if defined (ADC_USE_IT_METHOD)
            case ADC_CONV_COMPLETE_F:
#endif                
                Read_ADC_value(current_adc);
                isAdcStarted = FALSE;

                sensorBattResultReport(current_adc);

                sendtoSensorCmd(SENSOR_START_ADC_F);  // next queue
                break;
                
            case ADC_CONV_OUTOFWIN_F:
            case ADC_ERROR_OCCUR_F:
                break;

            case SENSOR_START_ADC_F:
                // check queue // ������ ���� 
                if(isAdcStarted == FALSE)
                {
                    if( xQueueReceive( xsensorAdcQueue, &current_adc, 0 ) == pdPASS )
                    {
                        if( Start_ADC_Operation(current_adc) == TRUE)
                        {
                            isAdcStarted = TRUE;
                            #if defined (ADC_USE_POLLING_METHOD)
                                xTimerStart( xadcConvCheckTimer, 0 );
                            #endif
                        }
                        else
                        {
                            sendtoSensorCmd(SENSOR_START_ADC_F);  // next queue
                        }
                    }
                }
                break;

            case SENSOR_READ_BATT_ADC_F:
                portENTER_CRITICAL();
                adc_cmd = ADC_BATT;
                xQueueSend(xsensorAdcQueue, &adc_cmd, 0);
                portEXIT_CRITICAL();
                
                portENTER_CRITICAL();
                adc_cmd = ADC_CHARGE;
                xQueueSend(xsensorAdcQueue, &adc_cmd, 0);
                portEXIT_CRITICAL();

                portENTER_CRITICAL();
                adc_cmd = ADC_BATT_TEMP;
                xQueueSend(xsensorAdcQueue, &adc_cmd, 0);
                portEXIT_CRITICAL();

                sendtoSensorCmd(SENSOR_START_ADC_F);                
                break;
                
            case SENSOR_READ_ETC_ADC_F:
                portENTER_CRITICAL();
                adc_cmd = ADC_LIGHT;
                xQueueSend(xsensorAdcQueue, &adc_cmd, 0);
                portEXIT_CRITICAL();
                
                if(isEnableEDA == TRUE)
                {
                    portENTER_CRITICAL();
                    adc_cmd = ADC_EDA;
                    xQueueSend(xsensorAdcQueue, &adc_cmd, 0);
                    portEXIT_CRITICAL();
                }
                sendtoSensorCmd(SENSOR_START_ADC_F);               
                break;        

            case SENSOR_DATA_REQ_F:
                //MC �� ���� �䱸�� �޾Ƽ� ���� ����
                sendSensorResult2mc();
                
                // Mic Value �ʱ�ȭ 
                //micsensorInitPeakValue();
                DBGHI(SEN,"Send Sensors Result to mc.\r\n");
                break;

            case SENSOR_READ_I2C_F:
                if(isIICStarted == FALSE)
                {
                    if( xQueueReceive( xsensorIICQueue, &currenti2c, 0 ) == pdPASS )
                    {
                        if( currenti2c == I2C1_READ_TEMP)
                        {
                            sendtoSensorCmd(SENSOR_READ_TEMP_F);               
                        }
                        else if(currenti2c == I2C1_READ_ACCE)
                        {
                            sendtoSensorCmd(SENSOR_READ_ACCE_F);
                        }
                        else
                        {
                            sendtoSensorCmd(SENSOR_READ_I2C_F);  // next queue
                        }
                    }
                }
                break;
                
            case SENSOR_READ_ACCE_F:
                {
                    int8_t x,y,z;
                    uint16_t x16,y16,z16;
                    int16_t cx,cy,cz;
                    
                    LIS2DH_READ();
                    GetAcceVal(&x,&y,&z);
                    GetAcceVal16(&x16,&y16,&z16);
                    GetCalcedVal(&cx,&cy,&cz);
                    
                    DBGLOW(SEN,"Acc X,Y,Z Val = (%d,%d,%d)\r\n",x,y,z);
                    DBGTEST(4,"Acc_X_Y_Z:(%d,%d,%d), Calced:(%d,%d,%d)\r\n",x,y,z,cx,cy,cz);
                    
                    sendtoSensorCmd(SENSOR_READ_I2C_F);  // next queue
                }
                break;
				
            case SENSOR_READ_TEMP_F:
                // Read Temperature
                isIICStarted = TRUE;
                if(SHT2x_MeasurePoll() == HAL_OK)
                {
#if defined (IIC_USE_WAIT_TIMER)
                    xTimerStart(xsensorPollCheckTimer,0);
                    RetryIIC = 5;
#endif                    
                }
                else
                {
                    isIICStarted = FALSE;
                    DBGERR(SEN,"I2C Error.!!!\r\n");
                }

#if !defined (IIC_USE_WAIT_TIMER)
                isIICStarted = FALSE;
                sendtoSensorCmd(SENSOR_READ_I2C_F);  // next queue
#endif                
                break;

#if defined (IIC_USE_WAIT_TIMER)
            case SENSOR_POLL_CHECK_F:
                {
                    uint8_t tempc;
                    
                    if(SHT2x_ReadData(&tempc) == HAL_OK)
                    {
                        DBGMED(SEN,"Temp = %d\r\n",GetTempC());
                        DBGTEST(5,"Temp:%.1f\r\n",GetTempCfloat());
                        isIICStarted = FALSE;
                        sendtoSensorCmd(SENSOR_READ_I2C_F);  // next queue
                    }
                    else
                    {
                        if(RetryIIC-- > 0)
                        {
                            DBGERR(SEN,"I2C Error.!!!\r\n");
                            xTimerStart(xsensorPollCheckTimer,0);
                            UpdateSensorStatus(TEMP_POSITION, OFF);
                        }
                        else
                        {
                            isIICStarted = FALSE;
                            xTimerStop(xsensorPollCheckTimer,0);
                        }
                    }
                }
                break;
#endif                
			default:
				break;
		}

		if( (cmd.msg != NULL) && (cmd.isconst == FALSE))
		{
			cmd_mfree(cmd.msg);
		}
	}
}

/*-----------------------------------------------------------*/

