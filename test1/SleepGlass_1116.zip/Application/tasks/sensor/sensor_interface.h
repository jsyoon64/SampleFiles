#ifndef SENSOR_INTERFACE_H
#define SENSOR_INTERFACE_H
/*===============================================================================================
 *
 *   @file sensor_interface.h
 *
 *   @version v1.0
 *
 =================================================================================================


Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*================================================================================================
 INCLUDE FILES
=================================================================================================*/

/*=================================================================================================
 CONSTANTS
=================================================================================================*/

#define MUSIC_FLAG_POSITION	0
#define LED_FLAG_POSITION	1
#define EDA_POSITION 		2
#define LIGHT_POSITION		3
#define TEMP_POSITION		4
#define ACC_POSTION			5
#define PPG_POSTION			6
#define EEG_POSTION			7

/*=================================================================================================
 ENUMS
=================================================================================================*/


/*=================================================================================================
 STRUCTURES AND OTHER TYPEDEFS
=================================================================================================*/

typedef struct {
    uint8               DevContact[1];
    uint8               Sensor_status[1];
    uint8               EDA_Value[1];
    uint8               AcceXValue[2];
	uint8               AcceYValue[2];
	uint8               AcceZValue[2];
    uint8               BatteryStatus[1];
    uint8               MicPeak[1];
    uint8               Temp[1];
	uint8				LightSensor[1];
    uint8               EndofData[1];
} sensor_status_field_type;


/*===============================================================================================*/
#endif  /* SENSOR_INTERFACE_H */
