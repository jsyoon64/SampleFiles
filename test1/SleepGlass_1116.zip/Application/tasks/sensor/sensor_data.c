/*===============================================================================================*/
/**
 *   @file sensor_data.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "comdef.h"
#include "signals.h"
#include "command.h"
#include "task_cfg.h"
#include "interface.h"
#include "sensor_data.h"
#include "ads1292.h"
#include "afe4400.h"
#include "adc_operation.h"
#include "lis2dh.h"
#include "sht20.h"
#include "debugmsgcli.h"

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/
//double buffering for eeg FFT
float EEG_Buffer_1[MAX_EEG_BUFFER_SIZE];
float EEG_Buffer_2[MAX_EEG_BUFFER_SIZE];
float* eegActiveBuffer;         //pointer to array for FFT
float* eegBackBuffer;               //pointer to array for storing datas
uint8_t eegBufferFlag = 0;          // flag for switch buffer
uint16_t eeg_buf_count=0;


//double buffering for ppg FFT
ppg_data_type PPG_Buffer_1[MAX_PPG_BUFFER_SIZE];
ppg_data_type PPG_Buffer_2[MAX_PPG_BUFFER_SIZE];
ppg_data_type* ppgActiveBuffer;         //pointer to array for FFT
ppg_data_type* ppgBackBuffer;               //pointer to array for storing datas
uint8_t ppgBufferFlag = 0;          // flag for switch buffer
uint16_t ppg_buf_count=0;

// double buffering for LEADOFF 
uint16_t LeadOff1 = 0;
uint16_t LeadOff2 = 0;
uint16_t *ptrLeadOffAct;
uint16_t *ptrLeadOffBack;

uint8_t DevContact=0;

uint8_t SensorStatus = 0;

/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/

/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/
uint8_t UpdateSensorStatus(uint8_t position, boolean onoff)
{
    uint8_t status = 1 << position;

    if(onoff == TRUE)
    {
        SensorStatus |= status;
    }
    else
    {
        SensorStatus &= ~status;
    }
    return SensorStatus;
}

void toggle_eeg_buffer_pointer(void)
{
    if(eegBufferFlag == 0)
    {
        // init double buffer    
        eegActiveBuffer = EEG_Buffer_1;
        eegBackBuffer = EEG_Buffer_2;

        ptrLeadOffAct = &LeadOff1;
        ptrLeadOffBack = &LeadOff2;
        eegBufferFlag = 1;
    }
    else
    {
        eegActiveBuffer = EEG_Buffer_2;
        eegBackBuffer = EEG_Buffer_1;

        ptrLeadOffAct = &LeadOff2;
        ptrLeadOffBack = &LeadOff1;

        eegBufferFlag = 0;
    }
    
    *ptrLeadOffAct = 0;
}


void toggle_ppg_buffer_pointer(void)
{
    if(ppgBufferFlag == 0)
    {
        // init double buffer    
        ppgActiveBuffer = PPG_Buffer_1;
        ppgBackBuffer = PPG_Buffer_2;
        ppgBufferFlag = 1;
    }
    else
    {
        ppgActiveBuffer = PPG_Buffer_2;
        ppgBackBuffer = PPG_Buffer_1;
        ppgBufferFlag = 0;
    }
}


void sendtoMcCmdConstBuf(uint16_t command, void * data, uint16_t len)
{
	command_type	cmd;

    portENTER_CRITICAL();
	cmd.len = len;
	cmd.msg = (void*)data;
    cmd.isconst = TRUE;
	cmd.cmd = command;
	xQueueSend(xMcTaskQueue,&cmd,sensorNO_BLOCK);
    portEXIT_CRITICAL();
}


void sendtoSensorCmd(uint16_t command)
{
	command_type	cmd;

    portENTER_CRITICAL();
	cmd.len = 0;
	cmd.msg = NULL;
    cmd.isconst = FALSE;
	cmd.cmd = command;
	xQueueSend(xSensorTaskQueue,&cmd,sensorNO_BLOCK);
    portEXIT_CRITICAL();
}

void sendSensorResult2mc( void)
{
	command_type	cmd;
	uint8_t * data;

    if((data = (uint8_t *)cmd_malloc(FDPOS(sensor_status_field_type,EndofData))) != NULL)
    {
        cmd.len = FDPOS(sensor_status_field_type,EndofData);
        cmd.isconst = FALSE;
        cmd.cmd = SENSOR_DATA_RESULT_EVT;

        memcpy(&data[FDPOS(sensor_status_field_type,DevContact)],
               &DevContact,
               FDSIZ(sensor_status_field_type,DevContact));

#if defined(TEST_CHARGING_STATUS)
        memcpy(&data[FDPOS(sensor_status_field_type,Sensor_status)],
               &ChargingStatus,
               FDSIZ(sensor_status_field_type,Sensor_status));
#else
        memcpy(&data[FDPOS(sensor_status_field_type,Sensor_status)],
               &SensorStatus,
               FDSIZ(sensor_status_field_type,Sensor_status));
#endif
        memcpy(&data[FDPOS(sensor_status_field_type,EDA_Value)],
               &EDA_Value,
               FDSIZ(sensor_status_field_type,EDA_Value));
        
        memcpy(&data[FDPOS(sensor_status_field_type,AcceXValue)],
               &CalcedXValue,
               FDSIZ(sensor_status_field_type,AcceXValue));

        memcpy(&data[FDPOS(sensor_status_field_type,AcceYValue)],
               &CalcedYValue,
               FDSIZ(sensor_status_field_type,AcceYValue));

        memcpy(&data[FDPOS(sensor_status_field_type,AcceZValue)],
               &CalcedZValue,
               FDSIZ(sensor_status_field_type,AcceZValue));
        
        memcpy(&data[FDPOS(sensor_status_field_type,BatteryStatus)],
               &BatteryStatus,
               FDSIZ(sensor_status_field_type,BatteryStatus));
        
        memcpy(&data[FDPOS(sensor_status_field_type,MicPeak)],
               &MicPeak,
               FDSIZ(sensor_status_field_type,MicPeak));
			   
		memcpy(&data[FDPOS(sensor_status_field_type,LightSensor)],
			   &LightSensor,
			   FDSIZ(sensor_status_field_type,LightSensor));

        uint8_t temp_data = GetTempC();
        memcpy(&data[FDPOS(sensor_status_field_type,Temp)],
               &temp_data,
               FDSIZ(sensor_status_field_type,Temp));
        
        cmd.msg = data;

        portENTER_CRITICAL();
        xQueueSend(xMcTaskQueue,&cmd,sensorNO_BLOCK);
        portEXIT_CRITICAL();        
    }
    
    else
    {
        DBGERR(GEN,"MEM Alloc Error!!!....\r\n");
    }
}


void sensordataCheckLeadOFF(uint8_t leadoff)
{
    if(leadoff != 0)
        (*ptrLeadOffAct)++;
}

void LeadOffReportNSetContact(uint16_t leadoff_cnt)
{
   
    if(leadoff_cnt == 0) //if contacted change from IDLE->STANBY
    {
        // send cmd to mc Contact
        sendtoMcCmdConstBuf(SENSOR_MASK_WORN_EVT, NULL, 0);
        DevContact = 1;
    }
    else
    {
        // send cmd to mc NonContact
        sendtoMcCmdConstBuf(SENSOR_MASK_OFF_EVT, NULL, 0);
        DevContact = 0;
    }
}

void sensorBattResultReport(uint8_t adc_chan)
{
    if(adc_chan == ADC_BATT)
    {
        sendtoMcCmdConstBuf(SENSOR_BATT_VAL_EVT, &BatteryStatus, 1);
    }
    else if (adc_chan == ADC_BATT_TEMP)
    {
        sendtoMcCmdConstBuf(SENSOR_BATT_TEMP_EVT, &BatteryTemp, 1);
    }
    else if (adc_chan == ADC_CHARGE)
    {
        sendtoMcCmdConstBuf(SENSOR_CHARGE_STATUS_ADC_EVT, &ChargingStatus, 1);
    }
    
}
/*===============================================================================================*/
