#ifndef _AFE4400_H_
#define _AFE4400_H_
/*===============================================================================================*/
/**
 *   @file afe4400.h
 *
 *   @version v1.0
 */
/*=================================================================================================


Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------


===================================================================================================*/
/* Standard includes. */

/* Scheduler include files. */
#include "FreeRTOS.h"
#include "stm32f4xx_hal.h"
#include "spi.h"


/* Application include files. */
#include "target.h"
#include "comdef.h"


/*=================================================================================================
 CONSTANTS
=================================================================================================*/
#define LED2STC_ADDR		0x01
#define LED2ENDC_ADDR		0x02
#define LED2LEDSTC_ADDR		0x03
#define LED2LEDENDC_ADDR	0x04
#define ALED2STC_ADDR		0x05
#define ALED2ENDC_ADDR		0x06
#define LED1STC_ADDR		0x07
#define LED1ENDC_ADDR		0x08
#define LED1LEDSTC_ADDR		0x09
#define LED1LEDENDC_ADDR	0x0A
#define ALED1STC_ADDR		0x0B
#define ALED1ENDC_ADDR		0x0C
#define LED2CONVST_ADDR		0x0D
#define LED2CONVEND_ADDR	0x0E
#define ALED2CONVST_ADDR	0x0F
#define ALED2CONVEND_ADDR	0x10
#define LED1CONVST_ADDR		0x11
#define LED1CONVEND_ADDR	0x12
#define ALED1CONVST_ADDR	0x13
#define ALED1CONVEND_ADDR	0x14
#define ADCRSTSTCT0_ADDR	0x15
#define ADCRSTENDCT0_ADDR	0x16
#define ADCRSTSTCT1_ADDR	0x17
#define ADCRSTENDCT1_ADDR	0x18
#define ADCRSTSTCT2_ADDR	0x19
#define ADCRSTENDCT2_ADDR	0x1A
#define ADCRSTSTCT3_ADDR	0x1B
#define ADCRSTENDCT3_ADDR	0x1C
#define PRPCOUNT_ADDR		0x1D
#define CONTROL1_ADDR		0x1E
#define SPARE1_ADDR			0x1F
#define TIAGAIN_GAIN_ADDR	0x20
#define TIA_AMB_GAIN_ADDR	0x21
#define LEDCNTRL_ADDR		0x22
#define CONTROL2_ADDR		0x23
#define SPARE2_ADDR			0x24
#define SPARE3_ADDR			0x25
#define SPARE4_ADDR			0x26
#define RESERVED1_ADDR		0x27
#define RESERVED2_ADDR		0x28
#define ALARM_ADDR			0x29
#define LED2VAL_ADDR		0x2A
#define ALED2VAL_ADDR		0x2B
#define LED1VAL_ADDR		0x2C
#define ALED1VAL_ADDR		0x2D
#define LED2_ALED2VAL_ADDR	0x2E
#define LED1_ALED1VAL_ADDR	0x2F

#define H_RATE	2

#define LED2STC_DATA		6050 *H_RATE
#define LED2ENDC_DATA		7998 *H_RATE
#define LED2LEDSTC_DATA		6000 *H_RATE
#define LED2LEDENDC_DATA	7999 *H_RATE
#define ALED2STC_DATA		50 *H_RATE
#define ALED2ENDC_DATA		1998 *H_RATE
#define LED1STC_DATA		2050 *H_RATE
#define LED1ENDC_DATA		3998 *H_RATE
#define LED1LEDSTC_DATA		2000 *H_RATE
#define LED1LEDENDC_DATA	3999 *H_RATE
#define ALED1STC_DATA		4050 *H_RATE
#define ALED1ENDC_DATA		5998 *H_RATE
#define LED2CONVST_DATA		4 *5
//#define LED2CONVST_DATA		4 *H_RATE
#define LED2CONVEND_DATA	1999 *H_RATE
#define ALED2CONVST_DATA	2004 *H_RATE
#define ALED2CONVEND_DATA	3999 *H_RATE
#define LED1CONVST_DATA		4004 *H_RATE
#define LED1CONVEND_DATA	5999 *H_RATE
#define ALED1CONVST_DATA	6004 *H_RATE
#define ALED1CONVEND_DATA	7999 *H_RATE
#define ADCRSTSTCT0_DATA	0
#define ADCRSTENDCT0_DATA	3 *H_RATE
#define ADCRSTSTCT1_DATA	2000 *H_RATE
#define ADCRSTENDCT1_DATA	2003 *H_RATE
#define ADCRSTSTCT2_DATA	4000 *H_RATE
#define ADCRSTENDCT2_DATA	4003 *H_RATE
#define ADCRSTSTCT3_DATA	6000 *H_RATE
#define ADCRSTENDCT3_DATA	6003 *H_RATE
#define PRPCOUNT_DATA		7999 *H_RATE

/*=================================================================================================
 STRUCTURES AND OTHER TYPEDEFS
=================================================================================================*/

typedef struct
{
    float       sample_LED;
    float       sample_IR;
} ppg_data_type;


/*=================================================================================================
 FUNCTION PROTOTYPES
=================================================================================================*/
void PPG_Init(void);
boolean PPG_ReadData(ppg_data_type * data);
/*===============================================================================================*/
#endif  /* _AFE4400_H_ */
