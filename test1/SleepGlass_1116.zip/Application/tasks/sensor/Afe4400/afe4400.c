/*===============================================================================================*/
/**
 *   @file afe4400.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.

===================================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "afe4400.h"


/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/
#define PPG_MAX_RESP_TIME   100 // 100 msec max operate time

#if defined(SHINWOOHW)
    #define PPG_SPI hspi4
#elif defined(FRASENHW)
    #define PPG_SPI hspi2
#endif
/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/
static uint32_t ppg_reg_data[31] =
{
	0, /* Control Register */
    LED2STC_DATA,   LED2ENDC_DATA,  LED2LEDSTC_DATA,LED2LEDENDC_DATA, ALED2STC_DATA,
    ALED2ENDC_DATA, LED1STC_DATA,   LED1ENDC_DATA,  LED1LEDSTC_DATA,  LED1LEDENDC_DATA,
    ALED1STC_DATA,  ALED1ENDC_DATA, LED2CONVST_DATA,LED2CONVEND_DATA, ALED2CONVST_DATA,
    ALED2CONVEND_DATA, LED1CONVST_DATA, LED1CONVEND_DATA, ALED1CONVST_DATA, ALED1CONVEND_DATA,
    ADCRSTSTCT0_DATA, ADCRSTENDCT0_DATA,ADCRSTSTCT1_DATA, ADCRSTENDCT1_DATA, ADCRSTSTCT2_DATA,
    ADCRSTENDCT2_DATA, ADCRSTSTCT3_DATA, ADCRSTENDCT3_DATA, PRPCOUNT_DATA, 0x000102
};

uint8_t rxBuf[3];
uint8_t txBuf[4];


uint32_t samples_count_PPG=0;
uint32_t samples_count_PPG_250=0;


/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/
void PPG_SPI_Write(uint32_t ppdata, uint8_t regAddr)
{
    #ifndef PPG_HARD_NSS
    // Select AFE4400(PPG) (CS low)
    HAL_GPIO_WritePin(PPG_CS, GPIO_PIN_RESET); // set PPG_CS to low
    #endif
    
    txBuf[0]= 0x00;
    txBuf[1]= 0x00;
    txBuf[2]= 0x00;
    txBuf[3]= 0x00;
    HAL_SPI_Transmit(&PPG_SPI, txBuf, 4, PPG_MAX_RESP_TIME);

    txBuf[0]= regAddr;
    txBuf[1]= ((ppdata >> 16) &0xFF);
    txBuf[2]= ((ppdata >> 8) &0xFF);
    txBuf[3]= (ppdata  &0xFF);
    HAL_SPI_Transmit(&PPG_SPI, txBuf, 4, PPG_MAX_RESP_TIME);

    #ifndef PPG_HARD_NSS
    // Select AFE4400(PPG) (CS high)
    HAL_GPIO_WritePin(PPG_CS, GPIO_PIN_SET); // set PPG_CS to high
    #endif
}

uint32_t PPG_SPI_Read(uint8_t regAddr)
{
    uint32_t l_retResult;

    #ifndef PPG_HARD_NSS
    // Select AFE4400(PPG) (CS low)
    HAL_GPIO_WritePin(PPG_CS, GPIO_PIN_RESET); // set PPG_CS to low
    #endif
    
    txBuf[0]= 0x00;
    txBuf[1]= 0x00;
    txBuf[2]= 0x00;
    txBuf[3]= 0x01;
    HAL_SPI_Transmit(&PPG_SPI, txBuf, 4, PPG_MAX_RESP_TIME);
    
    txBuf[0]=regAddr;
    HAL_SPI_Transmit(&PPG_SPI, txBuf, 1, PPG_MAX_RESP_TIME);
    
    HAL_SPI_Receive(&PPG_SPI, rxBuf, 3, PPG_MAX_RESP_TIME );
        
    #ifndef PPG_HARD_NSS
    // Select AFE4400(PPG) (CS high)
    HAL_GPIO_WritePin(PPG_CS, GPIO_PIN_SET); // set PPG_CS to high
    #endif

    l_retResult = rxBuf[0];
    l_retResult = (l_retResult << 8) & 0xFF00;
    l_retResult += rxBuf[1];
    l_retResult = (l_retResult << 8) & 0xFFFF00;
    l_retResult += rxBuf[2];

    return l_retResult;
}

/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/


/*===========================================================================
FUNCTION            PPG_Init           
DESCRIPTION     
DEPENDENCIES        SPI4
RETURN VALUE
===========================================================================*/
void PPG_Init(void)
{
    //uint8_t txDaqta[4];
    uint8_t i;
    //uint32_t count;

    //HAL_Delay(100); 
    vTaskDelay(100);
    
    HAL_GPIO_WritePin(PPG__RESET_GPIO_Port, PPG__RESET_Pin, GPIO_PIN_SET);
    HAL_GPIO_WritePin(PPG__PDN_GPIO_Port, PPG__PDN_Pin, GPIO_PIN_SET);
    
    #ifndef PPG_HARD_NSS
    // Select AFE4400(PPG) (CS low)
    HAL_GPIO_WritePin(PPG_CS, GPIO_PIN_RESET); // set PPG_CS to low
    #endif
    
    txBuf[0]= 0x00;
    txBuf[1]= 0x00;
    txBuf[2]= 0x00;
    txBuf[3]= 0x0A;
    HAL_SPI_Transmit(&PPG_SPI, txBuf, 4, PPG_MAX_RESP_TIME);

    #ifndef PPG_HARD_NSS
    // Select AFE4400(PPG) (CS high)
    HAL_GPIO_WritePin(PPG_CS, GPIO_PIN_SET); // set PPG_CS to high
    #endif
    
    //HAL_Delay(80); 
    vTaskDelay(80);
    //delay_ms(8);

#ifndef PPG_HARD_NSS
    // Select AFE4400(PPG) (CS low)
    HAL_GPIO_WritePin(PPG_CS, GPIO_PIN_RESET); // set PPG_CS to low
#endif
    txBuf[0]= 0x00;
    txBuf[1]= 0x00;
    txBuf[2]= 0x00;
    txBuf[3]= 0x00;
    HAL_SPI_Transmit(&PPG_SPI, txBuf, 4, PPG_MAX_RESP_TIME);

    #ifndef PPG_HARD_NSS
    // Select AFE4400(PPG) (CS high)
    HAL_GPIO_WritePin(PPG_CS, GPIO_PIN_SET); // set PPG_CS to high
    #endif
    
    for(i=1; i<0x1F; i++) {
        PPG_SPI_Write(ppg_reg_data[i], i);
    }

#if (0)
    PPG_SPI_Write(0x020100, 0x23);
    PPG_SPI_Write(0x01FFFF, 0x22);      //LED Current (up to FS)
    PPG_SPI_Write(0x000000, 0x1F);      //SPARE1 reg.
    PPG_SPI_Write(0x000000, 0x20);      //TIAGAIN   reg.
    PPG_SPI_Write(0x004000, 0x21);      //TIA_AMB_GAIN  default  p63
#else
    //PPG_SPI_Write(0x00FA00, 0x1D);	//Pulse Repetition Period count Dec = 7999 range 800~64000
    //PPG_SPI_Write(0x000005, 0x21);	//Ambient DAC 0uA, stage 2 amplify disable, stage 2 gain 0 dB, Cf= 5 pF, Rf=  10k BW=20MHz
    //PPG_SPI_Write(0x054200, 0x21);	    //Ambient DAC 5uA, stage 2 amplify enable,  stage 2 gain 6 dB, Cf= 5 pF, Rf=  500k	BW=400Hz
    PPG_SPI_Write(0x0A0001, 0x21);	//Ambient DAC 10uA, stage 2 amplify enable,  stage 2 gain 6 dB, Cf= 5 pF, Rf=  100k	BW=2MHz
    //PPG_SPI_Write(0x05000A, 0x21);	//Ambient DAC 5uA, stage 2 amplify enable,  stage 2 gain 6 dB, Cf= 10 pF, Rf=  100k	BW=2MHz
    //PPG_SPI_Write(0x000001, 0x21);	//Ambient DAC 5uA, stage 2 amplify enable,  stage 2 gain 6 dB, Cf= 10 pF, Rf=  100k	BW=2MHz
    /*count = */PPG_SPI_Read(0x21);
    //PPG_SPI_Write(0x016666, 0x22);		//LED Current (up to FS): turn on LED current = 20mA
    PPG_SPI_Write(0x013030, 0x22);	//LED Current (up to FS): turn on LED current = 10mA
    //PPG_SPI_Write(0x013300, 0x22);	//LED Current (up to FS): turn on LED current = 10mA
    /*count = */PPG_SPI_Read(0x22);
    PPG_SPI_Write(0x020100, 0x23);  //config: LED H-bridge,
#endif
}


/*===========================================================================
FUNCTION            PPG_ReadData           
DESCRIPTION         
DEPENDENCIES        SPI4
RETURN VALUE
===========================================================================*/
boolean PPG_ReadData(ppg_data_type * data)
{
	uint32_t ppg_reg_1, ppg_reg_2;
	uint32_t sample_LED,sample_IR;
	int32_t	 intLED,intIR;
	float buff_temp,buff_temp_2;

	ppg_reg_1 = PPG_SPI_Read(0x21);
	ppg_reg_2 = PPG_SPI_Read(0x22);

	(void)ppg_reg_1;
	(void)ppg_reg_2;

	samples_count_PPG_250++;
    
	//if(samples_count_PPG_250 >= 10)
    //if(samples_count_PPG_250 >= 2)
    {
		samples_count_PPG_250 = 0;

		sample_LED = PPG_SPI_Read(LED1_ALED1VAL_ADDR);
		sample_LED = sample_LED & 0x3FFFFF;// arvid - test code

		sample_IR = PPG_SPI_Read(LED2_ALED2VAL_ADDR);
		sample_IR = sample_IR & 0x3FFFFF;// arvid - test code

		//buff_temp = (float)sample_LED;
		if (sample_LED > 0x1FFFFF){
			intLED = (int32_t)(sample_LED | 0xFFC00000);
			//buff_temp = buff_temp - 0xFFFFFFFF;
			//buff_temp = buff_temp - 0x3FFFFF;// arvid - test code
			//buff_temp = buff_temp & 0x3FFFFF;		// arvid - test code
		}
		else
		{
			intLED = (int32_t)sample_LED;
		}
		//buff_temp_2 = (float)sample_IR;
		if (sample_IR > 0x1FFFFF){
			intIR = (int32_t)(sample_IR | 0xFFC00000);
			//buff_temp_2 = buff_temp_2 - 0xFFFFFFFF;
			//buff_temp_2 = buff_temp_2 - 0x3FFFFF;// arvid - test code
			//buff_temp_2 = buff_temp_2 & 0x3FFFFF;		// arvid - test code
		}
		else
		{
			intIR = (int32_t)sample_IR;
		}
		buff_temp = (float)intLED;
		buff_temp_2 = (float)intIR;

#ifdef FFT_PPG_ON
//normalized value of PPG (<1) for FFT calculation
		//BackBuffer_PPG_LED[samples_count_PPG]= buff_temp/8388607;
		buff_temp = buff_temp/(float)0x1FFFFF;
//			BackBuffer_PPG_LED[samples_count_PPG]= buff_temp; 		//raw value
		//BackBuffer_PPG_IR[samples_count_PPG]= buff_temp_2/8388607;
		buff_temp_2 = buff_temp_2/(float)0x1FFFFF;
//			BackBuffer_PPG_IR[samples_count_PPG]= buff_temp_2;		//Raw value
#endif
        data->sample_LED = buff_temp;
        data->sample_IR = buff_temp_2;

        return TRUE;
	}

    return FALSE;
}


/*===============================================================================================*/
