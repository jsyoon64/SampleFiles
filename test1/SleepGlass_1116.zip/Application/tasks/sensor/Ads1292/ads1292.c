/*===============================================================================================*/
/**
 *   @file ads1292.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.

===================================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "signals.h"
#include "command.h"
#include "ads1292.h"
#include "FIR_Filter.h"
#include "debugmsgcli.h"

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/
#define EEG_MAX_RESP_TIME   100 // 100 msec max operate time

#if defined(SHINWOOHW)
    #define EEG_SPI hspi2
#elif defined(FRASENHW)
    #define EEG_SPI hspi4
#endif

/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/
HAL_StatusTypeDef EEGCmdWrite(uint8_t opcmd)
{
    uint8_t opbuf= opcmd;
    return HAL_SPI_Transmit(&EEG_SPI, &opbuf, 1, EEG_MAX_RESP_TIME);
}

HAL_StatusTypeDef EEGRegDataWrite(uint8_t startindex, uint8_t wrdata)
{
    uint8_t buf[3];

    buf[0]= startindex | 0x40; //write
    buf[1]= 0x00;
    buf[2] = wrdata;
    return HAL_SPI_Transmit(&EEG_SPI, buf, 3, EEG_MAX_RESP_TIME);
}

uint8_t EEGRegDataRead(uint8_t startIndex)
{
    uint8_t buf[2];
    uint8_t rdbuf;

    buf[0]= startIndex | 0x20; //read
    buf[1]= 0x00;
    if( HAL_SPI_Transmit(&EEG_SPI, buf, 2, EEG_MAX_RESP_TIME) == HAL_OK)
    {
        if( HAL_SPI_Receive(&EEG_SPI, &rdbuf, 1, EEG_MAX_RESP_TIME ) == HAL_OK)
        {
            return rdbuf;
        }
    }
    return 0;
}


/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/

/*===========================================================================
FUNCTION            EEG_Init           
DESCRIPTION         Initializee ADS1292 EEG Chip.
DEPENDENCIES        SPI2
RETURN VALUE
===========================================================================*/
int EEG_Init(void)
{    
    uint16_t    MaxRetryCount=0;
    uint8_t     temp_read_data;
    int         ret = 0;
    //uint32_t    i;
    
     //wait 1 sec
    //HAL_Delay(1000); 
    vTaskDelay(1000);

    HAL_GPIO_WritePin(EEG__PWD__RESET_GPIO_Port,EEG__PWD__RESET_Pin,GPIO_PIN_RESET); //ADS_RESET= 0
    //HAL_Delay(100);
    vTaskDelay(100);
    HAL_GPIO_WritePin(EEG__PWD__RESET_GPIO_Port,EEG__PWD__RESET_Pin,GPIO_PIN_SET); //ADS_RESET= 1
    //HAL_Delay(10);
    vTaskDelay(10);

#ifndef EEG_HARD_NSS
    HAL_GPIO_WritePin(EEG_CS, GPIO_PIN_RESET); // set EEG_CS to low
#endif
	EEGCmdWrite(EEG_SDATAC_OPC);
	temp_read_data = EEGRegDataRead(EEG_WREG_ID);
	EEGRegDataWrite(EEG_WREG_CONFIG2,0xE0);		//Using internal Ref, turn off lead-off comparator
	temp_read_data = EEGRegDataRead(EEG_WREG_CONFIG2);
	EEGRegDataWrite(EEG_WREG_CONFIG1,0x01);		//continuous sampling, data_rate = 250 sps
	temp_read_data = EEGRegDataRead(EEG_WREG_CONFIG1);
	EEGRegDataWrite(EEG_RLD_SENS, 0x20);		//turn on buffer for RLD;
	temp_read_data = EEGRegDataRead(EEG_RLD_SENS);
	EEGRegDataWrite(EEG_RESP2, 0x07);		// calibration off, ADS1292 set
	EEGRegDataWrite(EEG_RESP1, 0x02);

	EEGRegDataWrite(EEG_WREG_LOFF,0xF0);		//default setting for Lead-off: threshold 70%,

	EEGRegDataWrite(EEG_LOFF_SENS,0x13);		// CH1 Lead-off enable
	EEGRegDataWrite(EEG_LOFF_STAT,0x00);

	MaxRetryCount=0;
    do
    {
		EEGRegDataWrite(EEG_WREG_CH1SET, 0x00);		// PGA=6
        HAL_Delay(1);
        temp_read_data = EEGRegDataRead(EEG_WREG_CH1SET);
#if (1)
        if(MaxRetryCount++ > 20)
        {
            ret -= 1;
            break;
        }
#endif
        
    }while (temp_read_data != 0x00);;		// PGA=6

	EEGRegDataWrite(EEG_WREG_CH2SET, 0x80);		//CH2 power down
	temp_read_data = EEGRegDataRead(EEG_WREG_CH2SET);

    HAL_GPIO_WritePin(EEG_START_GPIO_Port,EEG_START_Pin, GPIO_PIN_RESET); //EEG_START= 0
     //wait 1 sec
    //HAL_Delay(1000); 
     
    EEGCmdWrite(EEG_RDATAC_OPC);
	EEGCmdWrite(EEG_START_OPC);

#ifndef EEG_HARD_NSS
    HAL_GPIO_WritePin(EEG_CS, GPIO_PIN_SET); // set EEG_CS to High
#endif

     //wait 1 sec
   // HAL_Delay(1000); 
    vTaskDelay(1000);

    MaxRetryCount=0;
    while( HAL_GPIO_ReadPin(EEG__DRDY_GPIO_Port,EEG__DRDY_Pin) == GPIO_PIN_SET)
    {
        //HAL_Delay(10); 
        vTaskDelay(10);
        
        if(MaxRetryCount++ > 5)
        {
            ret -= 2;
            break;
        }
    }

    (void)temp_read_data;

    return ret;
}

/*===========================================================================
FUNCTION            EEG_Read_9Byte           
DESCRIPTION         Read data 9 byte from ADS1292 EEG Chip.
DEPENDENCIES        SPI2
RETURN VALUE
===========================================================================*/
HAL_StatusTypeDef EEG_Read_9Byte(float * result, uint8_t *isContact)
{    
    uint8_t     databuf[10];
    uint32_t    u32result = 0;
    int32_t		s32result;
    uint16_t    leadoffData = 0;
    HAL_StatusTypeDef ret = HAL_ERROR;

    int32_t	    s32result_ori;
    float		result_IIR, result_Nocth;

#ifndef EEG_HARD_NSS
    HAL_GPIO_WritePin(EEG_CS, GPIO_PIN_RESET); // set EEG_CS to Low
#endif

    if( HAL_SPI_Receive(&hspi2, &databuf[0], 9, EEG_MAX_RESP_TIME ) == HAL_OK)
    {
        // 24 status bits is: (1100 + LOFF_STAT[4:0] + GPIO[1:0] + 13 '0's).
        leadoffData =  ((uint16_t)(databuf[0] << 8) & 0xFF00);
        leadoffData += ((uint16_t)(databuf[1]     ) & 0x0080);

        *isContact = (uint8_t)(leadoffData >> 7) & 0x1F;

        u32result =  ((uint32_t)(databuf[3] << 16) & 0x00FF0000);
        u32result += ((uint32_t)(databuf[4] << 8 ) & 0x0000FF00);
        u32result += ((uint32_t)(databuf[5]      ) & 0x000000FF);

//        u32_CH2 =  ((uint32_t)(databuf[6] << 16) & 0x00FF0000);		// for EEG log display
//        u32_CH2 += ((uint32_t)(databuf[7] << 8 ) & 0x0000FF00);
//        u32_CH2 += ((uint32_t)(databuf[8]      ) & 0x000000FF);

        s32result = (int32_t)(u32result);
        if(u32result > 0x7FFFFF)
        {
            s32result = (int32_t)(u32result | 0xFF000000);
        }

        s32result_ori = s32result;		// for EEG log display

        *result = IIR_filter((float)s32result);
        result_IIR = *result;		// for EEG log display
        
        *result = Nocth_filter(*result);
        result_Nocth = *result;		// for EEG log display

        DBGERR(EXP, "%x, %x, %d, %f, %f\r\n", *isContact, s32result_ori, s32result_ori, result_IIR, result_Nocth);		// for EEG log display

        #ifdef FFT_EEG_ON
        //normalized value of EEG (<1) for FFT calculation
#if(0)        
		//result= result/8388607;
		*result= *result/(float)65535.0;
#else
        *result= *result/(float)8388607.0;
#endif
        #endif
        
		ret = HAL_OK;
    }
    
#ifndef EEG_HARD_NSS
    HAL_GPIO_WritePin(EEG_CS, GPIO_PIN_SET); // set EEG_CS to High
#endif

    return ret;
}

/*===============================================================================================*/
