#ifndef _ADS1292_H_
#define _ADS1292_H_
/*===============================================================================================*/
/**
 *   @file ads1292.h
 *
 *   @version v1.0
 */
/*=================================================================================================


Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------


===================================================================================================*/

/* Standard includes. */

/* Scheduler include files. */
#include "FreeRTOS.h"
#include "stm32f4xx_hal.h"

/* Application include files. */
#include "target.h"
#include "spi.h"


/*=================================================================================================
 CONSTANTS
=================================================================================================*/

#define EEG_WAKE_UP_OPC		    0x02
#define EEG_STAMDBY_OPC		    0x04
#define EEG_RESET_OPC		    0x06
#define EEG_START_OPC		    0x08
#define EEG_STOP_OPC		    0x0A

// Data read commands for EEG AFE(ADS1299)
#define EEG_RDATAC_OPC		    0x10
#define EEG_SDATAC_OPC		    0x11
#define EEG_RDATA_OPC		    0x12

// Internal register read commands for EEG AFE(ADS1299)
#define EEG_RREG_BASE_OPC	    0x20
#define EEG_WREG_BASE_OPC	    0x40
    
#define EEG_WREG_ID				0x00
#define EEG_WREG_CONFIG1		0x01
#define EEG_WREG_CONFIG2		0x02
    
#define EEG_WREG_LOFF			0x03
#define EEG_WREG_CH1SET			0x04
#define EEG_WREG_CH2SET			0x05
    
#define EEG_RLD_SENS			0x06
#define EEG_LOFF_SENS			0x07
#define EEG_LOFF_STAT			0x08
    
#define EEG_RESP1				0x09
#define EEG_RESP2				0x0A

/*=================================================================================================
 FUNCTION PROTOTYPES
=================================================================================================*/
int EEG_Init(void);
HAL_StatusTypeDef EEG_Read_9Byte(float * result, uint8_t *Devcontact);

/*===============================================================================================*/
#endif  /* _ADS1292_H_ */
