#ifndef LIS2DH_H_
#define LIS2DH_H_
/*===============================================================================================*/
/**
 *   @file lis2dh.h
 *
 *   @version v1.0
 */
/*=================================================================================================


Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------


===================================================================================================*/
/* Standard includes. */

/* Scheduler include files. */

/* Application include files. */

/*=================================================================================================
 CONSTANTS
=================================================================================================*/

#define AxisX	1
#define AxisY	2
#define AxisZ	3

extern int16_t CalcedXValue;
extern int16_t CalcedYValue;
extern int16_t CalcedZValue;

/*=================================================================================================
 FUNCTION PROTOTYPES
=================================================================================================*/
void LIS2DH_Init(void);
void LIS2DH_READ(void);
void GetAcceVal(int8_t *x,int8_t *y,int8_t *z);
void GetAcceVal16(uint16_t *x,uint16_t *y,uint16_t *z);
void GetCalcedVal(int16_t *x,int16_t *y,int16_t *z);


/*===============================================================================================*/
#endif  /* LIS2DH_H_ */
