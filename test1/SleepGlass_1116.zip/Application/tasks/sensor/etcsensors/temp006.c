/*===============================================================================================*/
/**
 *   @file temp006.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.

===================================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */
#include "math.h"

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "comdef.h"
#include "signals.h"
#include "command.h"
#include "temp006.h"
#include "temp006_reg.h"

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/
#define TEMP006_TIMEOUT 200

/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/
uint8_t readed_temperature;

/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/
uint16_t TMP006_ReadRegister(uint8_t register_addr)
{  
    HAL_StatusTypeDef result;
    uint8_t data[2];

    data[0] = (uint8_t)register_addr;

    result = HAL_I2C_Master_Transmit(&hi2c1, TMP006_ADDRESS, data, 1, TEMP006_TIMEOUT);
    if(result == HAL_OK)
    {
       result = HAL_I2C_Master_Receive(&hi2c1, TMP006_ADDRESS, data, 2, TEMP006_TIMEOUT);
    }

    if(result == HAL_OK)
    {
        return (uint16_t)((data[0] << 8) | data[1]);
    }
    else
    {
        return 0;
    }
}

HAL_StatusTypeDef TMP006_WriteRegister(uint8_t register_addr, uint16_t value)
{
    uint8_t data[3];

    data[0] = (uint8_t)register_addr;
    data[1] = (uint8_t)(value >> 8);
    data[2] = (uint8_t)(value & 0xFF);

    return HAL_I2C_Master_Transmit(&hi2c1, TMP006_ADDRESS, data, 3, TEMP006_TIMEOUT);
}

void TMP006_Sleep(void)
{
	// Read the control register and update it so bits 12-14 are zero to enter sleep mode.
	uint16_t control = TMP006_ReadRegister(TMP006_CONFIG);
	control &= ~(TMP006_CFG_MODEON);
	TMP006_WriteRegister(TMP006_CONFIG, control);
}

void TMP006_Wake(void)
{
	// Read the control register and update it so bits 12-14 are one to enter full operation.
	uint16_t control = TMP006_ReadRegister(TMP006_CONFIG);
	control |= TMP006_CFG_MODEON;
	TMP006_WriteRegister(TMP006_CONFIG, control);
}

int16_t TMP006_ReadRawDieTemperature(void)
{
	int16_t raw = TMP006_ReadRegister(TMP006_TAMB);

#if TMP006_DEBUG == 1

	TM_USART_Puts(USART1,"Raw Tambient: 0x");
	TM_USART_Puts(USART1,raw);


	float v = raw/4;
	v *= 0.03125;
	TM_USART_Puts(USART1," (");TM_USART_Puts(USART1,v); TM_USART_Puts(USART1," *C)");
#endif
	raw >>= 2;
	return raw;
}

double TMP006_ReadDieTempC(void)
{
	double Tdie = TMP006_ReadRawDieTemperature();
	Tdie *= 0.03125; // convert to celsius
#ifdef TMP006_DEBUG
	TM_USART_Puts(USART1,"Tdie = "); TM_USART_Puts(USART1,Tdie); TM_USART_Puts(USART1," C");
#endif
   return Tdie;
}

int16_t TMP006_ReadRawVoltage(void) {
	int16_t raw;
	raw = TMP006_ReadRegister(TMP006_VOBJ);

#if TMP006_DEBUG == 1

#ifdef TESTVOLT
	raw = TESTVOLT;
#endif

	TM_USART_Puts(USART1,"Raw voltage: 0x"); TM_USART_Puts(USART1,raw);
	float v = raw;
	v *= 156.25;
	v /= 1000;
	TM_USART_Puts(USART1," ("); TM_USART_Puts(USART1,v); TM_USART_Puts(USART1," uV)");
#endif
	return raw;
}

/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/
double TMP006_ReadObjTempC(void) 
{
	double Tdie = TMP006_ReadRawDieTemperature();
	double Vobj = TMP006_ReadRawVoltage();
	Vobj *= 156.25;  // 156.25 nV per LSB
	Vobj /= 1000; // nV -> uV
	Vobj /= 1000; // uV -> mV
	Vobj /= 1000; // mV -> V
	Tdie *= 0.03125; // convert to celsius
	Tdie += 273.15; // convert to kelvin

#ifdef TMP006_DEBUG
	TM_USART_Puts(USART1,"Vobj = "); TM_USART_Puts(USART1,Vobj * 1000000); TM_USART_Puts(USART1,"uV");
	STM_USART_Puts(USART1,"Tdie = "); TM_USART_Puts(USART1,Tdie); TM_USART_Puts(USART1," C");
#endif

	double tdie_tref = Tdie - TMP006_TREF;

	double S = (1 + TMP006_A1*tdie_tref +TMP006_A2*tdie_tref*tdie_tref);
	S *= TMP006_S0;
	S /= 10000000;
	S /= 10000000;

	double Vos = TMP006_B0 + TMP006_B1*tdie_tref + TMP006_B2*tdie_tref*tdie_tref;

	double fVobj = (Vobj - Vos) + TMP006_C2*(Vobj-Vos)*(Vobj-Vos);

	double Tobj = sqrt(sqrt(Tdie * Tdie * Tdie * Tdie + fVobj/S));

	Tobj -= 273.15; // Kelvin -> *C
	readed_temperature = (uint8_t)Tobj;
    
	return Tobj;
}

uint8_t GetTempC(void)
{
	return readed_temperature;
}

/*===============================================================================================*/
