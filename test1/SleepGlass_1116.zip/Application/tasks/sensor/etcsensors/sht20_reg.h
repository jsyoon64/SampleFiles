#ifndef _SHT20_REG_H_
#define _SHT20_REG_H_
/*===============================================================================================*/
/**
 *   @file sht20_reg.h
 *
 *   @version v1.0
 */
/*=================================================================================================


Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------


===================================================================================================*/
/* Standard includes. */

/* Scheduler include files. */

/* Application include files. */

/*=================================================================================================
 CONSTANTS
=================================================================================================*/
#define SHT20_ADDRESS 		 0x80

#if 0
#define SHT20_HOLD_T_MEAS    0xE3
#define SHT20_HOLD_RH_MEAS   0xE5

#define SHT20_NOHOLD_T_MEAS  0xF3
#define SHT20_NOHOLD_RH_MEAS 0xF5

#define SHT20_WRITE_USER_REG 0xE6
#define SHT20_READ_USER_REG  0xE7

#define SHT20_SOFT_RESET_REG 0xFE
#else
// sensor command
typedef enum{

	TRIG_T_MEASUREMENT_HM     = 0xE3, //command trig. temp meas. hold master
	TRIG_RH_MEASUREMENT_HM    = 0xE5, //command trig. humidity meas. hold master
	TRIG_T_MEASUREMENT_POLL   = 0xF3, //command trig. temp meas. no hold master
	TRIG_RH_MEASUREMENT_POLL  = 0xF5, //command trig. humidity meas. no hold master
	USER_REG_W                = 0xE6, //command writing user regiser
	USER_REG_R                = 0xE7, //command reading user regiser
	SOFT_RESET                = 0xFE  //command soft reset
	
}etSHT2xCommand; 
#endif
/*===============================================================================================*/
#endif  /* _SHT20_REG_H_ */
