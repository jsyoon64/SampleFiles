#ifndef _SHT20_H_
#define _SHT20_H_
/*===============================================================================================*/
/**
 *   @file sht20.h
 *
 *   @version v1.0
 */
/*=================================================================================================


Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------


===================================================================================================*/
/* Standard includes. */

/* Scheduler include files. */

/* Application include files. */
#include "target.h"
#include "i2c.h"
#include "comdef.h"
#include "command.h"
#include "stm32f4xx_hal.h"

/*=================================================================================================
 CONSTANTS
=================================================================================================*/
typedef enum {
    ACK_ERR         = 0x01,
    TIME_OUT_ERR    = 0x02,
    CHECKSUM_ERR    = 0x04,
    UNIT_ERR        = 0x08
}eError;

typedef enum{

	SHT2x_RES_12_14BIT        = 0x00, //RH=12bit, T=14bit
	SHT2x_RES_8_12BIT         = 0x01, //RH= 8bit, T=12bit
	SHT2x_RES_10_13BIT        = 0x80, //RH=10bit, T=13bit
	SHT2x_RES_11_11BIT        = 0x81, //RH=11bit, T=11bit
	SHT2x_RES_MASK            = 0x81  //mask for res. bits (7,0) in user reg.
	
} etSHT2xResolution;

typedef enum{

	SHT2x_EOB_ON              = 0x40, // end of battery
	SHT2x_EOB_MASK            = 0x40, // Mask for EOB bit(6) in user reg.
	
} etSHT2xEob;

typedef enum{

	SHT2x_HEATER_ON           = 0x04, //heater on
	SHT2x_HEATER_OFF          = 0x00, //heater off
	SHT2x_HEATER_MASK         = 0x04  //Mask for Heater bit(2) in user reg.
	
} etSHT2xHeater;

//measuerment signal selection
typedef enum{

	HUMIDITY,
	TEMP
	
}etSHT2xMeasureType;


/*=================================================================================================
FUNCTION PROTOTYPES
=================================================================================================*/
void SHT20_config(void);
HAL_StatusTypeDef SHT2x_MeasurePoll(void);
HAL_StatusTypeDef SHT2x_ReadData(uint8_t *tempC);
uint8_t GetTempC(void);
float GetTempCfloat(void);

#endif  /* _SHT20_H_ */
