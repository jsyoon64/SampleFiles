/*===============================================================================================*/
/**
 *   @file adc_operation.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.

===================================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "signals.h"
#include "command.h"
#include "adc.h"
#include "adc_operation.h"
#include "comdef.h"
#include "stdlib.h"
#include "debugmsgcli.h"
#include "gpio.h"
#include "ringbuf.h"


/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/


/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/
/*
    PA1     CHAN1   Light sensor
    PB1     CHAN9   MIC Out
    PC0     CHAN10  Battery
    PC2     CHAN12  Charge status
    PC3     CHAN13  Battery Temp
    PC5     CHAN15  EDA
*/

/* PA1     CHAN1   Light sensor */
uint8_t     LightSensor;

/* PB1     CHAN9   MIC Out */
//uint8_t     MicAver=0;
uint8_t     MicPeak=0;

//HW_VERNO == 0  ADCMaxValue

uint8_t		MicADCMaxValue = 170;

/* PC0     CHAN10  Battery */
uint8_t     BatteryStatus;

/* PC2     CHAN12  Charging Status*/
uint8_t     ChargingStatus;

/* PC3     CHAN13  Battery Temp*/
uint8_t     BatteryTemp;

/* PC5     CHAN15  EDA */
uint8_t     EDA_Value;

/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/
boolean     isMicadc_loop_start = FALSE;

ringbuf_t   micRB;

/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/
void adcStartAdc(uint32_t channel)
{
    ADC_ChannelConfTypeDef sConfig;

    /*##-2- Configure ADC regular channel ######################################*/
    sConfig.Channel = channel;
    sConfig.Rank = 1;
    sConfig.SamplingTime = ADC_SAMPLETIME_3CYCLES;    /* Sampling time (number of clock cycles unit) */
    sConfig.Offset = 0;                               /* Parameter discarded because offset correction is disabled */

    if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
    {
      /* Channel Configuration Error */
      //Error_Handler();
    }

    /*##-3- Start the conversion process #######################################*/
    
    #if defined (ADC_USE_POLLING_METHOD)
        HAL_ADC_Start(&hadc1);
    #elif defined (ADC_USE_IT_METHOD)
        HAL_ADC_Start_IT(&hadc1);
    #endif

#if(0)
 /*##-4- Wait for the end of conversion #####################################*/
  /*  Before starting a new conversion, you need to check the current state of
       the peripheral; if it�s busy you need to wait for the end of current
       conversion before starting a new one.
       For simplicity reasons, this example is just waiting till the end of the
       conversion, but application may perform other tasks while conversion
       operation is ongoing. */
  if (HAL_ADC_PollForConversion(&AdcHandle, 10) != HAL_OK)
  {
    /* End Of Conversion flag not set on time */
    Error_Handler();
  }

/* Check if the continuous conversion of regular channel is finished */
  if ((HAL_ADC_GetState(&AdcHandle) & HAL_ADC_STATE_EOC_REG) == HAL_ADC_STATE_EOC_REG)
  {
    /*##-5- Get the converted value of regular channel  ########################*/
    uhADCxConvertedValue = HAL_ADC_GetValue(&AdcHandle);
  }
#endif
    
}

boolean ReadAdcResult(uint16_t *data)
{
    #if defined (ADC_USE_POLLING_METHOD)
        /*##-4- Wait for the end of conversion #####################################*/
        if (HAL_ADC_PollForConversion(&hadc1, 10) != HAL_OK)
        {
          /* End Of Conversion flag not set on time */
          return FALSE;
        }
    #endif
    
    /* Check if the continuous conversion of regular channel is finished */
    if ((HAL_ADC_GetState(&hadc1) & HAL_ADC_STATE_EOC_REG) == HAL_ADC_STATE_EOC_REG)
    {
      /*##-5- Get the converted value of regular channel  ########################*/
      *data =  HAL_ADC_GetValue(&hadc1);
      return TRUE;
    }
    return FALSE;   
}


#if 0
uint8_t micsensorGetPeakValue(uint16_t data)
{
    uint8_t Bytedata;
    uint16_t TestData;

#if(1)
    TestData = ((data >> 4) & 0xFF);
#else
    if (HW_VERNO == 0)
    {
        TestData = ((data >> 3) & 0x1FF);
    }
    else
    {
        TestData = ((data >> 4) & 0xFF);
        
		if (HW_VERNO == 1)	
            MicADCMaxValue = 170;
		else if (HW_VERNO == 2)	
            MicADCMaxValue = 170;
        else 
            MicADCMaxValue = 170;
        
		TestData = ((data * (MicMaxValue - MicMinValue)) / MicADCMaxValue) + MicMinValue;
	}
    if( TestData > 255)
    {
    	Bytedata = 255;
    }
    else
#endif        
    {
    	Bytedata = (uint8_t)TestData;
	}

    if(MicPeak < Bytedata)
    {
        MicPeak = Bytedata;
    }

    return MicPeak;
}
#endif

/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/

/*===========================================================================
FUNCTION           
DESCRIPTION     
DEPENDENCIES
RETURN VALUE
===========================================================================*/
uint8_t micsensorInitPeakValue(void)
{
    uint8_t PrevVal = MicPeak;
    
    MicPeak = 0;

    return PrevVal;
}

boolean Start_ADC_Operation(uint8_t chan)
{
    boolean     ret = TRUE;
    
    switch(chan)
    {
        case ADC_LIGHT:
            adcStartAdc(ADC_CHANNEL_1);
            break;
            
        case ADC_MIC:
            adcStartAdc(ADC_CHANNEL_9);
            break;

        case ADC_BATT:
            adcStartAdc(ADC_CHANNEL_10);
            break;
            
        case ADC_CHARGE:
            adcStartAdc(ADC_CHANNEL_12);
            break;

        case ADC_BATT_TEMP:
            adcStartAdc(ADC_CHANNEL_13);
            break;
            
        case ADC_EDA:
            adcStartAdc(ADC_CHANNEL_15);
            break;

        default:
            ret = FALSE;
            break;
    }

    return ret;
}


boolean Read_ADC_value(uint8_t chan)
{
    boolean     ret = TRUE;
    uint16_t    adc_val;
    static uint16_t micAdcReadCount=0;
    static uint8_t micADC_Max_Value;
    
        
    switch(chan)
    {
        case ADC_LIGHT:
            if( ReadAdcResult(&adc_val) == TRUE)
            {
                LightSensor = (adc_val >> 4) & 0xFF;
                DBGMED(SEN,"Light ADC %d LightSensor=%d\r\n",adc_val,LightSensor);
                DBGTEST(1,"Light ADC:%d\r\n",LightSensor);
            }
            break;
            
        case ADC_MIC:

            if(isMicadc_loop_start == TRUE)
            {
                micAdcReadCount = 0;
                micADC_Max_Value = 0;
                isMicadc_loop_start = FALSE;
            }

            micAdcReadCount++;
            
            if( ReadAdcResult(&adc_val) == TRUE)
            {
                //uint8_t peak_val = micsensorGetPeakValue(adc_val);
                //uint8_t badc_val = (adc_val >> 4) & 0xFF;

                uint8_t badc_val;

                if( adc_val < 0xFF) 
                    badc_val = adc_val;
                else 
                    badc_val = 0xFF;

                if(micADC_Max_Value < badc_val)
                {
                    micADC_Max_Value = badc_val;
                }
                DBGTEST(6,"Mic bADC:%d, MaxPeak Value:%d\r\n",badc_val,micADC_Max_Value);
            }

            if(micAdcReadCount >= MICADC_LOOP_MAX_COUNT)
            {
                DBGMED(SEN,"Mic ADC %d\r\n",micADC_Max_Value);
                //MicPeak = micADC_Max_Value;
                MicPeak=ringbuf_add_getMax(micRB,micADC_Max_Value);
                
                DBGTEST(1,"MicPeak=%d, Mic ADC:%d\r\n",MicPeak,micADC_Max_Value);
                DBGTEST(6,"MicPeak=%d, Peak Value=%d\r\n",MicPeak,micADC_Max_Value);
            }
            break;

        case ADC_BATT:
            if( ReadAdcResult(&adc_val) == TRUE)
            {
                BatteryStatus = (adc_val >> 4) & 0xFF;
                DBGMED(SEN,"Batt ADC %d BatteryStatus=%d\r\n",adc_val,BatteryStatus);
                DBGTEST(1,"BATT ADC:%d\r\n",BatteryStatus);
            }
            break;
            
        case ADC_CHARGE:
            if( ReadAdcResult(&adc_val) == TRUE)
            {
                ChargingStatus = (adc_val >> 4) & 0xFF;
                DBGMED(SEN,"Charge ADC %d ChargingStatus=%d\r\n",adc_val,ChargingStatus);
                DBGTEST(1,"Charge ADC:%d\r\n",ChargingStatus);
            }
            break;

        case ADC_BATT_TEMP:
            if( ReadAdcResult(&adc_val) == TRUE)
            {
                BatteryTemp = (adc_val >> 4) & 0xFF;                
                DBGMED(SEN,"Batt Temp ADC %d BatteryTemp=%d\r\n",adc_val,BatteryTemp);
                DBGTEST(1,"BATT TEMP ADC:%d\r\n",BatteryTemp);
            }
            break;
            
        case ADC_EDA:
            if( ReadAdcResult(&adc_val) == TRUE)
            {
                EDA_Value = (adc_val >> 4) & 0xFF;                
                DBGMED(SEN,"EDA ADC %d EDA_Value=%d\r\n",adc_val,EDA_Value);
                DBGTEST(1,"EDA ADC:%d\r\n",EDA_Value);
            }
            break;

        default:
            ret = FALSE;
            break;
    }

    return ret;
}


void InitMicRingbuf()
{
  if(micRB == NULL)
  {
    micRB = ringbuf_new(MAX_MICRINGBUF); 
  }
  else
  {
    ringbuf_reset(micRB);
  }
}

/*===============================================================================================*/
