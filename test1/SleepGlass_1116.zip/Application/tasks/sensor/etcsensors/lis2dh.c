/*===============================================================================================*/
/**
 *   @file lis2dh.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.
*/

/*===============================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */
#include <stdlib.h>

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "stm32f4xx_hal.h"

/* Application includes. */
#include "target.h"
#include "comdef.h"
#include "signals.h"
#include "command.h"
#include "task_cfg.h"
#include "i2c.h"
#include "lis2dh.h"
#include "lis2dh_reg.h"
#include "debugmsgcli.h"


/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/
#define LIS2DH_TIMEOUT 200


/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/

int8_t AcceXValue;
int8_t AcceYValue;
int8_t AcceZValue;

uint16_t XValue_16;
uint16_t YValue_16;
uint16_t ZValue_16;

int16_t CalcedXValue;
int16_t CalcedYValue;
int16_t CalcedZValue;


/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/
uint8_t LIS2DH_ReadRegister(const uint8_t register_addr)
{
    HAL_StatusTypeDef result;
    uint8_t data = register_addr;

    result = HAL_I2C_Master_Transmit(&hi2c1, LIS2DH_I_AM_MASK, &data, 1, LIS2DH_TIMEOUT);
    if(result == HAL_OK)
    {
       result = HAL_I2C_Master_Receive(&hi2c1, LIS2DH_I_AM_MASK, &data, 1, LIS2DH_TIMEOUT);
    }
    
    if(result == HAL_OK)
    {
        return data;
    }
    else
    {
        return 0;
    }
}


HAL_StatusTypeDef LIS2DH_WriteRegister(const uint8_t register_addr, const uint8_t value) 
{
    uint8_t data[3];
    
    data[0] = (uint8_t)register_addr;
    data[1] = (uint8_t)(value );
    
    return HAL_I2C_Master_Transmit(&hi2c1, LIS2DH_I_AM_MASK, data, 2, LIS2DH_TIMEOUT);
}

boolean LIS2DH_WriteRegisters(const uint8_t msb_register, const uint8_t msb_value, const uint8_t lsb_register, const uint8_t lsb_value)
{
	uint8_t msb_bool, lsb_bool;
	msb_bool = LIS2DH_WriteRegister(msb_register, msb_value);
	lsb_bool = LIS2DH_WriteRegister(lsb_register, lsb_value);
	return msb_bool | lsb_bool;
}

boolean LIS2DH_WriteMaskedRegister(const uint8_t register_addr, const uint8_t mask, const boolean value)
{
	uint8_t data = LIS2DH_ReadRegister(register_addr);
	uint8_t combo;
	if(value) {
		combo = (mask | data);
	} else {
		combo = ((~mask) & data);
	}
	return LIS2DH_WriteRegister(register_addr, combo);
}

boolean LIS2DH_WriteMaskedRegister_N(const int register_addr, const int mask, const int value)
{
	uint8_t data;
	uint8_t masked_value;
	data = LIS2DH_ReadRegister(register_addr);
	masked_value = (~mask & data  )|value; //Not sure if right...
	return LIS2DH_WriteRegister(register_addr, masked_value);
}

uint16_t LIS2DH_ReadRegisters(const uint8_t msb_register, const uint8_t lsb_register)
{
	uint8_t msb = LIS2DH_ReadRegister(msb_register);
	uint8_t lsb = LIS2DH_ReadRegister(lsb_register);
	return (((int16_t)msb) << 8) | lsb;
}

uint8_t LIS2DH_ReadMaskedRegister(const uint8_t register_addr, const uint8_t mask)
{
	uint8_t data = LIS2DH_ReadRegister(register_addr);
	return (data & mask);
}

/** Read the X axis registers
 * @see LIS2DH_OUT_X_H
 * @see LIS2DH_OUT_X_L
 */
int16_t LIS2DH_GetAxisX(void) {
	return LIS2DH_ReadRegisters(LIS2DH_OUT_X_H, LIS2DH_OUT_X_L);
}

/** Read the Y axis registers
 * @see LIS2DH_OUT_Y_H
 * @see LIS2DH_OUT_Y_L
 */
int16_t LIS2DH_GetAxisY(void) {
	return LIS2DH_ReadRegisters(LIS2DH_OUT_Y_H, LIS2DH_OUT_Y_L);
}

/** Read the Z axis registers
 * @see LIS2DH_OUT_Z_H
 * @see LIS2DH_OUT_Z_L
 */
int16_t LIS2DH_GetAxisZ(void) {
	return LIS2DH_ReadRegisters(LIS2DH_OUT_Z_H, LIS2DH_OUT_Z_L);
}

/** Read the all axis registers
 * @see getAxisZ()
 * @see getAxisY()
 * @see getAxisZ()
 */
void LIS2DH_GetMotion(int16_t* ax, int16_t* ay, int16_t* az) {
    *ax = LIS2DH_GetAxisX();
    *ay = LIS2DH_GetAxisY();
    *az = LIS2DH_GetAxisZ();
}

boolean LIS2DH_WhoAmI(void) {
    return (LIS2DH_I_AM_MASK == LIS2DH_ReadRegister(LIS2DH_WHO_AM_I));
}

uint8_t LIS2DH_GetDataRate(void) {
    return LIS2DH_ReadMaskedRegister(LIS2DH_CTRL_REG1, LIS2DH_ODR_MASK);
}

boolean LIS2DH_SetDataRate(uint8_t rate) {
    if(rate > 9) {
        return 0;
    }
    uint8_t data_rate = rate << 4;
    return LIS2DH_WriteMaskedRegister_N(LIS2DH_CTRL_REG1, LIS2DH_ODR_MASK, data_rate);
}

boolean LIS2DH_EnableAxisX(void) {
    return LIS2DH_WriteMaskedRegister(LIS2DH_CTRL_REG1, LIS2DH_X_EN_MASK, TRUE);
}

boolean LIS2DH_DisableAxisX(void) {
    return LIS2DH_WriteMaskedRegister(LIS2DH_CTRL_REG1, LIS2DH_X_EN_MASK, FALSE);
}

boolean LIS2DH_IsXAxisEnabled(void) {
    return (LIS2DH_ReadMaskedRegister(LIS2DH_CTRL_REG1, LIS2DH_X_EN_MASK) != 0);
}

boolean LIS2DH_EnableAxisY(void) {
    return LIS2DH_WriteMaskedRegister(LIS2DH_CTRL_REG1, LIS2DH_Y_EN_MASK, TRUE);
}

boolean LIS2DH_DisableAxisY(void) {
    return LIS2DH_WriteMaskedRegister(LIS2DH_CTRL_REG1, LIS2DH_Y_EN_MASK, FALSE);
}

boolean LIS2DH_IsYAxisEnabled(void) {
    return (LIS2DH_ReadMaskedRegister(LIS2DH_CTRL_REG1, LIS2DH_Y_EN_MASK) != 0);
}

boolean LIS2DH_EnableAxisZ(void) {
    return LIS2DH_WriteMaskedRegister(LIS2DH_CTRL_REG1, LIS2DH_Z_EN_MASK, TRUE);
}

boolean LIS2DH_DisableAxisZ(void) {
    return LIS2DH_WriteMaskedRegister(LIS2DH_CTRL_REG1, LIS2DH_Z_EN_MASK, FALSE);
}

boolean LIS2DH_IsZAxisEnabled(void) {
    return (LIS2DH_ReadMaskedRegister(LIS2DH_CTRL_REG1, LIS2DH_Z_EN_MASK) != 0);
}

boolean LIS2DH_EnableAxisXYZ(void) {
    return LIS2DH_WriteMaskedRegister(LIS2DH_CTRL_REG1, LIS2DH_XYZ_EN_MASK, TRUE);
}

boolean LIS2DH_DisableAxisXYZ(void) {
    return LIS2DH_WriteMaskedRegister(LIS2DH_CTRL_REG1, LIS2DH_XYZ_EN_MASK, FALSE);
}

boolean LIS2DH_DisableLowPower(void) {
    return LIS2DH_WriteMaskedRegister(LIS2DH_CTRL_REG1, LIS2DH_LPEN_MASK, FALSE);
}

boolean LIS2DH_EnableLowPower(void) {
    return LIS2DH_WriteMaskedRegister(LIS2DH_CTRL_REG1, LIS2DH_LPEN_MASK, TRUE);
}

/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/

/*===========================================================================
FUNCTION           
DESCRIPTION     
DEPENDENCIES
RETURN VALUE
===========================================================================*/

void LIS2DH_Init(void)
{
	LIS2DH_EnableLowPower();
    LIS2DH_WriteMaskedRegister(LIS2DH_CTRL_REG1,LIS2DH_HR_MASK,0);
	LIS2DH_EnableAxisXYZ();
	LIS2DH_SetDataRate(4);
}

#define ACCUPPERLIMIT   65
#define ACCLOWERLIMIT   (-65)
#define ACC_VAL_LIMIT   180

#define ACCUPPERLIMITZ  65
#define ACCLOWERLIMITZ  (-65)

int8_t check_limit(int8_t val)
{
    int8_t ret_val = val;
    
    if( val > ACCUPPERLIMIT ) 
        ret_val = ACCUPPERLIMIT;
    else if( val < ACCLOWERLIMIT ) 
        ret_val = ACCLOWERLIMIT;

    return ret_val;
}

int16_t checkOver180limit(int16_t val)
{
    int16_t ret_val = val;
    
    if( val > ACC_VAL_LIMIT ) 
        ret_val = val-360;
    return ret_val;
}

void LIS2DH_READ(void)
{
    uint16_t temp;
    float test_val,square_val;
    int8_t temp_limit_val;
    
    temp = LIS2DH_GetAxisX();   //read data X-asix Acce
    
    XValue_16 = temp;
    AcceXValue = (int8_t)(temp>>8);
    
    temp = LIS2DH_GetAxisY();   //read data Y-asix Acce
    YValue_16 = temp;
    AcceYValue = (int8_t)(temp>>8);
    
    temp = LIS2DH_GetAxisZ();   //read data Z-asix Acce
    ZValue_16 = temp;
    AcceZValue = (int8_t)(temp>>8);

    temp_limit_val = check_limit(AcceXValue);
    test_val = (float)(temp_limit_val*((float)90.0/(float)(ACCUPPERLIMIT*1.0)));
    if(AcceZValue > 0) {
        test_val = 180.0 - test_val;
    }
    CalcedXValue = (int16_t)(test_val*1.0);
    CalcedXValue = checkOver180limit(CalcedXValue);
    //DBGERR(SEN,"X: test(%f), orig(%d),Calced(%d)\r\n",test_val,AcceXValue,CalcedXValue);

    temp_limit_val = check_limit(AcceYValue);
    test_val = (float)(temp_limit_val*((float)90.0/(float)(ACCUPPERLIMIT*1.0)));
    if(AcceZValue > 0) {
        test_val = 180.0 - test_val;
    }
    CalcedYValue = (int16_t)(test_val*1.0);
    CalcedYValue = checkOver180limit(CalcedYValue);
    //DBGERR(SEN,"Y: test(%f), orig(%d),Calced(%d)\r\n",test_val,AcceYValue,CalcedYValue);

    //temp_limit_val = check_limit(AcceZValue);

    temp_limit_val = AcceZValue;
    if( AcceZValue > ACCUPPERLIMITZ )       temp_limit_val = ACCUPPERLIMITZ;
    else if( AcceZValue < ACCLOWERLIMITZ )  temp_limit_val = ACCLOWERLIMITZ;

    square_val = (float)temp_limit_val/(float)(ACCUPPERLIMITZ*1.0);
    square_val = square_val * square_val * square_val;
    if(square_val < 0) square_val = square_val* (-1.0);

    if(AcceZValue < 0)  test_val = (float)(90 - square_val*90.0);
    else                test_val = (float)(90 + square_val*90.0); 
    
    CalcedZValue = (int16_t)(test_val*1.0);

    //DBGERR(SEN,"Z: test(%f), orig(%d),Calced(%d)\r\n",test_val,AcceZValue,CalcedZValue);

    
}

void GetAcceVal(int8_t *x,int8_t *y,int8_t *z)
{
    *x=AcceXValue;
    *y=AcceYValue;
    *z=AcceZValue;
}

void GetAcceVal16(uint16_t *x,uint16_t *y,uint16_t *z)
{
    *x=XValue_16;
    *y=YValue_16;
    *z=ZValue_16;
}

void GetCalcedVal(int16_t *x,int16_t *y,int16_t *z)
{
    *x=CalcedXValue;
    *y=CalcedYValue;
    *z=CalcedZValue;
}

/*===============================================================================================*/
