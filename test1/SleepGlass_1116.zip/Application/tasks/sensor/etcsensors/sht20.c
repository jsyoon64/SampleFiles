/*===============================================================================================*/
/**
 *   @file sht20.c
 *
 *   @version v1.0
 */
/*=================================================================================================

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:
Indicate if this module is portable to other compilers or
platforms. If not, indicate specific reasons why is it not portable.

===================================================================================================
 INCLUDE FILES
=================================================================================================*/

/* Standard includes. */
#include "math.h"

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"

/* Application includes. */
#include "target.h"
#include "comdef.h"
#include "signals.h"
#include "command.h"
#include "sht20.h"
#include "sht20_reg.h"

/*=================================================================================================
 LOCAL FUNCTION PROTOTYPES
==================================================================================================*/


/*==================================================================================================
 LOCAL CONSTANTS
==================================================================================================*/
#define TEMPSENSOR_TIMEOUT 200
const uint16_t SHT20POLYNOMIAL = 0x131;

/*==================================================================================================
 LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
==================================================================================================*/


/*==================================================================================================
 LOCAL MACROS
==================================================================================================*/


/*==================================================================================================
 LOCAL VARIABLES
==================================================================================================*/
uint8_t readed_temperature;
float float_temp;

/*==================================================================================================
 GLOBAL VARIABLES
==================================================================================================*/


/*==================================================================================================
 LOCAL FUNCTIONS
==================================================================================================*/
HAL_StatusTypeDef I2c_WriteByte(uint8_t val)
{
    uint8_t command;

    command = val;
    return HAL_I2C_Master_Transmit(&hi2c1, SHT20_ADDRESS, &command, 1, TEMPSENSOR_TIMEOUT);
}


HAL_StatusTypeDef SHT2x_SoftReset()
{
    uint8_t command;

    command = SOFT_RESET;
    return HAL_I2C_Master_Transmit(&hi2c1, SHT20_ADDRESS, &command, 1, TEMPSENSOR_TIMEOUT);
}


//=========================================================
HAL_StatusTypeDef SHT2x_ReadUserRegister(uint8_t *pRegisterValue)
//=========================================================
{
	uint8_t error=0; // error variable
	uint8_t checksum; // variable for checksum byte
	uint8_t read_data[2];
    HAL_StatusTypeDef result;
    
	I2c_WriteByte (USER_REG_R);
    result = HAL_I2C_Master_Receive(&hi2c1, SHT20_ADDRESS, read_data, 2, TEMPSENSOR_TIMEOUT);
	*pRegisterValue = read_data[0];
	checksum=read_data[1];
	//error=SHT2x_CheckCrc (pRegisterValue,1,checksum);
	//return error; // if wrong return 0x04
	(void)checksum;
	(void)error;
	return result;
}

//===========================================================
HAL_StatusTypeDef SHT2x_WriteUserRegister(uint8_t *pRegisterValue)
//===========================================================
{
	uint8_t data[2];

    data[0] = USER_REG_W;
    data[1] = *pRegisterValue;
    
	return HAL_I2C_Master_Transmit(&hi2c1, SHT20_ADDRESS, data, 2, TEMPSENSOR_TIMEOUT);
	
}

//==============================================================
float SHT2x_CalcRh(uint16_t u16sRH)
//==============================================================
{

	float humidityRH; // variable for result
	
	u16sRH &= ~0x0003; //clear bits [1..0] (status bits)
	// -- calculate reative humidity [%RH] --
	
	humidityRH = -6.0 + 125.0 /65536 * (float)u16sRH; //RH = -6 +125 * SRH/2^16
	return humidityRH;
	
}

//===============================================================
float SHT2x_CalcTemperatureC(uint16_t u16sT)
//===============================================================
{

	float temperatureC;  // variable for result
	
	u16sT &= ~0x0003;  //clear bits [1..0] (status bits)
	
	// -- calculate temperature [C] --
	//temperatureC = -46.85 + 175.72/65536 + (float)u16sT; // t = -46.85 + 175.72 * ST2^16
	temperatureC = -4685 + 17592 *u16sT/65536; // t = -46.85 + 175.72 * ST2^16
	temperatureC /= 100;
	return temperatureC;
	
}

#if 0
//===========================================================
u8t SHT2x_MeasurePoll(etSHT2xMeasureType eSHT2xMeasureType, u16t *pMeasurand)
//===========================================================
{

	u8t  checksum; //checksum
	u8t  read_data[3]; //data array for checksum verification
	u16t result;
	u8t  error=0; // error variable
	
	//  -- write I2C sensor address and command --
	switch(eSHT2xMeasureType)
	{
		case HUMIDITY:   I2c_WriteByte (SHT20_ADR,0,TRIG_RH_MEASUREMENT_POLL,0); break;
		case TEMP    :   I2c_WriteByte (SHT20_ADR,0,TRIG_T_MEASUREMENT_POLL,0); break;
		default      :   break;
	}
	
	
	DelayMicroSeconds(25000);
	I2c_ReadArray (SHT20_ADR,read_data, 0, 3,0,0);
	
	// -- read two data bytes and one checksum byte --
	result=read_data[0]& 0x00ff;
	result=result<<8;
	result|=read_data[1]& 0x00ff;
	*pMeasurand=result;
	checksum=read_data[2];
	
	// -- verify checksum --
	error  |= SHT2x_CheckCrc (read_data,2,checksum);
	
	return error;
	
}

//===============================================================
void SHT2x_GetSerialNumber(u8t u8SerialNumber[])
//===============================================================
{


	I2c_WriteByte (SHT20_ADR,0xFA,0x0F,1); //I2C address   command for readout on-chip memory  on-chip memory address
	I2c_ReadArray (SHT20_ADR,u8SerialNumber, 0 ,5,0,0);
	
	//Read from memory location 2
	I2c_WriteByte (SHT20_ADR,0xFc,0xc9,1);  //I2C address   command for readout on-chip memory  on-chip memory address
	
	I2c_ReadArray (SHT20_ADR,u8SerialNumber+5, 0, 5,0,0 );
	
	
}

#endif

/*==================================================================================================
 GLOBAL FUNCTIONS
==================================================================================================*/

void SHT20_config(void)
{
	uint8_t   userRegister;
    
	SHT2x_SoftReset();
    vTaskDelay(25);
    
	SHT2x_ReadUserRegister(&userRegister);  //get actual user reg
	userRegister = (userRegister & ~SHT2x_RES_MASK) | SHT2x_RES_11_11BIT;
	SHT2x_WriteUserRegister(&userRegister); //write changed user reg
}


HAL_StatusTypeDef SHT2x_MeasurePoll(void)
{
    uint8_t command;

    command = TRIG_T_MEASUREMENT_HM;//TRIG_T_MEASUREMENT_POLL;

#if defined (IIC_USE_WAIT_TIMER)
    return HAL_I2C_Master_Transmit(&hi2c1, SHT20_ADDRESS, &command, 1, TEMPSENSOR_TIMEOUT);
#else
    uint8_t tempD;

    HAL_I2C_Master_Transmit(&hi2c1, SHT20_ADDRESS, &command, 1, TEMPSENSOR_TIMEOUT);
    vTaskDelay(50);
    return SHT2x_ReadData(&tempD);
#endif
}

HAL_StatusTypeDef SHT2x_ReadData(uint8_t *tempC)
{
    HAL_StatusTypeDef result;
    uint8_t     data[3];
    uint16_t    rawTemp;

    result = HAL_I2C_Master_Receive(&hi2c1, SHT20_ADDRESS, data, 3, TEMPSENSOR_TIMEOUT);

  	rawTemp = data[0]& 0x00ff;
	rawTemp = rawTemp<<8;
	rawTemp |= data[1]& 0x00ff;

    float_temp = SHT2x_CalcTemperatureC(rawTemp);

    *tempC = (uint8_t)float_temp;
    readed_temperature = *tempC;
    
    return result;
}


uint8_t GetTempC(void)
{
	return readed_temperature;
}

float GetTempCfloat(void)
{
	return float_temp;
}

/*===============================================================================================*/
