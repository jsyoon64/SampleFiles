#ifndef ADC_OPERATION_H_
#define ADC_OPERATION_H_
/*===============================================================================================*/
/**
 *   @file adc_operation.h
 *
 *   @version v1.0
 */
/*=================================================================================================


Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------


===================================================================================================*/
/* Standard includes. */

/* Scheduler include files. */

/* Application include files. */
#include "ringbuf.h"

/*=================================================================================================
 CONSTANTS
=================================================================================================*/
#define ADC_LIGHT               1
#define ADC_MIC                 2
#define ADC_BATT                3
#define ADC_CHARGE              4
#define ADC_BATT_TEMP           5
#define ADC_EDA                 6

#define MicMaxValue			  255
#define MicMinValue				0


#define MICADC_LOOP_MAX_COUNT   30


extern ringbuf_t micRB;
#define MAX_MICRINGBUF    3

/*
    PA1     CHAN1   Light sensor
    PB1     CHAN9   MIC Out
    PC0     CHAN10  Battery
    PC2     CHAN12  Charge status
    PC3     CHAN13  Battery Temp
    PC5     CHAN15  EDA
*/

/* PA1     CHAN1   Light sensor */
extern uint8_t     LightSensor;

/* PB1     CHAN9   MIC Out */
extern uint8_t     MicPeak;

/* PC0     CHAN10  Battery */
extern uint8_t     BatteryStatus;

/* PC2     CHAN12  Charging Status*/
extern uint8_t     ChargingStatus;

/* PC3     CHAN13  Battery Temp*/
extern uint8_t     BatteryTemp;

/* PC5     CHAN15  EDA */
extern uint8_t     EDA_Value;

extern boolean     isMicadc_loop_start;

/*=================================================================================================
 FUNCTION PROTOTYPES
=================================================================================================*/
boolean Start_ADC_Operation(uint8_t chan);
boolean Read_ADC_value(uint8_t chan);
uint8_t micsensorInitPeakValue(void);
void InitMicRingbuf();


/*===============================================================================================*/
#endif  /* ADC_OPERATION_H_ */
