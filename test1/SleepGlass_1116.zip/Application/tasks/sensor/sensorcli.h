/*
*/

#ifndef SENSORCLI_H
#define SENSORCLI_H

void SensorCLIregister(void);

#endif

