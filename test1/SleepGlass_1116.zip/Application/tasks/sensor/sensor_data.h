#ifndef SENSOR_DATA_H_
#define SENSOR_DATA_H_
/*===============================================================================================*/
/**
 *   @file sensor_data.h
 *
 *   @version v1.0
 */
/*=================================================================================================


Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------


===================================================================================================*/
/* Standard includes. */
#include "target.h"
#include "command.h"

/* Scheduler include files. */

/* Application include files. */
#include "ads1292.h"
#include "afe4400.h"
#include "lis2dh.h"
#include "sht20.h"
#include "interface.h"

/*=================================================================================================
 CONSTANTS
=================================================================================================*/
#define sensorNO_BLOCK			( 0 )

#define MAX_EEG_BUFFER_SIZE     512
#define MAX_EEG_SIZE_FOR_FFT    500

#define MAX_PPG_BUFFER_SIZE     130
#define MAX_PPG_SIZE_FOR_FFT    128

/*=================================================================================================
 FUNCTION PROTOTYPES
=================================================================================================*/
extern ppg_data_type* ppgActiveBuffer;         //pointer to array for FFT
extern ppg_data_type* ppgBackBuffer;           //pointer to array for storing datas
extern uint16_t ppg_buf_count;

extern uint16_t *ptrLeadOffAct;
extern uint16_t *ptrLeadOffBack;

extern float* eegActiveBuffer;                //pointer to array for FFT
extern float* eegBackBuffer;                  //pointer to array for storing datas
extern uint16_t eeg_buf_count;

extern uint8_t DevContact;

void sensorBattResultReport(uint8_t adc_chan);
uint8_t UpdateSensorStatus(uint8_t position, boolean onoff);
void toggle_eeg_buffer_pointer(void);
void toggle_ppg_buffer_pointer(void);
void sendtoMcCmdConstBuf(uint16_t command, void * data, uint16_t len);
void sendtoSensorCmd(uint16_t command);
void sendSensorResult2mc( void);
void sensordataCheckLeadOFF(uint8_t leadoff);
void LeadOffReportNSetContact(uint16_t leadoff_cnt);

/*===============================================================================================*/
#endif  /* SENSOR_DATA_H_ */
