#ifndef TARGET_H
#define TARGET_H
/*===============================================================================================*/
/**
 *   @file target.h
 *
 *   @version v1.0
 */
/*=================================================================================================

 (c) Copyright , All Rights Reserved

Revision History:

Modification Tracking
Author          Date            Number          Description of Changes
--------        --------        -------         ------------------------

Portability:

===================================================================================================
 INCLUDE FILES
=================================================================================================*/

/* CONSTANTS */

/* H/W Board Type Define */
#define SHINWOOHW
//#define FRASENHW

#define V21BOARD

#define USB_PWR_AUTO_ON

#define FFT_EEG_ON

#define FFT_PPG_ON
#define NEW_HEARTBEAT_CALC

/* for NSS Selection */
//#define PPG_HARD_NSS
//#define VS_HARD_NSS
//#define EEG_HARD_NSS


/* ADC Conversion METHOD */
//#define ADC_USE_POLLING_METHOD
//#define ADC_USE_DMA_METHOD
#define ADC_USE_IT_METHOD


/* MP3 DREQ method : POLL */
//#define USE_MP3_DREQ_POLL


/* USART TX RX METHOD */
#define USART_USE_TX_IT_METHOD
//#define USART_USE_DMA_METHOD
#define USART_RX_MULTIBYTE_WAIT
//#define USART_RX_PROCESS_SINGLE_BYTE

#if defined(USART_RX_PROCESS_SINGLE_BYTE) && defined(USART_RX_MULTIBYTE_WAIT)
    #error "Select USART_RX_PROCESS_SINGLE_BYTE or USART_RX_MULTIBYTE_WAIT !!!"
#endif

/* DEBUG PRINT */
#define USING_DBG_PRINT
#define USING_CUBEMX_USB_DRIVER
//#define USING_TM_USB_DRIVER
#define SYS_HAD_TICK

/* for BLE Module */
#define MURATA_BLE

/* for TEMP IIC Module */
#define IIC_USE_WAIT_TIMER

/* for FAT */
#define USING_QSORT_FILENAME

/* for SD or EMMC */
#define SUPPORT_EMMC_CARD
//#define SUPPORT_SPI_SD_CARD


/* for USB DEVICE Class */
#define USE_USB_VCP
#define USE_USB_MSC

#ifdef SUPPORT_SPI_SD_CARD
    #define USE_SPI_SDCARD
    #undef USE_EMMC_SD
	#undef USE_USB_MSC
#elif defined (SUPPORT_EMMC_CARD)
    #define USE_EMMC_SD
    #undef USE_SPI_SDCARD
    #define USE_EMMC_DRIVER
    #define USE_MASS_STORAGE_DMA
	#define USE_USB_MSC
#endif

#if defined(SUPPORT_SPI_SD_CARD) && defined(SUPPORT_EMMC_CARD)
    #error "Select One Device Only !!!"
#endif


#define DEFAULT_USB_DEVICE      1 // VCP == 1, MSC == 2

#if (DEFAULT_USB_DEVICE != 1) && !defined(USE_USB_MSC)
    #error " Error in DEFAULT_USB_DEVICE"
#endif    

/* TESTING PURPOSE ONLY */
/* charging status BLE Debugging purpose */
//#define TEST_CHARGING_STATUS
//#define FOR_LINE_TEST
#define DEV_VERSION

/*===============================================================================================*/
#endif  /* TARGET_H */
