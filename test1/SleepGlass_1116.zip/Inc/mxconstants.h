/**
  ******************************************************************************
  * File Name          : mxconstants.h
  * Description        : This file contains the common defines of the application
  ******************************************************************************
  *
  * COPYRIGHT(c) 2016 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "target.h"

/* USER CODE BEGIN Includes */

#ifdef SHINWOOHW

/* USER CODE END Includes */

/* Private define ------------------------------------------------------------*/

#define OSC32_IN_Pin GPIO_PIN_14
#define OSC32_IN_GPIO_Port GPIOC
#define OSC32_OUT_Pin GPIO_PIN_15
#define OSC32_OUT_GPIO_Port GPIOC
#define OSC_IN_Pin GPIO_PIN_0
#define OSC_IN_GPIO_Port GPIOH
#define OSC_OUT_Pin GPIO_PIN_1
#define OSC_OUT_GPIO_Port GPIOH
#define BATT_THERM_Pin GPIO_PIN_0
#define BATT_THERM_GPIO_Port GPIOC

#define KEY_PWR_Pin GPIO_PIN_1
#define KEY_PWR_GPIO_Port GPIOE

#define CHG_STA_Pin GPIO_PIN_2
#define CHG_STA_GPIO_Port GPIOC
#define BAT_CHK_Pin GPIO_PIN_3
#define BAT_CHK_GPIO_Port GPIOC

#ifdef V21BOARD
#define STA_LED_R_Pin GPIO_PIN_4
#define STA_LED_R_GPIO_Port GPIOC
#define STA_LED_G_Pin GPIO_PIN_0
#define STA_LED_G_GPIO_Port GPIOA
#else
#define STA_LED_R_Pin GPIO_PIN_0
#define STA_LED_R_GPIO_Port GPIOA
#define STA_LED_G_Pin GPIO_PIN_4
#define STA_LED_G_GPIO_Port GPIOC
#endif

#define LIGHT_SEN_Pin GPIO_PIN_1
#define LIGHT_SEN_GPIO_Port GPIOA
#define MIC_OUT_Pin GPIO_PIN_5
#define MIC_OUT_GPIO_Port GPIOC
#define STA_LED_B_Pin GPIO_PIN_0
#define STA_LED_B_GPIO_Port GPIOB
#define MP3_DCS_Pin GPIO_PIN_7
#define MP3_DCS_GPIO_Port GPIOE

#ifdef V21BOARD
#define MP3_DREQ_Pin GPIO_PIN_10
#define MP3_DREQ_GPIO_Port GPIOE
#else
#define MP3_DREQ_Pin GPIO_PIN_8
#define MP3_DREQ_GPIO_Port GPIOE
#endif

#define MP3_RESET_Pin GPIO_PIN_9
#define MP3_RESET_GPIO_Port GPIOE
#define SD__CS_Pin GPIO_PIN_11
#define SD__CS_GPIO_Port GPIOE
#define SD_CLK_Pin GPIO_PIN_12
#define SD_CLK_GPIO_Port GPIOE
#define SD_MISO_Pin GPIO_PIN_13
#define SD_MISO_GPIO_Port GPIOE
#define SD_MOSI_Pin GPIO_PIN_14
#define SD_MOSI_GPIO_Port GPIOE
#define SD_DECT_Pin GPIO_PIN_15
#define SD_DECT_GPIO_Port GPIOE
#define AMP_SCL_Pin GPIO_PIN_10
#define AMP_SCL_GPIO_Port GPIOB

#define EEG__DRDY_Pin GPIO_PIN_8
#define EEG__DRDY_GPIO_Port GPIOD

#define EEG_START_Pin GPIO_PIN_9
#define EEG_START_GPIO_Port GPIOD
#define EEG__PWD__RESET_Pin GPIO_PIN_10
#define EEG__PWD__RESET_GPIO_Port GPIOD
#define PPG__PDN_Pin GPIO_PIN_11
#define PPG__PDN_GPIO_Port GPIOD
#define PPG_DIAG_END_Pin GPIO_PIN_15
#define PPG_DIAG_END_GPIO_Port GPIOD
#define PPG_LED_ALM_Pin GPIO_PIN_6
#define PPG_LED_ALM_GPIO_Port GPIOC
#define PPG_PD_ALM_Pin GPIO_PIN_7
#define PPG_PD_ALM_GPIO_Port GPIOC
#define EMMC__RESET_Pin GPIO_PIN_8
#define EMMC__RESET_GPIO_Port GPIOA
#define TEMP_DRDY_Pin GPIO_PIN_9
#define TEMP_DRDY_GPIO_Port GPIOA
#define USB_ID_Pin GPIO_PIN_10
#define USB_ID_GPIO_Port GPIOA
#define ACCE_INT1_Pin GPIO_PIN_5
#define ACCE_INT1_GPIO_Port GPIOD

#define PPG_ADC_RDY_Pin GPIO_PIN_6
#define PPG_ADC_RDY_GPIO_Port GPIOD

#define PPG__RESET_Pin GPIO_PIN_7
#define PPG__RESET_GPIO_Port GPIOD
#define AMP_SDZ_Pin GPIO_PIN_8
#define AMP_SDZ_GPIO_Port GPIOB
#define AMP_SDA_Pin GPIO_PIN_9
#define AMP_SDA_GPIO_Port GPIOB

#define PW_CTRL_Pin GPIO_PIN_1
#define PW_CTRL_GPIO_Port GPIOC

// �ʱ� power up �ÿ� check�Ͽ� test mode ����.
#define TMODE_Pin GPIO_PIN_15
#define TMODE_GPIO_Port GPIOA

/* BLE Module Reset Pin Define */
#define BLE_RST_Pin GPIO_PIN_0
#define BLE_RST_GPIO_Port GPIOE

/* H/W Version ID Pin Define */
#define HW_ID_0_Pin GPIO_PIN_0
#define HW_ID_0_GPIO_Port GPIOD
#define HW_ID_1_Pin GPIO_PIN_1
#define HW_ID_1_GPIO_Port GPIOD

/* USB_DET Pin Define */
#define USB_DET_Pin GPIO_PIN_3
#define USB_DET_GPIO_Port GPIOE

/* CHG_CTRL Pin Define */
#define CHG_CTRL_Pin GPIO_PIN_13
#define CHG_CTRL_GPIO_Port GPIOC

/* USER CODE BEGIN Private defines */
#define EEG_CS_PIN          GPIO_PIN_12
#define EEG_CS_GPIO_Port    GPIOB

#define PPG_CS_PIN          GPIO_PIN_4
#define PPG_CS_GPIO_Port    GPIOE

#define MP3_CS_PIN          GPIO_PIN_4
#define MP3_CS_GPIO_Port    GPIOA

#define EEG_CS				GPIOB, GPIO_PIN_12
#define PPG_CS				GPIOE, GPIO_PIN_4
#define SD_CS				GPIOE, GPIO_PIN_11
#define MP3_CS				GPIOA, GPIO_PIN_4


#elif defined (FRASENHW)
    #include "mxconstants_FRASEN.h"
#endif

/* USER CODE END Private defines */

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
