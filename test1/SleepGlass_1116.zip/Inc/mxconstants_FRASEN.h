/**
  ******************************************************************************
  * File Name          : mxconstants.h
  * Description        : This file contains the common defines of the application
  ******************************************************************************
  *
  * COPYRIGHT(c) 2016 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "target.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private define ------------------------------------------------------------*/

#define OSC32_IN_Pin GPIO_PIN_14
#define OSC32_IN_GPIO_Port GPIOC
#define OSC32_OUT_Pin GPIO_PIN_15
#define OSC32_OUT_GPIO_Port GPIOC
#define OSC_IN_Pin GPIO_PIN_0
#define OSC_IN_GPIO_Port GPIOH
#define OSC_OUT_Pin GPIO_PIN_1
#define OSC_OUT_GPIO_Port GPIOH
#define BATT_THERM_Pin GPIO_PIN_0
#define BATT_THERM_GPIO_Port GPIOC

#define KEY_PWR_Pin GPIO_PIN_3
#define KEY_PWR_GPIO_Port GPIOD

#define CHG_STA_Pin GPIO_PIN_2
#define CHG_STA_GPIO_Port GPIOC
#define BAT_CHK_Pin GPIO_PIN_3
#define BAT_CHK_GPIO_Port GPIOC

#define STA_LED_R_Pin GPIO_PIN_0
#define STA_LED_R_GPIO_Port GPIOA

#define LIGHT_SEN_Pin GPIO_PIN_1
#define LIGHT_SEN_GPIO_Port GPIOA

#define STA_LED_G_Pin GPIO_PIN_4
#define STA_LED_G_GPIO_Port GPIOC
#define STA_LED_B_Pin GPIO_PIN_4
#define STA_LED_B_GPIO_Port GPIOC

#define MIC_OUT_Pin GPIO_PIN_5
#define MIC_OUT_GPIO_Port GPIOC

#define MP3_DCS_Pin GPIO_PIN_10
#define MP3_DCS_GPIO_Port GPIOD

#define MP3_DREQ_Pin GPIO_PIN_0
#define MP3_DREQ_GPIO_Port GPIOB

#define MP3_RESET_Pin GPIO_PIN_9
#define MP3_RESET_GPIO_Port GPIOD

#define SD__CS_Pin GPIO_PIN_9
#define SD__CS_GPIO_Port GPIOC

#define SD_CLK_Pin GPIO_PIN_10
#define SD_CLK_GPIO_Port GPIOC

#define SD_MISO_Pin GPIO_PIN_11
#define SD_MISO_GPIO_Port GPIOC

#define SD_MOSI_Pin GPIO_PIN_12
#define SD_MOSI_GPIO_Port GPIOC

#define SD_DECT_Pin GPIO_PIN_8
#define SD_DECT_GPIO_Port GPIOC

#define AMP_SCL_Pin GPIO_PIN_10
#define AMP_SCL_GPIO_Port GPIOB

#define EEG__DRDY_Pin GPIO_PIN_1
#define EEG__DRDY_GPIO_Port GPIOB

#define EEG_START_Pin GPIO_PIN_3
#define EEG_START_GPIO_Port GPIOE

#define EEG__PWD__RESET_Pin GPIO_PIN_4
#define EEG__PWD__RESET_GPIO_Port GPIOE

#define PPG__PDN_Pin GPIO_PIN_6
#define PPG__PDN_GPIO_Port GPIOD

#define PPG_DIAG_END_Pin GPIO_PIN_15
#define PPG_DIAG_END_GPIO_Port GPIOD
#define PPG_LED_ALM_Pin GPIO_PIN_6
#define PPG_LED_ALM_GPIO_Port GPIOC
#define PPG_PD_ALM_Pin GPIO_PIN_7
#define PPG_PD_ALM_GPIO_Port GPIOC
#define EMMC__RESET_Pin GPIO_PIN_8
#define EMMC__RESET_GPIO_Port GPIOA
#define TEMP_DRDY_Pin GPIO_PIN_9
#define TEMP_DRDY_GPIO_Port GPIOA
#define USB_ID_Pin GPIO_PIN_10
#define USB_ID_GPIO_Port GPIOA
#define ACCE_INT1_Pin GPIO_PIN_5
#define ACCE_INT1_GPIO_Port GPIOD

#define PPG_ADC_RDY_Pin GPIO_PIN_2
#define PPG_ADC_RDY_GPIO_Port GPIOB

#define PPG__RESET_Pin GPIO_PIN_5
#define PPG__RESET_GPIO_Port GPIOD

#define AMP_SDZ_Pin GPIO_PIN_8
#define AMP_SDZ_GPIO_Port GPIOB
#define AMP_SDA_Pin GPIO_PIN_9
#define AMP_SDA_GPIO_Port GPIOB

#define PW_CTRL_Pin GPIO_PIN_4
#define PW_CTRL_GPIO_Port GPIOD

/* USER CODE BEGIN Private defines */

#define EEG_CS_PIN          GPIO_PIN_2
#define EEG_CS_GPIO_Port    GPIOD

#define PPG_CS_PIN          GPIO_PIN_7
#define PPG_CS_GPIO_Port    GPIOD

#define MP3_CS_PIN          GPIO_PIN_11
#define MP3_CS_GPIO_Port    GPIOD

#define EEG_CS				GPIOD, GPIO_PIN_2
#define PPG_CS				GPIOD, GPIO_PIN_7
#define SD_CS				GPIOC, GPIO_PIN_9
#define MP3_CS				GPIOD, GPIO_PIN_11

/* USER CODE END Private defines */

/**
  * @}
  */ 

/**
  * @}
*/ 

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
