This project includes sample applications that demonstrate different features of the Android Framework and Support Library.

It is actively managed by the Android Framework Team.

### Disclaimers
**This is not an official Google product.**