# Movie-Pedia
This is a sample project showing the use of Android Data Binding library, Picasso and Retrofit.
